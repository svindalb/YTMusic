import AppKit
import Observation
import SwiftUI
import WebKit

@MainActor @Observable
final class MusicSession {
    private(set) var accountGeneration = UUID()
    private var accountIdentity: MusicAccountIdentity?
    private var currentPageCanBeCached = true
    var ready = false
    var connecting = true
    var connectionMessage = "Restoring your music session…"
    var tools = ListeningTools()
    private var pendingPlaceRestore: (generation: String, videoID: String, elapsed: Double, playing: Bool)?
    private var placeRestoreInFlight = false
    private var restoredQueue: [MusicItem]?
    private var restoredQueueIndex = 0
    private var restoredShuffleBag: [Int] = []
    private var restoredHistory: [Int] = []
    private var placeRestoreTimeout: Task<Void, Never>?
    private var holdCaptureTask: Task<Void, Never>?
    private var reportedPlaylistIndex: Int?
    var now = NowPlaying()
    private var playingDetails: MusicItem?
    private(set) var shuffle = false
    private(set) var repeatMode: MusicRepeatMode = .off
    var showLyrics = false
    private(set) var lyrics: SongLyrics?
    private(set) var loadingLyrics = false
    private(set) var lyricsError: String?
    private var lyricsRequestID = UUID()
    @ObservationIgnored private let systemMedia = SystemMediaControls()
    var volume: Double = UserDefaults.standard.object(forKey: "musicVolume") as? Double ?? 0.7
    var clearingCache = false
    var cacheCleanupPending = false
    var cacheCleanupMessage: String?
    var lastCacheCleanup: Date? = UserDefaults.standard.object(forKey: "lastCacheCleanup") as? Date
    private var cacheMaintenanceTask: Task<Void, Never>?
    var continuous = true
    var playbackError: String?
    var playlists: [MusicItem] = []
    var loadingPlaylists = false
    var playlistsError: String?
    private var playlistsRequestID = UUID()
    var addToPlaylistSong: MusicItem?
    var playlistMutationBusy = false
    var playlistMutationError: String?
    var songLikes: [String: Bool] = [:]
    var songLikeBusy = Set<String>()
    var songLikeErrors: [String: String] = [:]
    var queue: [MusicItem] = []
    var route = LibrarySection.all[0].route
    var page: MusicPage?
    var isLoading = false
    var loadingMore = false
    var error: String?
    var history: [MusicRoute] = []
    private var loadTask: Task<Void, Never>?
    private var navigationRequestID = UUID()
    private var pageCache = MusicPageCache()
    #if DEBUG
    private var lastVolumeDiagnosticWrite = Date.distantPast
    #endif
    private var initialized = false
    private var capturing = false
    private var playback = PlaybackContext()
    private var selectionTask: Task<Void, Never>?
    private var selectionID = UUID()
    private var queueTask: Task<Void, Never>?
    private var queueRequestID = UUID()
    private var transportSequence = 0
    private var pendingTransportCommand: Int?
    private var endRecovery: Task<Void, Never>?
    private var lastEndID = ""
    private var browser: WKWebView?
    private var window: NSWindow?
    private var bridge: MusicBrowserBridge?
    private let store = WKWebsiteDataStore(forIdentifier: UUID(uuidString: "79BFAB9B-7B7E-471C-9F83-24A2B6F138AE")!)
    private let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"
    @ObservationIgnored private lazy var api = MusicAPI(store: store, userAgent: userAgent)

    func start() {
        guard !initialized else { return }
        initialized = true
        systemMedia.start(self)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = store
        configuration.mediaTypesRequiringUserActionForPlayback = []
        let bridge = MusicBrowserBridge(owner: self)
        configuration.userContentController.add(bridge, name: "musicState")
        guard installPlayerBridge(into: configuration.userContentController, autoplay: false) else { return }
        let browser = WKWebView(frame: NSRect(x: 0, y: 0, width: 1100, height: 760), configuration: configuration)
        browser.customUserAgent = userAgent
        browser.navigationDelegate = bridge
        browser.uiDelegate = bridge
        self.browser = browser
        self.bridge = bridge
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1100, height: 760),
            styleMask: [.titled, .closable, .resizable, .miniaturizable], backing: .buffered, defer: false)
        window.title = "YouTube Music — Account & Player"
        window.isReleasedWhenClosed = false
        window.contentView = NSHostingView(rootView: MusicBrowserWindow(browser: browser, session: self))
        window.center()
        self.window = window
        cacheMaintenanceTask = Task { [weak self] in
            guard let self else { return }
            await clearCache()
            browser.load(URLRequest(url: URL(string: "https://music.youtube.com/")!))
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(30 * 60)) }
                catch { return }
                if !now.isPlaying && CacheMaintenance.isDue(lastCleanup: lastCacheCleanup) {
                    await clearCache()
                }
            }
        }
    }

    func requestCacheCleanup() {
        guard !clearingCache else { return }
        if now.isPlaying {
            cacheCleanupPending = true
            cacheCleanupMessage = "Cache will clear when playback pauses. Your login stays saved."
        } else {
            Task { await clearCache() }
        }
    }

    private func clearCache() async {
        guard !clearingCache else { return }
        clearingCache = true
        cacheCleanupPending = false
        defer { clearingCache = false }
        await CacheMaintenance.clear(store)
        await ArtworkLoader.shared.clear()
        URLCache.shared.removeAllCachedResponses()
        invalidatePages()
        let date = Date()
        lastCacheCleanup = date
        UserDefaults.standard.set(date, forKey: "lastCacheCleanup")
        cacheCleanupMessage = "Cache cleared. Your login is still saved."
    }

    func showBrowser() {
        start()
        window?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func captureSession() async {
        guard !capturing, let browser, browser.url?.host == "music.youtube.com" else { return }
        capturing = true
        defer { capturing = false }
        do {
            let script = "JSON.stringify({loggedIn:window.ytcfg?.get('LOGGED_IN')===true,context:window.ytcfg?.get('INNERTUBE_CONTEXT'),apiKey:window.ytcfg?.get('INNERTUBE_API_KEY'),authUser:window.ytcfg?.get('SESSION_INDEX')??0,delegatedSession:window.ytcfg?.get('DELEGATED_SESSION_ID'),dataSyncID:window.ytcfg?.get('DATASYNC_ID')})"
            guard let raw = try await browser.evaluateJavaScript(script) as? String,
                  let config = try JSONSerialization.jsonObject(with: Data(raw.utf8)) as? [String: Any] else { return }
            connecting = false
            guard config["loggedIn"] as? Bool == true else {
                resetAccountState()
                connectionMessage = "Sign in to bring your music here."
                return
            }
            let identity = MusicAccountIdentity(config: config)
            if accountIdentity != identity { resetAccountState(); accountIdentity = identity; tools.connect(identity) }
            api.config = config
            if !ready {
                ready = true
                connectionMessage = "Connected to YouTube Music"
                window?.orderOut(nil)
                navigate(route, remember: false)
                Task { await loadPlaylists() }
            }

        } catch {
            if !ready { connectionMessage = "Session is still loading. Open Account to continue."; connecting = false }
        }
    }

    func resetAccountState() {
        cancelPlaceRestore()
        holdCaptureTask?.cancel()
        tools.reset()
        reportedPlaylistIndex = nil
        restoredQueue = nil; restoredHistory = []; restoredShuffleBag = []
        accountGeneration = UUID()
        accountIdentity = nil
        ready = false
        api.resetSession()
        loadTask?.cancel(); selectionTask?.cancel(); queueTask?.cancel(); endRecovery?.cancel()
        navigationRequestID = UUID(); selectionID = UUID(); queueRequestID = UUID(); playlistsRequestID = UUID()
        pendingTransportCommand = nil
        transportSequence += 1
        playback = PlaybackContext()
        run("document.querySelectorAll('video,audio').forEach(v => v.pause())")
        if let browser { _ = installPlayerBridge(into: browser.configuration.userContentController, autoplay: false) }
        pageCache = MusicPageCache()
        currentPageCanBeCached = false
        page = nil; history = []; queue = []; playlists = []
        route = LibrarySection.all[0].route
        now = NowPlaying()
        playingDetails = nil
        lyricsRequestID = UUID(); lyrics = nil; lyricsError = nil; loadingLyrics = false; showLyrics = false
        shuffle = false; repeatMode = .off
        systemMedia.update()
        loadingPlaylists = false; isLoading = false; loadingMore = false
        songLikes = [:]; songLikeErrors = [:]; songLikeBusy = []
        playlistsError = nil; playbackError = nil; error = nil
        addToPlaylistSong = nil; playlistMutationBusy = false; playlistMutationError = nil
        lastEndID = ""
    }

    private func checkAccount(_ generation: UUID) throws {
        guard ready, accountGeneration == generation else { throw CancellationError() }
    }

    func invalidatePages() {
        pageCache = MusicPageCache()
        currentPageCanBeCached = false
    }

    func holdMyPlace() {
        guard ready, let song = currentSong, !tools.holding else { return }
        let index: Int?
        if let restoredQueue, restoredQueue.indices.contains(restoredQueueIndex) {
            index = restoredQueue[restoredQueueIndex].playlistPosition ?? restoredQueueIndex
        } else {
            index = reportedPlaylistIndex ?? playingDetails?.playlistPosition ?? queue.firstIndex { $0.videoID == song.videoID }
        }
        let sourceID = playback.playlistID
        var captured = HeldPlace(song: song, queue: queue, playlistID: sourceID,
            selectedIndex: index, elapsed: max(0, now.elapsed), wasPlaying: now.isPlaying,
            shuffle: shuffle, repeatMode: repeatMode.rawValue, radioTrailID: tools.activeTrailID)
        let account = accountGeneration
        let nativeQueue = restoredQueue
        tools.setHolding(true)
        holdCaptureTask = Task {
            defer { if accountGeneration == account { tools.setHolding(false) } }
            do {
                if nativeQueue == nil, let sourceID, !sourceID.hasPrefix("RD") {
                    let source = MusicItem(id: "VL" + sourceID, title: "Current queue", subtitle: "", playlistID: sourceID, kind: "Playlist")
                    captured.queue = try await fullPlaylist(source).filter { $0.videoID != nil && !$0.unavailable }
                }
                try Task.checkCancellation(); try checkAccount(account)
                if captured.queue.count > 1000 {
                    let focus = captured.queue.firstIndex { $0.videoID == song.videoID && $0.playlistPosition == index }
                        ?? captured.queue.firstIndex { $0.videoID == song.videoID } ?? 0
                    let start = max(0, min(focus - 100, captured.queue.count - 1000))
                    captured.queue = Array(captured.queue.dropFirst(start).prefix(1000))
                }
                if !captured.queue.contains(where: { $0.videoID == song.videoID }) {
                    captured.queue.insert(song, at: 0)
                    captured.queue = Array(captured.queue.prefix(1000))
                }
                tools.hold(captured)
                tools.restoreMessage = "Your place is held. Explore whenever you like."
            } catch is CancellationError { }
            catch { if accountGeneration == account { tools.restoreMessage = "Couldn’t save the queue. Your previous held place is unchanged. Try again." } }
        }
    }

    func restoreHeldPlace() {
        guard ready, browser != nil, let saved = tools.heldPlace, let id = saved.song.videoID else { return }
        shuffle = saved.shuffle; repeatMode = MusicRepeatMode(rawValue: saved.repeatMode) ?? .off
        tools.resumeTrail(saved.radioTrailID)
        var seed = saved.queue
        if !seed.contains(where: { $0.videoID == id }) { seed.insert(saved.song, at: 0) }
        playingDetails = saved.song
        let index = seed.firstIndex(where: { $0.playlistPosition != nil && $0.playlistPosition == saved.selectedIndex && $0.videoID == id })
            ?? saved.selectedIndex.flatMap { seed.indices.contains($0) && seed[$0].videoID == id ? $0 : nil }
            ?? seed.firstIndex(where: { $0.videoID == id }) ?? 0
        restoredQueue = seed; restoredQueueIndex = index
        restoredShuffleBag = Array(seed.indices).filter { $0 != index }; restoredHistory = []
        play(videoID: id, playlistID: saved.playlistID, seed: seed, selectedIndex: saved.selectedIndex, startPaused: true, preserveRestoredQueue: true)
        guard playbackError == nil else { tools.setRestoring(false, message: playbackError); return }
        let generation = playback.generation
        pendingPlaceRestore = (generation, id, saved.elapsed, saved.wasPlaying)
        tools.setRestoring(true, message: "Loading your saved song and position…")
        placeRestoreTimeout = Task {
            do { try await Task.sleep(for: .seconds(30)) } catch { return }
            guard playback.generation == generation, pendingPlaceRestore != nil else { return }
            cancelPlaceRestore()
            run("window.__nativeMusic?.setPlaying(false, 0)")
            tools.setRestoring(false, message: "Couldn’t restore this song yet. Your held place is still saved; try again.")
        }
    }

    private func cancelPlaceRestore() {
        if pendingPlaceRestore != nil || placeRestoreInFlight { transportSequence += 1; pendingTransportCommand = nil }
        placeRestoreInFlight = false
        pendingPlaceRestore = nil
        placeRestoreTimeout?.cancel(); placeRestoreTimeout = nil
        if tools.restoring { tools.setRestoring(false) }
    }

    private func applyPlaceRestore(_ saved: (generation: String, videoID: String, elapsed: Double, playing: Bool)) {
        guard let browser, !placeRestoreInFlight else { return }
        placeRestoreInFlight = true
        transportSequence += 1
        let command = transportSequence
        let elapsed = max(0, min(saved.elapsed, max(0, now.duration - 0.25)))
        pendingTransportCommand = command
        browser.evaluateJavaScript("window.__nativeMusic?.restorePlace(\(elapsed), \(saved.playing), \(command))") { [weak self] result, error in
            guard let self, self.playback.generation == saved.generation, self.transportSequence == command,
                  self.placeRestoreInFlight, self.pendingPlaceRestore?.videoID == saved.videoID else { return }
            self.pendingPlaceRestore = nil; self.placeRestoreInFlight = false
            self.placeRestoreTimeout?.cancel(); self.placeRestoreTimeout = nil
            if error == nil && result as? Bool == true {
                self.now.elapsed = elapsed; self.now.isPlaying = saved.playing
                self.tools.setRestoring(false, message: "Returned to your saved place at " + elapsed.musicTime + ".")
                self.systemMedia.update()
            } else {
                self.pendingTransportCommand = nil
                self.tools.setRestoring(false, message: "Couldn’t seek to the saved position. Your held place is still saved; try again.")
            }
        }
    }

    private func fullPlaylist(_ playlist: MusicItem) async throws -> [MusicItem] {
        guard let id = playlist.playlistID else { throw ProbeError(message: "Choose a playlist to scan.") }
        let account = accountGeneration
        var entries: [MusicItem] = []
        var token: String?
        var seen = Set<String>()
        repeat {
            try Task.checkCancellation(); try checkAccount(account)
            let result = try await api.page(MusicRoute(title: playlist.title, browseID: "VL" + id), continuation: token)
            try Task.checkCancellation(); try checkAccount(account)
            let list = result.shelves.filter(\.isList).flatMap(\.items)
            for var item in list.isEmpty ? result.items : list {
                item.playlistPosition = entries.count
                entries.append(item)
            }
            token = result.continuation
            if let token, !seen.insert(token).inserted || seen.count > 300 {
                throw ProbeError(message: "Couldn’t finish reading the complete playlist. No changes were made. Try again.")
            }
        } while token != nil
        return entries
    }

    func scanPlaylist(_ playlist: MusicItem, compare: MusicItem?) async throws -> PlaylistAudit {
        let account = accountGeneration
        try checkAccount(account)
        let entries = try await fullPlaylist(playlist)
        try checkAccount(account)
        let other: [MusicItem]
        if let compare { other = try await fullPlaylist(compare) } else { other = [] }
        try checkAccount(account)
        return PlaylistAudit.make(playlist: playlist, entries: entries, compared: compare, other: other)
    }

    func removeDoctorDuplicates(_ selected: [MusicItem], from playlist: MusicItem) async throws {
        guard !playlistMutationBusy, let id = playlist.playlistID, selected.count <= 100 else {
            throw ProbeError(message: "Select up to 100 extra copies at a time, and wait for other playlist changes to finish.")
        }
        let account = accountGeneration
        playlistMutationBusy = true
        defer { if accountGeneration == account { playlistMutationBusy = false } }
        let fresh = try await fullPlaylist(playlist)
        let actions = try PlaylistAudit.removalActions(selected: selected, fresh: fresh, playlistID: id)
        try checkAccount(account)
        try await api.editPlaylist(id, actions: actions)
        try checkAccount(account)
        playlistDidChange(id)
    }

    func playlistArtwork(for item: MusicItem) -> URL? {
        if let artwork = item.artwork { return artwork }
        // The add-to-playlist endpoint often omits covers. Reuse the matching
        // library cover without changing which destinations are writable.
        guard let id = item.playlistID else { return nil }
        return playlists.first(where: { $0.playlistID == id || $0.browseID == "VL" + id })?.artwork
    }

    func writablePlaylists(for item: MusicItem) async throws -> [MusicItem] {
        let generation = accountGeneration
        try checkAccount(generation)
        guard let id = item.videoID else { return [] }
        let result = try await api.writablePlaylists(videoID: id)
        try checkAccount(generation)
        return result
    }

    func navigationFailed() {
        connecting = false
        connectionMessage = "Couldn’t connect to YouTube Music. Open Account to retry."
    }

    func navigate(_ target: MusicRoute, remember: Bool = true, refresh: Bool = false) {
        if let page, !isLoading, currentPageCanBeCached { pageCache.store(page, for: route) }
        if remember && route.id != target.id { history.append(route) }
        loadTask?.cancel()
        navigationRequestID = UUID()
        let requestID = navigationRequestID
        route = target
        error = nil
        loadingMore = false
        let cached = refresh ? nil : pageCache.page(for: target)
        page = cached
        currentPageCanBeCached = cached != nil
        isLoading = cached == nil
        loadTask = Task {
            do {
                let fetched: MusicPage
                if let cached { fetched = cached }
                else { fetched = try await api.page(target) }
                try Task.checkCancellation()
                guard navigationRequestID == requestID else { return }
                page = fetched
                currentPageCanBeCached = true
                // Use one captured target. Never chase a moving player through pages.
                let revealVideoID = now.videoID
                if let activePlaylist = playback.playlistID, fetched.playlistID == activePlaylist,
                   !revealVideoID.isEmpty {
                    var seen = Set<String>()
                    while page?.items.contains(where: { $0.videoID == revealVideoID }) == false,
                          let token = page?.continuation, seen.count < 15, seen.insert(token).inserted {
                        let more = try await api.page(target, continuation: token)
                        try Task.checkCancellation()
                        guard navigationRequestID == requestID else { return }
                        appendPage(more, token: token)
                    }
                }
                if let page { pageCache.store(page, for: target) }
                isLoading = false
            } catch is CancellationError { }
            catch {
                guard !Task.isCancelled, navigationRequestID == requestID else { return }
                self.error = error.localizedDescription
                self.page = nil
                self.isLoading = false
            }
        }
    }

    func navigateFromMenu(_ target: MusicRoute) {
        let generation = accountGeneration
        // Let the native pop-up finish its action before removing its source row.
        Task { @MainActor in
            await Task.yield()
            guard ready, accountGeneration == generation else { return }
            navigate(target)
        }
    }

    func back() {
        guard let previous = history.popLast() else { return }
        navigate(previous, remember: false)
    }

    func presentAddToPlaylist(_ item: MusicItem) {
        let generation = accountGeneration
        Task { @MainActor in
            await Task.yield()
            guard ready, accountGeneration == generation else { return }
            addToPlaylistSong = item
        }
    }

    func addSong(_ item: MusicItem, to playlistID: String) async throws {
        let generation = accountGeneration
        try checkAccount(generation)
        guard let videoID = item.videoID else { return }
        guard try await !api.playlistContains(playlistID, videoID: videoID) else {
            throw ProbeError(message: "This song is already in this playlist. Nothing was added.")
        }
        try checkAccount(generation)
        try await api.editPlaylist(playlistID, action: ["action": "ACTION_ADD_VIDEO", "addedVideoId": videoID])
        try checkAccount(generation)
        playlistDidChange(playlistID)
    }

    func createPlaylistAndAdd(_ item: MusicItem, title: String) async throws {
        let generation = accountGeneration
        try checkAccount(generation)
        guard let videoID = item.videoID else { return }
        let id = try await api.createPlaylist(title: title, videoID: videoID)
        try checkAccount(generation)
        // Make it immediately available even before the library refresh finishes.
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        playlists.append(MusicItem(id: "VL" + id, title: name, subtitle: "Private playlist", playlistID: id, browseID: "VL" + id, kind: "Playlist"))
        playlistDidChange(id)
        Task { await loadPlaylists() }
    }

    func removeSong(_ item: MusicItem, from playlistID: String) async {
        let generation = accountGeneration
        guard ready, !playlistMutationBusy, let entry = item.playlistEntryID,
              item.removalPlaylistID == playlistID, let videoID = item.videoID,
              route.browseID == "VL" + playlistID else { return }
        playlistMutationBusy = true
        defer { if accountGeneration == generation { playlistMutationBusy = false } }
        do {
            try await api.editPlaylist(playlistID, action: ["action": "ACTION_REMOVE_VIDEO", "setVideoId": entry, "removedVideoId": videoID])
            try checkAccount(generation)
            playlistDidChange(playlistID)
        } catch { if accountGeneration == generation { playlistMutationError = error.localizedDescription } }
    }

    private func playlistDidChange(_ playlistID: String) {
        invalidatePages()
        if route.browseID == "VL" + playlistID {
            navigate(route, remember: false, refresh: true)
        }
    }

    func loadSongLike(_ videoID: String, known: Bool? = nil) async {
        let generation = accountGeneration
        guard ready, songLikes[videoID] == nil, !songLikeBusy.contains(videoID) else { return }
        if let known { songLikes[videoID] = known; return }
        songLikeBusy.insert(videoID)
        defer { if accountGeneration == generation { songLikeBusy.remove(videoID) } }
        do {
            let liked = try await api.songLiked(videoID)
            try checkAccount(generation)
            if let liked {
                songLikes[videoID] = liked
                songLikeErrors[videoID] = nil
            } else { songLikeErrors[videoID] = "Like status unavailable. Click to retry." }
        } catch { if accountGeneration == generation { songLikeErrors[videoID] = "Couldn’t read like status. Click to retry." } }
    }

    func toggleSongLike(_ videoID: String) async {
        let generation = accountGeneration
        guard ready, !songLikeBusy.contains(videoID) else { return }
        guard let previous = songLikes[videoID] else { await loadSongLike(videoID); return }
        songLikeBusy.insert(videoID)
        songLikeErrors[videoID] = nil
        defer { if accountGeneration == generation { songLikeBusy.remove(videoID) } }
        do {
            try await api.setSongLiked(videoID, liked: !previous)
            try checkAccount(generation)
            songLikes[videoID] = !previous
            invalidatePages()
            if route.browseID == "VLLM" { navigate(route, remember: false, refresh: true) }
        } catch { if accountGeneration == generation { songLikeErrors[videoID] = "Couldn’t update like. Click to retry." } }
    }

    func loadPlaylists() async {
        guard ready, !loadingPlaylists else { return }
        loadingPlaylists = true
        playlistsError = nil
        let requestID = UUID()
        playlistsRequestID = requestID
        defer { if playlistsRequestID == requestID { loadingPlaylists = false } }
        let target = LibrarySection.all.first { $0.title == "Playlists" }!.route
        var token: String?
        var seenTokens = Set<String>()
        var seenPlaylists = Set<String>()
        var loaded: [MusicItem] = []
        do {
            repeat {
                let response = try await api.page(target, continuation: token)
                try Task.checkCancellation()
                guard ready, playlistsRequestID == requestID else { return }
                for item in response.items where item.playlistID != nil {
                    let identity = item.playlistID ?? item.id
                    if seenPlaylists.insert(identity).inserted { loaded.append(item) }
                }
                // Publish each page so the sidebar is usable while the rest loads.
                playlists = loaded
                token = response.continuation
                if let next = token, !seenTokens.insert(next).inserted { token = nil }
            } while token != nil
        } catch is CancellationError { }
        catch {
            guard ready, playlistsRequestID == requestID else { return }
            playlistsError = "Couldn’t load all playlists."
        }
    }

    func loadMore() async {
        guard !loadingMore, let token = page?.continuation else { return }
        let target = route
        let requestID = navigationRequestID
        loadingMore = true
        defer { if navigationRequestID == requestID { loadingMore = false } }
        do {
            let more = try await api.page(target, continuation: token)
            guard navigationRequestID == requestID else { return }
            appendPage(more, token: token)
            if let page, currentPageCanBeCached { pageCache.store(page, for: target) }
        } catch { if navigationRequestID == requestID { self.error = error.localizedDescription } }
    }

    private func appendPage(_ more: MusicPage, token: String) {
        for (index, shelf) in more.shelves.enumerated() {
            if let last = page?.shelves.indices.last,
               let existing = page?.shelves[last], existing.isList && shelf.isList,
               existing.title == shelf.title {
                page?.shelves[last].items.append(contentsOf: shelf.items)
            } else {
                page?.shelves.append(MusicShelf(id: token + "-\(index)", title: shelf.title,
                    items: shelf.items, more: shelf.more, isList: shelf.isList))
            }
        }
        if var updated = page, route.browseID.hasPrefix("VL") {
            var position = 0
            for shelfIndex in updated.shelves.indices where updated.shelves[shelfIndex].isList {
                for itemIndex in updated.shelves[shelfIndex].items.indices {
                    updated.shelves[shelfIndex].items[itemIndex].playlistPosition = position
                    position += 1
                }
            }
            page = updated
        }
        page?.continuation = more.continuation == token ? nil : more.continuation
    }

    var currentSong: MusicItem? {
        guard !now.videoID.isEmpty else { return nil }
        var item = MusicItem(id: now.videoID, title: now.title, subtitle: now.artist,
            artwork: now.artwork, videoID: now.videoID, duration: now.duration > 0 ? now.duration.musicTime : nil, kind: "Song")
        item = enrichedSong(item)
        return item
    }

    func enrichedSong(_ song: MusicItem) -> MusicItem {
        guard song.videoID == now.videoID, !now.videoID.isEmpty else { return song }
        let sources = [playingDetails, page?.song, route.song].compactMap { $0 } + (page?.items ?? []) + queue
        return sources.reduce(song) { PlaybackMetadata.merge($0, with: $1) }
    }

    func openCurrentSong() {
        guard let route = currentSong?.detailRoute else { return }
        navigate(route)
    }

    func open(_ item: MusicItem) {
        // Navigation wins over a thumbnail's suggested/shuffled playback endpoint.
        if let target = item.containerRoute { navigate(target) }
        else if item.videoID != nil { play(item) }
        else if let target = item.route { navigate(target) }
        else if let id = item.playlistID { navigate(.init(title: item.title, browseID: "VL" + id)) }
    }

    func play(_ item: MusicItem, radio: Bool = false) {
        guard ready else { return }
        selectionTask?.cancel()
        selectionID = UUID()
        let requestID = selectionID
        if let videoID = item.videoID, item.containerRoute?.browseID.hasPrefix("VL") != true {
            playingDetails = item
            let onCurrentPlaylist = page?.items.contains(where: { $0.videoID == videoID }) == true
                && (item.playlistID == nil || item.playlistID == page?.playlistID)
                && (route.browseID.hasPrefix("VL") || route.browseID.hasPrefix("MPRE"))
            if radio { tools.endRadio() }
            let playlistID = radio ? "RDAMVM" + videoID
                : (onCurrentPlaylist ? page?.playlistID : item.playlistID) ?? "RDAMVM" + videoID
            let seed = !radio && onCurrentPlaylist ? playableTracks(page!) : []
            let queueMatches = !radio && !onCurrentPlaylist && queue.contains(where: { $0.playlistEntryID != nil && $0.playlistEntryID == item.playlistEntryID })
            let tracks = queueMatches ? queue : seed
            let index = radio ? nil : PlaybackContext.selectedIndex(item: item, in: tracks)
            play(videoID: videoID, playlistID: playlistID, seed: tracks, selectedIndex: index)
        } else if let playlistID = item.playlistID {
            // A card's thumbnail overlay may represent shuffle/resume. Resolve the
            // canonical playlist list and explicitly request its first playable row.
            selectionTask = Task {
                do {
                    let list = try await api.page(.init(title: item.title, browseID: "VL" + playlistID))
                    try Task.checkCancellation()
                    guard selectionID == requestID else { return }
                    let tracks = playableTracks(list)
                    guard let first = tracks.first, let id = first.videoID else {
                        throw ProbeError(message: "This playlist has no playable songs.")
                    }
                    play(videoID: id, playlistID: playlistID, seed: tracks)
                } catch {
                    if !Task.isCancelled && selectionID == requestID { playbackError = error.localizedDescription }
                }
            }
        }
    }

    private func playableTracks(_ page: MusicPage) -> [MusicItem] {
        let lists = page.shelves.filter(\.isList).flatMap(\.items).filter { $0.videoID != nil }
        return lists.isEmpty ? page.items.filter { $0.videoID != nil } : lists
    }

    func playPage() {
        guard let page else { return }
        if let song = page.song { play(song); return }
        selectionTask?.cancel()
        selectionID = UUID()
        let tracks = playableTracks(page)
        guard let first = tracks.first, let id = first.videoID else { return }
        let playlistID = route.browseID.hasPrefix("VL") ? String(route.browseID.dropFirst(2)) : page.playlistID
        play(videoID: id, playlistID: playlistID ?? "RDAMVM" + id, seed: tracks)
    }

    private func play(videoID: String?, playlistID: String?, seed: [MusicItem] = [], selectedIndex: Int? = nil, startPaused: Bool = false, preserveRestoredQueue: Bool = false) {
        guard let videoID, let browser else { return }
        cancelPlaceRestore()
        if !preserveRestoredQueue { restoredQueue = nil; restoredHistory = []; restoredShuffleBag = [] }
        reportedPlaylistIndex = selectedIndex
        playingDetails = ([playingDetails, page?.song, route.song].compactMap { $0 } + seed + (page?.items ?? []))
            .first { $0.videoID == videoID }
        endRecovery?.cancel()
        queueTask?.cancel()
        transportSequence += 1
        pendingTransportCommand = nil
        playback.begin(videoID: videoID, playlistID: playlistID)
        queue = seed.map { item in var copy = item; copy.playlistID = playlistID; return copy }
        playbackError = nil
        lastEndID = ""
        guard installPlayerBridge(into: browser.configuration.userContentController, autoplay: !startPaused, pauseOnLoad: startPaused) else { return }
        // Keep the outgoing document quiet as well; its late state messages are
        // rejected by generation once the new request starts.
        run("document.querySelector('video')?.pause()")
        var url = URLComponents(string: "https://music.youtube.com/watch")!
        url.queryItems = [URLQueryItem(name: "v", value: videoID)]
        if let playlistID { url.queryItems?.append(.init(name: "list", value: playlistID)) }
        if let index = selectedIndex ?? seed.firstIndex(where: { $0.videoID == videoID }) {
            url.queryItems?.append(.init(name: "index", value: String(index + 1)))
        }
        if let item = ([playingDetails].compactMap { $0 } + seed + (page?.items ?? [])).first(where: { $0.videoID == videoID }) {
            now.title = item.title; now.artist = item.subtitle; now.artwork = item.artwork
        } else {
            now.title = "Loading song…"; now.artist = ""; now.artwork = nil
        }
        now.videoID = videoID
        if playlistID?.hasPrefix("RD") == true, let seed = currentSong {
            tools.beginRadio(seed: seed, playlistID: playlistID!)
        } else { tools.endRadio() }
        now.elapsed = 0
        now.duration = 0
        now.isPlaying = false
        lyricsRequestID = UUID(); lyrics = nil; lyricsError = nil; loadingLyrics = false
        systemMedia.update()
        browser.load(URLRequest(url: url.url!))
        refreshQueue(videoID: videoID)
    }

    private func refreshQueue(videoID: String) {
        queueTask?.cancel()
        let generation = playback.generation
        let playlistID = playback.playlistID
        let requestID = UUID()
        queueRequestID = requestID
        queueTask = Task { await loadQueue(videoID: videoID, playlistID: playlistID,
            generation: generation, requestID: requestID) }
    }

    private func loadQueue(videoID: String?, playlistID: String?, generation: String, requestID: UUID) async {
        var body: [String: Any] = ["isAudioOnly": true, "enablePersistentPlaylistPanel": true]
        if let videoID { body["videoId"] = videoID }
        if let playlistID { body["playlistId"] = playlistID }
        guard let json = try? await api.request("next", body: body), !Task.isCancelled,
              playback.owns(generation, playlistID: playlistID), queueRequestID == requestID else { return }
        var items: [MusicItem] = []
        let playlistPanels = MusicParser.dictionaries(json, key: "playlistPanelRenderer")
        let wrappers = playlistPanels.first?["contents"] as? [[String: Any]] ?? []
        let panels: [[String: Any]] = wrappers.compactMap { wrapper in
            if let panel = wrapper["playlistPanelVideoRenderer"] as? [String: Any] { return panel }
            let wrapped = wrapper["playlistPanelVideoWrapperRenderer"] as? [String: Any]
            return (wrapped?["primaryRenderer"] as? [String: Any])?["playlistPanelVideoRenderer"] as? [String: Any]
        }
        for panel in panels {
            if let item = PlaybackMetadata.item(from: panel, playlistID: playlistID) { items.append(item) }
        }
        if let detail = items.first(where: { $0.videoID == now.videoID }) {
            playingDetails = playingDetails.map { PlaybackMetadata.merge($0, with: detail) } ?? detail
        }
        if let displayed = page?.song, let detail = items.first(where: { $0.videoID == displayed.videoID }) {
            page?.song = PlaybackMetadata.merge(displayed, with: detail)
        }
        queue = restoredQueue ?? PlaybackContext.reconcileQueue(existing: queue, incoming: items, playlistID: playlistID)
    }

    func setShuffle(_ enabled: Bool) {
        shuffle = enabled
        applyPlaybackModes()
    }

    func setRepeat(_ mode: MusicRepeatMode) {
        repeatMode = mode
        applyPlaybackModes()
    }

    private func applyPlaybackModes() {
        run("window.__nativeMusic?.setModes(\(shuffle), '\(repeatMode.rawValue)')")
        if let browser { _ = installPlayerBridge(into: browser.configuration.userContentController, autoplay: false) }
    }

    func loadLyrics() async {
        let videoID = now.videoID
        let account = accountGeneration
        let request = UUID()
        lyricsRequestID = request
        lyrics = nil; lyricsError = nil
        guard ready, !videoID.isEmpty else { loadingLyrics = false; return }
        loadingLyrics = true
        defer { if lyricsRequestID == request { loadingLyrics = false } }
        do {
            let next = try await api.request("next", body: ["videoId": videoID, "isAudioOnly": true])
            guard !Task.isCancelled, lyricsRequestID == request, accountGeneration == account, now.videoID == videoID else { return }
            guard let browseID = LyricsParser.browseID(in: next) else { return }
            let response = try await api.request("browse", body: ["browseId": browseID])
            guard !Task.isCancelled, lyricsRequestID == request, accountGeneration == account, now.videoID == videoID else { return }
            lyrics = LyricsParser.parse(response)
        } catch {
            guard !Task.isCancelled, lyricsRequestID == request, accountGeneration == account, now.videoID == videoID else { return }
            lyricsError = error.localizedDescription
        }
    }

    func togglePlayback() { cancelPlaceRestore(); setPlaying(!now.isPlaying) }

    func setPlaying(_ desired: Bool) {
        cancelPlaceRestore()
        guard let browser, !now.videoID.isEmpty else { return }
        let previous = now.isPlaying
        transportSequence += 1
        let command = transportSequence
        let generation = playback.generation
        pendingTransportCommand = command
        // The icon responds on this click, without waiting for the WebKit round trip.
        now.isPlaying = desired
        systemMedia.update()
        browser.evaluateJavaScript("window.__nativeMusic?.setPlaying(\(desired), \(command))") { [weak self] result, error in
            guard let self, self.playback.generation == generation,
                  self.transportSequence == command else { return }
            if error != nil || result as? Bool != true {
                self.pendingTransportCommand = nil
                self.now.isPlaying = previous
                self.systemMedia.update()
            }
        }
    }
    func next() {
        cancelPlaceRestore()
        if restoredQueue != nil { advanceRestoredQueue(); return }
        run("document.querySelector('#movie_player')?.nextVideo?.()")
    }

    private func advanceRestoredQueue(automatic: Bool = false) {
        guard let tracks = restoredQueue, !tracks.isEmpty else { return }
        let index: Int?
        if repeatMode == .one && automatic { index = restoredQueueIndex }
        else if shuffle {
            if restoredShuffleBag.isEmpty, repeatMode == .all { restoredShuffleBag = Array(tracks.indices).filter { $0 != restoredQueueIndex } }
            index = restoredShuffleBag.isEmpty ? (repeatMode == .all ? restoredQueueIndex : nil) : restoredShuffleBag.remove(at: Int.random(in: 0..<restoredShuffleBag.count))
        } else if restoredQueueIndex + 1 < tracks.count { index = restoredQueueIndex + 1 }
        else { index = repeatMode == .all ? 0 : nil }
        guard let index else {
            if continuous, let song = currentSong, let id = song.videoID { play(videoID: id, playlistID: "RDAMVM" + id, seed: [song]) }
            else { setPlaying(false) }
            return
        }
        restoredHistory.append(restoredQueueIndex)
        restoredHistory = Array(restoredHistory.suffix(1000))
        restoredQueueIndex = index
        play(videoID: tracks[index].videoID, playlistID: playback.playlistID, seed: tracks,
            selectedIndex: tracks[index].playlistPosition, preserveRestoredQueue: true)
    }
    func previous() {
        cancelPlaceRestore()
        if now.elapsed > 3 { seek(0) }
        else if let tracks = restoredQueue {
            let index = restoredHistory.popLast() ?? max(0, restoredQueueIndex - 1)
            restoredQueueIndex = index
            play(videoID: tracks[index].videoID, playlistID: playback.playlistID, seed: tracks,
                selectedIndex: tracks[index].playlistPosition, preserveRestoredQueue: true)
        }
        else { run("document.querySelector('#movie_player')?.previousVideo?.()") }
    }
    func seek(_ seconds: Double) {
        cancelPlaceRestore()
        let value = max(0, min(seconds, now.duration))
        now.elapsed = value
        systemMedia.update()
        run("(()=>{const v=document.querySelector('video');if(v)v.currentTime=\(value);})()")
    }
    func setVolume(_ value: Double) {
        volume = max(0, min(1, value))
        UserDefaults.standard.set(volume, forKey: "musicVolume")
        run("window.__nativeMusic?.setVolume(\(volume))")
        if let browser { _ = installPlayerBridge(into: browser.configuration.userContentController, autoplay: false) }
    }
    private func run(_ script: String) { browser?.evaluateJavaScript(script, completionHandler: nil) }

    func receive(_ state: [String: Any]) {
        guard ready, let id = state["id"] as? String,
              let generation = state["generation"] as? String,
              playback.accepts(generation: generation, videoID: id) else { return }
        if restoredQueue != nil, id != now.videoID { return }
        #if DEBUG
        if Date().timeIntervalSince(lastVolumeDiagnosticWrite) >= 2,
           let diagnostics = state["volumeDiagnostics"] as? [String: Any],
           let data = try? JSONSerialization.data(withJSONObject: diagnostics, options: [.sortedKeys]) {
            try? data.write(to: FileManager.default.temporaryDirectory.appendingPathComponent("YTMusic-VolumeDiagnostics.json"), options: .atomic)
            if let modes = state["playbackModes"] as? [String: Any], let modeData = try? JSONSerialization.data(withJSONObject: modes) {
                try? modeData.write(to: FileManager.default.temporaryDirectory.appendingPathComponent("YTMusic-PlaybackModes.json"), options: .atomic)
            }
            lastVolumeDiagnosticWrite = Date()
        }
        #endif
        let changed = now.videoID != id
        if changed { now.artwork = nil; reportedPlaylistIndex = nil }
        now.videoID = id
        if let title = state["title"] as? String, !title.isEmpty { now.title = title }
        if let artist = state["artist"] as? String, !artist.isEmpty { now.artist = artist }
        if let image = state["artwork"] as? String, let url = URL(string: image) { now.artwork = url }
        // Ignore reports sent before the latest click while its command is in flight.
        if pendingTransportCommand == nil || (state["transportCommand"] as? Int ?? 0) >= pendingTransportCommand! {
            pendingTransportCommand = nil
            now.isPlaying = state["playing"] as? Bool ?? false
        }
        if !now.isPlaying && !clearingCache,
           cacheCleanupPending || CacheMaintenance.isDue(lastCleanup: lastCacheCleanup) {
            Task { await clearCache() }
        }
        let elapsed = state["elapsed"] as? Double ?? 0
        let duration = state["duration"] as? Double ?? 0
        now.elapsed = elapsed.isFinite ? elapsed : 0
        now.duration = duration.isFinite ? duration : 0
        systemMedia.update()
        if let index = state["playlistIndex"] as? Int, index >= 0, index < 100000,
           state["playlistID"] as? String == playback.playlistID { reportedPlaylistIndex = index }
        tools.updateArtwork(now.artwork)
        if now.isPlaying, let song = currentSong { tools.record(song) }
        if let saved = pendingPlaceRestore, saved.videoID == id, saved.generation == playback.generation, now.duration > 0 {
            applyPlaceRestore(saved)
        }
        if changed {
            playingDetails = ([page?.song, route.song].compactMap { $0 } + (page?.items ?? []) + queue).first { $0.videoID == id }
            lyricsRequestID = UUID(); lyrics = nil; lyricsError = nil; loadingLyrics = false
            lastEndID = ""
            endRecovery?.cancel()
            refreshQueue(videoID: id)
        }
        if state["ended"] as? Bool == true, restoredQueue != nil {
            if lastEndID != id { lastEndID = id; advanceRestoredQueue(automatic: true) }
            return
        }
        if state["ended"] as? Bool == true, (continuous || repeatMode != .off), lastEndID != id {
            lastEndID = id
            let endingGeneration = playback.generation
            endRecovery = Task {
                try? await Task.sleep(for: .seconds(2))
                guard !Task.isCancelled, now.videoID == id, !now.isPlaying else { return }
                if repeatMode == .one { seek(0); setPlaying(true); lastEndID = ""; return }
                next()
                try? await Task.sleep(for: .seconds(3))
                guard !Task.isCancelled, now.videoID == id, !now.isPlaying else { return }
                if repeatMode == .all, let first = queue.first, let firstID = first.videoID {
                    play(videoID: firstID, playlistID: playback.playlistID, seed: queue, selectedIndex: 0)
                    return
                }
                // If a finite queue has ended and YouTube did not advance, start its song radio.
                let json = try? await api.request("next", body: ["videoId": id, "playlistId": "RDAMVM" + id, "isAudioOnly": true])
                guard !Task.isCancelled, playback.generation == endingGeneration else { return }
                let videos = json.map { MusicParser.dictionaries($0, key: "playlistPanelVideoRenderer") } ?? []
                if let nextID = videos.compactMap({ $0["videoId"] as? String }).first(where: { $0 != id }) {
                    play(videoID: nextID, playlistID: "RDAMVM" + id)
                }
            }
        }
    }

    @discardableResult
    private func installPlayerBridge(into controller: WKUserContentController, autoplay: Bool, pauseOnLoad: Bool = false) -> Bool {
        guard let url = Bundle.main.url(forResource: "PlayerBridge", withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else {
            playbackError = "The playback component is missing. Please rebuild the app."
            return false
        }
        let config: [String: Any] = ["generation": playback.generation, "volume": volume,
            "expectedVideoID": playback.awaitingVideoID as Any? ?? NSNull(), "autoplay": autoplay,
            "shuffle": shuffle, "repeatMode": repeatMode.rawValue, "pauseOnLoad": pauseOnLoad, "nativeQueue": restoredQueue != nil]
        guard let data = try? JSONSerialization.data(withJSONObject: config),
              let json = String(data: data, encoding: .utf8) else { return false }
        controller.removeAllUserScripts()
        controller.addUserScript(WKUserScript(source: source.replacingOccurrences(of: "__NATIVE_CONFIG__", with: json),
            injectionTime: .atDocumentStart, forMainFrameOnly: true))
        return true
    }

}

@MainActor
final class MusicBrowserBridge: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    weak var owner: MusicSession?
    private var popups: [NSWindow] = []
    init(owner: MusicSession) { self.owner = owner }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.frameInfo.securityOrigin.host == "music.youtube.com",
              let state = message.body as? [String: Any] else { return }
        owner?.receive(state)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { Task { await owner?.captureSession() } }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { owner?.navigationFailed() }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        let popup = WKWebView(frame: .zero, configuration: configuration)
        popup.customUserAgent = webView.customUserAgent
        popup.navigationDelegate = self; popup.uiDelegate = self
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 760, height: 760),
            styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
        window.title = "Google Sign In"; window.isReleasedWhenClosed = false; window.contentView = popup
        popups.append(window); window.center(); window.makeKeyAndOrderFront(nil)
        return popup
    }
    func webViewDidClose(_ webView: WKWebView) { webView.window?.close() }
}

struct MusicBrowserWindow: View {
    let browser: WKWebView
    let session: MusicSession
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Reload") { browser.reload() }
                Button("YouTube Music") { browser.load(URLRequest(url: URL(string: "https://music.youtube.com/")!)) }
                Spacer()
                Button("Continue in App") { Task { await session.captureSession(); if session.ready { browser.window?.orderOut(nil) } } }
            }.padding(10)
            ProbeWebView(browser: browser)
        }
    }
}

import SwiftUI

struct SongActionsMenu: View {
    let song: MusicItem
    var includeSong = false
    var close: () -> Void = {}
    @Environment(MusicSession.self) private var music

    var body: some View {
        let item = music.enrichedSong(song)
        let generation = music.accountGeneration
        Menu {
            if includeSong, let route = item.detailRoute {
                Button("Go to song", systemImage: "music.note") { perform(account: generation) { music.navigateFromMenu(route) } }
            }
            Button("Go to artist", systemImage: "person") {
                if let artist = item.artist { perform(account: generation) { music.navigateFromMenu(artist.route) } }
            }.disabled(item.artist == nil)
            Button("Go to album", systemImage: "square.stack") {
                if let album = item.album { perform(account: generation) { music.navigateFromMenu(album.route) } }
            }.disabled(item.album == nil)
            Divider()
            Button("Add to playlist…", systemImage: "text.badge.plus") {
                perform(account: generation) { music.presentAddToPlaylist(item) }
            }.disabled(item.videoID == nil)
        } label: {
            Image(systemName: "ellipsis").font(.system(size: 16, weight: .semibold)).frame(width: 26, height: 26)
        }
        .menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize()
        .help("Song actions").accessibilityLabel("Song actions")
        .accessibilityIdentifier(includeSong ? "now-playing-song-actions" : "song-detail-actions")
    }

    private func perform(account generation: UUID, _ action: @escaping @MainActor () -> Void) {
        // Finish the native menu action before dismissing its source popup.
        Task { @MainActor in
            await Task.yield()
            guard music.ready, music.accountGeneration == generation else { return }
            close()
            action()
        }
    }
}

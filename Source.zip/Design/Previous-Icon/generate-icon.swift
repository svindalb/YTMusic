import AppKit
import CoreGraphics
import Foundation

// Flat geometric artwork. Values are shared by SVG and raster outputs.
let output = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let design = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
let fileManager = FileManager.default
try fileManager.createDirectory(at: output, withIntermediateDirectories: true)
try fileManager.createDirectory(at: design, withIntermediateDirectories: true)
let tile = CGRect(x: 96, y: 96, width: 832, height: 832)
let corner: CGFloat = 184
let discRadius: CGFloat = 282
let ringRadius: CGFloat = 203
let ringWidth: CGFloat = 25
let triangle = [CGPoint(x: 461, y: 395), CGPoint(x: 461, y: 629), CGPoint(x: 648, y: 512)]
func color(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> CGColor {
    CGColor(colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!, components: [r / 255, g / 255, b / 255, 1])!
}
func png(pixels: Int) throws -> Data {
    let context = CGContext(data: nil, width: pixels, height: pixels, bitsPerComponent: 8,
        bytesPerRow: pixels * 4, space: CGColorSpace(name: CGColorSpace.sRGB)!,
        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    context.setAllowsAntialiasing(true)
    context.setShouldAntialias(true)
    context.scaleBy(x: CGFloat(pixels) / 1024, y: CGFloat(pixels) / 1024)
    context.setFillColor(color(23, 21, 29))
    context.addPath(CGPath(roundedRect: tile, cornerWidth: corner, cornerHeight: corner, transform: nil))
    context.fillPath()
    context.setFillColor(color(255, 37, 79))
    context.fillEllipse(in: CGRect(x: 512 - discRadius, y: 512 - discRadius, width: discRadius * 2, height: discRadius * 2))
    context.setStrokeColor(color(255, 255, 255))
    context.setLineWidth(ringWidth)
    context.strokeEllipse(in: CGRect(x: 512 - ringRadius, y: 512 - ringRadius, width: ringRadius * 2, height: ringRadius * 2))
    context.setFillColor(color(255, 255, 255))
    context.move(to: triangle[0]); context.addLine(to: triangle[1]); context.addLine(to: triangle[2])
    context.closePath(); context.fillPath()
    let image = context.makeImage()!
    return NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:])!
}
let sizes = [16, 32, 128, 256, 512]
var images: [[String: String]] = []
for size in sizes {
    for scale in [1, 2] {
        let suffix = scale == 2 ? "@2x" : ""
        let name = "icon_\(size)x\(size)\(suffix).png"
        try png(pixels: size * scale).write(to: output.appendingPathComponent(name))
        images.append(["filename": name, "idiom": "mac", "size": "\(size)x\(size)", "scale": "\(scale)x"])
    }
}
let contents: [String: Any] = ["images": images, "info": ["author": "xcode", "version": 1]]
try JSONSerialization.data(withJSONObject: contents, options: [.prettyPrinted, .sortedKeys]).write(to: output.appendingPathComponent("Contents.json"))
try png(pixels: 1024).write(to: design.appendingPathComponent("AppIcon-1024.png"))
try png(pixels: 256).write(to: design.appendingPathComponent("AppIcon-Preview.png"))
let svg = """
<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
  <title>YT Music flat app icon</title>
  <rect x="96" y="96" width="832" height="832" rx="184" fill="#17151D"/>
  <circle cx="512" cy="512" r="282" fill="#FF254F"/>
  <circle cx="512" cy="512" r="203" fill="none" stroke="#FFFFFF" stroke-width="25"/>
  <path d="M461 395V629L648 512Z" fill="#FFFFFF"/>
</svg>
"""
try Data(svg.utf8).write(to: design.appendingPathComponent("AppIcon.svg"))
print("Generated 10 macOS icon sizes, editable SVG and previews.")

import AppKit
import CoreGraphics
import Foundation

// Flat geometric artwork. Values are shared by SVG and raster outputs.
let output = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let design = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
let fileManager = FileManager.default
try fileManager.createDirectory(at: output, withIntermediateDirectories: true)
try fileManager.createDirectory(at: design, withIntermediateDirectories: true)
let tile = CGRect(x: 96, y: 96, width: 832, height: 832)
let corner: CGFloat = 184
let waveform = [CGPoint(x: 286, y: 654), CGPoint(x: 382, y: 366), CGPoint(x: 512, y: 562), CGPoint(x: 642, y: 366), CGPoint(x: 738, y: 654)]
let strokeWidth: CGFloat = 100
func color(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> CGColor {
    CGColor(colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!, components: [r / 255, g / 255, b / 255, 1])!
}
func png(pixels: Int) throws -> Data {
    let context = CGContext(data: nil, width: pixels, height: pixels, bitsPerComponent: 8,
        bytesPerRow: pixels * 4, space: CGColorSpace(name: CGColorSpace.sRGB)!,
        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    context.setAllowsAntialiasing(true)
    context.setShouldAntialias(true)
    context.scaleBy(x: CGFloat(pixels) / 1024, y: CGFloat(pixels) / 1024)
    context.setFillColor(color(23, 21, 29))
    context.addPath(CGPath(roundedRect: tile, cornerWidth: corner, cornerHeight: corner, transform: nil))
    context.fillPath()
    // Draw in SVG's top-down coordinate system.
    context.translateBy(x: 0, y: 1024)
    context.scaleBy(x: 1, y: -1)
    context.setLineWidth(strokeWidth)
    context.setLineCap(.round)
    context.setLineJoin(.round)
    context.setStrokeColor(color(255, 37, 79))
    context.move(to: waveform[0]); context.addLine(to: waveform[1]); context.addLine(to: waveform[2])
    context.strokePath()
    context.setStrokeColor(color(255, 104, 111))
    context.move(to: waveform[2]); context.addLine(to: waveform[3]); context.addLine(to: waveform[4])
    context.strokePath()
    let image = context.makeImage()!
    return NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:])!
}
let sizes = [16, 32, 128, 256, 512]
var images: [[String: String]] = []
for size in sizes {
    for scale in [1, 2] {
        let suffix = scale == 2 ? "@2x" : ""
        let name = "icon_\(size)x\(size)\(suffix).png"
        try png(pixels: size * scale).write(to: output.appendingPathComponent(name))
        images.append(["filename": name, "idiom": "mac", "size": "\(size)x\(size)", "scale": "\(scale)x"])
    }
}
let contents: [String: Any] = ["images": images, "info": ["author": "xcode", "version": 1]]
try JSONSerialization.data(withJSONObject: contents, options: [.prettyPrinted, .sortedKeys]).write(to: output.appendingPathComponent("Contents.json"))
try png(pixels: 1024).write(to: design.appendingPathComponent("AppIcon-1024.png"))
try png(pixels: 256).write(to: design.appendingPathComponent("AppIcon-Preview.png"))
let svg = """
<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
  <title>YT Music waveform monogram — flat app icon</title>
  <rect x="96" y="96" width="832" height="832" rx="184" fill="#17151D"/>
  <path d="M286 654L382 366L512 562" fill="none" stroke="#FF254F" stroke-width="100" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M512 562L642 366L738 654" fill="none" stroke="#FF686F" stroke-width="100" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""
try Data(svg.utf8).write(to: design.appendingPathComponent("AppIcon.svg"))
print("Generated 10 macOS icon sizes, editable SVG and previews.")

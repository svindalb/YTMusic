import SwiftUI

@main struct MyApp: App {
    @State private var music = MusicSession()
    var body: some Scene {
        WindowGroup(id: "main") {
            ContentView().environment(music)
        }
        .defaultSize(width: 1280, height: 850)
        .windowStyle(.hiddenTitleBar)
        .commands {
            CommandGroup(replacing: .appInfo) {
                Button("About YT Music") { AppAbout.show() }
            }
            CommandMenu("Playback") {
                Button(music.now.isPlaying ? "Pause" : "Play") { music.togglePlayback() }.keyboardShortcut(.space, modifiers: [])
                Button("Next song") { music.next() }.keyboardShortcut(.rightArrow, modifiers: .command)
                Button("Previous song") { music.previous() }.keyboardShortcut(.leftArrow, modifiers: .command)
                Divider()
                Button("Account & player window") { music.showBrowser() }
            }
        }
        MenuBarExtra("YT Music", systemImage: "waveform") {
            MenuBarPlayerView().environment(music)
        }.menuBarExtraStyle(.window)
        Settings {
            CacheSettingsView().environment(music)
        }
    }
}

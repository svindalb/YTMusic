import AppKit
import MediaPlayer

@MainActor
final class SystemMediaControls {
    private weak var music: MusicSession?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var artworkTask: Task<Void, Never>?
    private var artworkKey = ""
    private var artwork: MPMediaItemArtwork?

    func start(_ music: MusicSession) {
        guard targets.isEmpty else { return }
        self.music = music
        let commands = MPRemoteCommandCenter.shared()
        register(commands.playCommand) { $0.setPlaying(true) }
        register(commands.pauseCommand) { $0.setPlaying(false) }
        register(commands.togglePlayPauseCommand) { $0.togglePlayback() }
        register(commands.nextTrackCommand) { $0.next() }
        register(commands.previousTrackCommand) { $0.previous() }
        let seek = commands.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            let position = event.positionTime
            Task { @MainActor [weak self] in self?.music?.seek(position) }
            return .success
        }
        targets.append((commands.changePlaybackPositionCommand, seek))
        update()
    }

    private func register(_ command: MPRemoteCommand, action: @escaping @MainActor (MusicSession) -> Void) {
        let target = command.addTarget { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let music = self?.music, music.ready, !music.now.videoID.isEmpty else { return }
                action(music)
            }
            return .success
        }
        targets.append((command, target))
    }

    func update() {
        guard let music else { return }
        let active = music.ready && !music.now.videoID.isEmpty
        for (command, _) in targets { command.isEnabled = active }
        MPRemoteCommandCenter.shared().changePlaybackPositionCommand.isEnabled = active && music.now.duration > 0
        let center = MPNowPlayingInfoCenter.default()
        guard active else {
            artworkTask?.cancel(); artworkKey = ""; artwork = nil
            center.nowPlayingInfo = nil; center.playbackState = .stopped
            return
        }
        let now = music.now
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: now.title,
            MPMediaItemPropertyArtist: now.artist,
            MPMediaItemPropertyPlaybackDuration: now.duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: now.elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: now.isPlaying ? 1.0 : 0.0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyExternalContentIdentifier: now.videoID
        ]
        let key = now.videoID + "|" + (now.artwork?.absoluteString ?? "")
        if artworkKey != key {
            artworkTask?.cancel(); artworkKey = key; artwork = nil
            let candidates = ArtworkResolution.candidates(for: now.artwork, pixels: 512)
            artworkTask = Task { [weak self] in
                guard let data = await ArtworkLoader.shared.data(for: candidates),
                      let image = NSImage(data: data), let self,
                      !Task.isCancelled, self.artworkKey == key else { return }
                self.artwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
                self.update()
            }
        }
        if let artwork { info[MPMediaItemPropertyArtwork] = artwork }
        center.nowPlayingInfo = info
        center.playbackState = now.isPlaying ? .playing : .paused
    }
}

import SwiftUI
import ImageIO

struct AtmosphereRGB: Equatable, Sendable {
    var red: Double
    var green: Double
    var blue: Double
    var color: Color { Color(red: red, green: green, blue: blue) }
}
struct ArtworkPalette: Equatable, Sendable {
    var primary: AtmosphereRGB
    var secondary: AtmosphereRGB
}

enum ArtworkPaletteExtractor {
    nonisolated static func extract(_ data: Data) -> ArtworkPalette? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: 32,
                kCGImageSourceCreateThumbnailWithTransform: true
              ] as CFDictionary) else { return nil }
        let width = image.width, height = image.height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let rendered = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height,
                bitsPerComponent: 8, bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue) else { return false }
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard rendered else { return nil }
        var buckets: [Int: (score: Double, red: Double, green: Double, blue: Double, count: Int)] = [:]
        for offset in stride(from: 0, to: pixels.count, by: 4) where pixels[offset + 3] > 160 {
            let r = Double(pixels[offset]) / 255, g = Double(pixels[offset + 1]) / 255, b = Double(pixels[offset + 2]) / 255
            let high = max(r, g, b), low = min(r, g, b)
            guard high > 0.12, low < 0.94 else { continue }
            let saturation = high == 0 ? 0 : (high - low) / high
            let score = 0.15 + saturation * 1.8 + high * 0.3
            let key = Int(r * 7) * 64 + Int(g * 7) * 8 + Int(b * 7)
            var bucket = buckets[key] ?? (0, 0, 0, 0, 0)
            bucket.score += score; bucket.red += r; bucket.green += g; bucket.blue += b; bucket.count += 1
            buckets[key] = bucket
        }
        let ordered = buckets.values.sorted { $0.score > $1.score }.map {
            AtmosphereRGB(red: $0.red / Double($0.count), green: $0.green / Double($0.count), blue: $0.blue / Double($0.count))
        }
        guard let primary = ordered.first else { return nil }
        let secondary = ordered.dropFirst().first { candidate in
            abs(candidate.red - primary.red) + abs(candidate.green - primary.green) + abs(candidate.blue - primary.blue) > 0.5
        } ?? AtmosphereRGB(red: primary.blue * 0.65, green: primary.red * 0.65, blue: primary.green * 0.65)
        return ArtworkPalette(primary: primary, secondary: secondary)
    }
}

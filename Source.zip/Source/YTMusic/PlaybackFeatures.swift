import SwiftUI

enum MusicRepeatMode: String, CaseIterable {
    case off, all, one
    var next: Self { switch self { case .off: .all; case .all: .one; case .one: .off } }
    var symbol: String { self == .one ? "repeat.1" : "repeat" }
    var label: String { switch self { case .off: "Repeat off"; case .all: "Repeat queue"; case .one: "Repeat song" } }
}

struct SongLyrics {
    let text: String
    let source: String
}

enum LyricsParser {
    static func browseID(in response: [String: Any]) -> String? {
        MusicParser.dictionaries(response, key: "tabRenderer").compactMap { tab -> String? in
            guard tab["unselectable"] as? Bool != true,
                  let id = MusicParser.firstString(tab["endpoint"] ?? [:], key: "browseId"),
                  id.hasPrefix("MPLY") else { return nil }
            return id
        }.first
    }
    static func parse(_ response: [String: Any]) -> SongLyrics? {
        for shelf in MusicParser.dictionaries(response, key: "musicDescriptionShelfRenderer") {
            let text = MusicParser.text(shelf["description"]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { return SongLyrics(text: text, source: MusicParser.text(shelf["footer"])) }
        }
        return nil
    }
}

struct ShuffleButton: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        Button { music.setShuffle(!music.shuffle) } label: {
            Image(systemName: "shuffle").foregroundStyle(music.shuffle ? MusicStyle.red : .white.opacity(0.65))
        }.buttonStyle(TransportButtonStyle(compact: true))
            .help(music.shuffle ? "Shuffle on" : "Shuffle off")
            .accessibilityLabel(music.shuffle ? "Shuffle on" : "Shuffle off")
            .accessibilityAddTraits(music.shuffle ? .isSelected : [])
    }
}
struct RepeatButton: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        Button { music.setRepeat(music.repeatMode.next) } label: {
            Image(systemName: music.repeatMode.symbol).foregroundStyle(music.repeatMode == .off ? .white.opacity(0.65) : MusicStyle.red)
        }.buttonStyle(TransportButtonStyle(compact: true)).help(music.repeatMode.label)
            .accessibilityLabel(music.repeatMode.label)
    }
}
struct LyricsButton: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        Button { music.showLyrics = true } label: { Image(systemName: "quote.bubble") }
            .buttonStyle(TransportButtonStyle(compact: true)).help("Lyrics").accessibilityLabel("Lyrics")
            .disabled(music.now.videoID.isEmpty)
    }
}

struct LyricsView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text("Lyrics").font(.title2.bold())
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction)
            }
            HStack(spacing: 12) {
                ArtworkView(url: music.now.artwork, size: 52, radius: 9)
                VStack(alignment: .leading, spacing: 5) {
                    Text(music.now.title).font(.headline).lineLimit(2)
                    Text(music.now.artist).foregroundStyle(.secondary).lineLimit(1)
                }
            }
            Divider()
            if music.loadingLyrics {
                ProgressView("Loading lyrics…").frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let lyrics = music.lyrics {
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        Text(lyrics.text).font(.system(size: 21, weight: .medium, design: .rounded))
                            .lineSpacing(10).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                        if !lyrics.source.isEmpty { Text(lyrics.source).font(.caption).foregroundStyle(.secondary) }
                    }.padding(.vertical, 8).padding(.trailing, 12)
                }
            } else {
                ContentUnavailableView {
                    Label(music.lyricsError == nil ? "No lyrics available" : "Couldn’t load lyrics", systemImage: "quote.bubble")
                } description: { Text(music.lyricsError ?? "YouTube Music doesn’t provide lyrics for this song.") } actions: {
                    if music.lyricsError != nil { Button("Try again") { Task { await music.loadLyrics() } } }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }.padding(24).frame(width: 490, height: 620)
            .background(MusicBackdrop()).preferredColorScheme(.dark).tint(MusicStyle.red)
            .task(id: music.now.videoID) { await music.loadLyrics() }
    }
}

struct MenuBarPlayerView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.openWindow) private var openWindow
    private var hasTrack: Bool { !music.now.videoID.isEmpty }
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 13) {
                ArtworkView(url: music.now.artwork, size: 64, radius: 12)
                VStack(alignment: .leading, spacing: 6) {
                    Text(music.now.title).font(.headline).lineLimit(2)
                    Text(music.now.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
            HStack(spacing: 19) {
                ShuffleButton()
                Button { music.previous() } label: { Image(systemName: "backward.end.fill") }.buttonStyle(TransportButtonStyle()).help("Previous song")
                Button { music.togglePlayback() } label: { Image(systemName: music.now.isPlaying ? "pause.fill" : "play.fill") }
                    .buttonStyle(TransportButtonStyle(prominent: true)).accessibilityLabel(music.now.isPlaying ? "Pause" : "Play")
                Button { music.next() } label: { Image(systemName: "forward.end.fill") }.buttonStyle(TransportButtonStyle()).help("Next song")
                RepeatButton()
            }.disabled(!hasTrack)
            VStack(spacing: 4) {
                Slider(value: Binding(get: { music.now.elapsed }, set: { music.seek($0) }), in: 0...max(1, music.now.duration))
                    .controlSize(.mini).disabled(music.now.duration <= 0).accessibilityLabel("Playback position")
                HStack { Text(music.now.elapsed.musicTime); Spacer(); Text(music.now.duration.musicTime) }
                    .font(.caption2).monospacedDigit().foregroundStyle(.secondary)
            }
            HStack {
                Image(systemName: music.volume == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill").foregroundStyle(.secondary)
                Slider(value: Binding(get: { music.volume }, set: { music.setVolume($0) }), in: 0...1)
                    .controlSize(.mini).accessibilityLabel("App volume")
            }
            Divider()
            HStack {
                Button("Open YT Music") { openWindow(id: "main"); NSApp.activate() }
                Spacer()
                Button("Quit") { NSApp.terminate(nil) }
            }.buttonStyle(.plain).font(.caption)
        }.padding(20).frame(width: 330).background(MusicBackdrop())
            .preferredColorScheme(.dark).tint(MusicStyle.red).task { music.start() }
    }
}

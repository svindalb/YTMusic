import Foundation
import Observation
import CryptoKit

@MainActor @Observable
final class ListeningTools {
    var sheet: ListeningToolSheet?
    var playlistDestinationSong: MusicItem?
    private(set) var heldPlace: HeldPlace?
    private(set) var trails: [RadioTrail] = []
    private(set) var discoveries: [MusicItem] = []
    private(set) var activeTrailID: UUID?
    private(set) var storageError: String?
    private(set) var restoring = false
    private(set) var holding = false
    var restoreMessage: String?
    private(set) var palette: ArtworkPalette?
    private(set) var atmosphereEnabled = UserDefaults.standard.object(forKey: "artworkAtmosphereEnabled") as? Bool ?? true
    private(set) var atmosphereIntensity = min(1, max(0, UserDefaults.standard.object(forKey: "artworkAtmosphereIntensity") as? Double ?? 0.45))
    @ObservationIgnored private var storageURL: URL?
    @ObservationIgnored private var revision = UUID()
    @ObservationIgnored private var paletteTask: Task<Void, Never>?
    @ObservationIgnored private var artworkURL: URL?

    var activePalette: ArtworkPalette? { atmosphereEnabled ? palette : nil }
    var hasDiskStorage: Bool { storageURL != nil }

    func connect(_ identity: MusicAccountIdentity, directory: URL? = nil) {
        reset()
        // Session slot numbers alone are not account identities. Without a stable
        // identity, keep these features in memory rather than mix two accounts.
        guard !identity.dataSyncID.isEmpty || !identity.delegated.isEmpty else { return }
        let key = [identity.slot, identity.delegated, identity.dataSyncID].joined(separator: "|")
        let digest = SHA256.hash(data: Data(key.utf8)).map { String(format: "%02x", $0) }.joined()
        let folder = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("YTMusic/Listening", isDirectory: true)
        storageURL = folder.appendingPathComponent(digest + ".json")
        guard let url = storageURL, FileManager.default.fileExists(atPath: url.path) else { return }
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            guard ((attributes[.size] as? NSNumber)?.intValue ?? 0) <= 8 * 1024 * 1024 else { throw CocoaError(.fileReadCorruptFile) }
            let data = try Data(contentsOf: url)
            guard data.count <= 8 * 1024 * 1024 else { throw CocoaError(.fileReadCorruptFile) }
            let stored = try JSONDecoder().decode(LocalListeningData.self, from: data).withoutAccountHints()
            guard stored.version == 1 else { throw CocoaError(.fileReadCorruptFile) }
            heldPlace = stored.heldPlace
            if heldPlace?.song.videoID == nil { heldPlace = nil }
            if let held = heldPlace, !held.elapsed.isFinite || held.elapsed < 0 { heldPlace = nil }
            if var held = heldPlace { held.queue = Array(held.queue.prefix(1000)); heldPlace = held }
            trails = Array(stored.trails.prefix(12)).map { trail in var copy = trail; copy.visits = Array(copy.visits.suffix(100)); return copy }
            discoveries = Array(stored.discoveries.prefix(80))
        } catch { storageError = "Couldn’t read your saved listening tools. New changes can still be saved." }
    }

    func reset() {
        revision = UUID(); paletteTask?.cancel(); artworkURL = nil; palette = nil
        heldPlace = nil; trails = []; discoveries = []; activeTrailID = nil
        storageURL = nil; storageError = nil; restoring = false; holding = false; restoreMessage = nil
        sheet = nil; playlistDestinationSong = nil
    }

    private func persist() {
        guard let url = storageURL else { return }
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(LocalListeningData(heldPlace: heldPlace, trails: trails, discoveries: discoveries).withoutAccountHints())
            guard data.count <= 8 * 1024 * 1024 else { throw CocoaError(.fileWriteOutOfSpace) }
            try data.write(to: url, options: .atomic)
            storageError = nil
        } catch { storageError = "Couldn’t save listening tools on this Mac. Your current session still has them." }
    }

    func setHolding(_ active: Bool) { holding = active }
    func hold(_ place: HeldPlace) { heldPlace = place; restoreMessage = nil; persist() }
    func clearPlace() { heldPlace = nil; restoreMessage = nil; persist() }
    func setRestoring(_ active: Bool, message: String? = nil) { restoring = active; restoreMessage = message }

    func beginRadio(seed: MusicItem, playlistID: String) {
        if let activeTrailID, trails.contains(where: { $0.id == activeTrailID && $0.playlistID == playlistID }) { return }
        let trail = RadioTrail(seed: seed, playlistID: playlistID)
        trails.insert(trail, at: 0); trails = Array(trails.prefix(12)); activeTrailID = trail.id; persist()
    }
    func endRadio() { activeTrailID = nil }
    func resumeTrail(_ id: UUID?) { activeTrailID = id.flatMap { id in trails.contains(where: { $0.id == id }) ? id : nil } }
    func record(_ song: MusicItem) {
        guard let id = song.videoID, let index = trails.firstIndex(where: { $0.id == activeTrailID }) else { return }
        var trail = trails[index]
        if trail.seed.videoID == song.videoID { trail.seed = PlaybackMetadata.merge(song, with: trail.seed) }
        if let last = trail.visits.last, last.song.videoID == id {
            let updated = PlaybackMetadata.merge(song, with: last.song)
            if updated != last.song || trail.seed != trails[index].seed {
                trail.visits[trail.visits.count - 1].song = updated
                trails[index] = trail
                persist()
            }
            return
        }
        trail.visits.append(RadioVisit(song: song))
        trail.visits = Array(trail.visits.suffix(100))
        trails[index] = trail
        persist()
    }
    func isDiscovered(_ song: MusicItem) -> Bool { discoveries.contains { $0.videoID == song.videoID } }
    func toggleDiscovery(_ song: MusicItem) {
        guard let id = song.videoID else { return }
        if discoveries.contains(where: { $0.videoID == id }) { discoveries.removeAll { $0.videoID == id } }
        else { discoveries.insert(song, at: 0); discoveries = Array(discoveries.prefix(80)) }
        persist()
    }
    func clearTrails() { trails = []; activeTrailID = nil; persist() }

    func configureAtmosphere(enabled: Bool? = nil, intensity: Double? = nil) {
        if let enabled { atmosphereEnabled = enabled; UserDefaults.standard.set(enabled, forKey: "artworkAtmosphereEnabled") }
        if let intensity, intensity.isFinite {
            atmosphereIntensity = min(1, max(0, intensity))
            UserDefaults.standard.set(atmosphereIntensity, forKey: "artworkAtmosphereIntensity")
        }
        if !atmosphereEnabled { paletteTask?.cancel() }
        else if enabled == true { updateArtwork(artworkURL, force: true) }
    }
    func updateArtwork(_ url: URL?, force: Bool = false) {
        guard force || url != artworkURL else { return }
        artworkURL = url; paletteTask?.cancel()
        guard atmosphereEnabled, let url else { if url == nil { palette = nil }; return }
        let revision = revision
        let candidates = ArtworkResolution.candidates(for: url, pixels: 256)
        paletteTask = Task { [weak self] in
            let data = await ArtworkLoader.shared.data(for: candidates)
            guard !Task.isCancelled else { return }
            guard let data else {
                if let self, self.revision == revision, self.artworkURL == url { self.palette = nil }
                return
            }
            let result = await Task.detached(priority: .utility) { ArtworkPaletteExtractor.extract(data) }.value
            guard let self, !Task.isCancelled, self.revision == revision, self.artworkURL == url else { return }
            self.palette = result
        }
    }
}

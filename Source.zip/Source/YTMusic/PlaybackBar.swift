import SwiftUI

struct PlaybackBar: View {
    var expand: () -> Void = {}
    @Environment(MusicSession.self) private var music
    @State private var seeking = false
    @State private var seekPosition: Double = 0
    @State private var previousVolume: Double = 0.7
    @State private var artworkHovered = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var hasTrack: Bool { !music.now.videoID.isEmpty }
    var body: some View {
        HStack(spacing: 24) {
            HStack(spacing: 12) {
                Button { music.openCurrentSong() } label: {
                    ArtworkView(url: music.now.artwork, size: 57, radius: 11)
                }.buttonStyle(.plain).disabled(!hasTrack)
                    .help("Go to song")
                    .overlay { RoundedRectangle(cornerRadius: 11).strokeBorder(MusicStyle.red.opacity(artworkHovered && hasTrack ? 0.35 : 0), lineWidth: 1) }
                    .shadow(color: MusicStyle.red.opacity(artworkHovered && hasTrack ? 0.42 : 0), radius: 9)
                    .scaleEffect(!reduceMotion && artworkHovered && hasTrack ? 1.08 : 1)
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: artworkHovered)
                    .onHover { artworkHovered = $0 }
                    .accessibilityLabel("Go to song")
                    .accessibilityIdentifier("now-playing-artwork")
                VStack(alignment: .leading, spacing: 6) {
                    Text(music.now.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                    Text(music.now.artist).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 0)
                if hasTrack {
                    SongLikeButton(videoID: music.now.videoID)
                    EqualizerView(active: music.now.isPlaying)
                }
            }.frame(minWidth: 170, idealWidth: 250, maxWidth: 320)
            VStack(spacing: 7) {
                HStack(spacing: 16) {
                    ShuffleButton()
                    Button { music.previous() } label: { Image(systemName: "backward.end.fill").font(.system(size: 17)) }
                        .help("Previous song").buttonStyle(TransportButtonStyle())
                    Button { music.togglePlayback() } label: {
                        Image(systemName: music.now.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 17, weight: .bold)).contentTransition(.identity)
                    }
                    .buttonStyle(TransportButtonStyle(prominent: true))
                    .accessibilityIdentifier("transport-play-pause")
                    .help(music.now.isPlaying ? "Pause" : "Play")
                    Button { music.next() } label: { Image(systemName: "forward.end.fill").font(.system(size: 17)) }.help("Next song").buttonStyle(TransportButtonStyle())
                    RepeatButton()
                }.disabled(!hasTrack)
                HStack(spacing: 10) {
                    Text((seeking ? seekPosition : music.now.elapsed).musicTime).frame(width: 42, alignment: .trailing)
                    Slider(value: Binding(get: { seeking ? seekPosition : music.now.elapsed }, set: { seekPosition = $0; if !seeking { music.seek($0) } }),
                        in: 0...max(1, music.now.duration), onEditingChanged: { editing in
                            if editing { seekPosition = music.now.elapsed; seeking = true }
                            else { music.seek(seekPosition); seeking = false }
                        })
                        .controlSize(.mini).disabled(music.now.duration <= 0).accessibilityLabel("Playback position")
                    Text(music.now.duration.musicTime).frame(width: 42, alignment: .leading)
                }.font(.system(size: 10)).monospacedDigit().foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity)
            HStack(spacing: 9) {
                LyricsButton()
                Button {
                    if music.volume > 0 { previousVolume = music.volume; music.setVolume(0) }
                    else { music.setVolume(previousVolume > 0 ? previousVolume : 0.7) }
                } label: { Image(systemName: music.volume == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill").font(.system(size: 13)) }
                    .buttonStyle(TransportButtonStyle(compact: true)).foregroundStyle(.secondary).help("Mute app audio")
                Slider(value: Binding(get: { music.volume }, set: { music.setVolume($0) }), in: 0...1)
                    .controlSize(.mini).accessibilityLabel("App volume")
                Text("\(Int(music.volume * 100))%")
                    .font(.system(size: 10)).monospacedDigit().foregroundStyle(.secondary).frame(width: 32)
            }.frame(width: 200)
        }
        .padding(.horizontal, 20).padding(.vertical, 13)
        .background {
            Button(action: expand) {
                RoundedRectangle(cornerRadius: 20).fill(Color.clear)
                    .contentShape(RoundedRectangle(cornerRadius: 20))
            }
            .buttonStyle(.plain).disabled(!hasTrack)
            .accessibilityLabel("Expand Now Playing")
            .accessibilityIdentifier("expand-now-playing")
            .help(hasTrack ? "Expand Now Playing" : "Choose a song to open Now Playing")
        }
        .modifier(MusicSurface(radius: 20))
        .overlay(alignment: .top) {
            LinearGradient(colors: [.clear, MusicStyle.red.opacity(0.38), .purple.opacity(0.20), .clear], startPoint: .leading, endPoint: .trailing)
                .frame(height: 1).padding(.horizontal, 26)
        }
    }
}


struct TransportButtonStyle: ButtonStyle {
    var prominent = false
    var compact = false
    func makeBody(configuration: Configuration) -> some View {
        TransportButtonBody(configuration: configuration, prominent: prominent, compact: compact)
    }

    private struct TransportButtonBody: View {
        let configuration: Configuration
        let prominent: Bool
        let compact: Bool
        @Environment(\.isEnabled) private var enabled
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        @State private var hovering = false
        private var lit: Bool { hovering && enabled }
        private var size: CGFloat { prominent ? 40 : compact ? 26 : 32 }
        var body: some View {
            configuration.label
                .frame(width: size, height: size)
                .foregroundStyle(.white.opacity(enabled ? 1 : 0.35))
                .background {
                    Circle().fill(prominent ? AnyShapeStyle(MusicStyle.gradient) : AnyShapeStyle(.white.opacity(lit ? 0.065 : 0)))
                }
                .overlay { Circle().strokeBorder(MusicStyle.red.opacity(lit ? 0.35 : 0), lineWidth: 1) }
                .shadow(color: MusicStyle.red.opacity(lit ? (prominent ? 0.6 : 0.42) : 0), radius: prominent ? 12 : 9)
                .scaleEffect(reduceMotion ? 1 : configuration.isPressed ? 0.95 : lit ? 1.08 : 1)
                .contentShape(Circle())
                .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: lit)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.08), value: configuration.isPressed)
                .onHover { hovering = $0 }
        }
    }
}

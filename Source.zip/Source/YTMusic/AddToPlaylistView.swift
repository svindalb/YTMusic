import SwiftUI

struct AddToPlaylistView: View {
    let song: MusicItem
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var search = ""
    @State private var working = false
    @State private var error: String?
    @State private var writable: [MusicItem] = []
    @State private var loadingDestinations = false
    @State private var destinationError: String?
    private var destinations: [MusicItem] {
        writable.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Add to playlist").font(.title2.bold())
                    Text(song.title).font(.callout).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Button("Done") { dismiss() }.disabled(working).keyboardShortcut(.cancelAction)
            }
            HStack(spacing: 10) {
                TextField("New playlist name", text: $name).textFieldStyle(.roundedBorder)
                    .onSubmit { create() }
                Button("Create & add", systemImage: "plus") { create() }
                    .disabled(working || loadingDestinations || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            Text("New playlists are private.").font(.caption).foregroundStyle(.secondary)
            Divider()
            TextField("Find a playlist", text: $search).textFieldStyle(.roundedBorder)
            List(destinations) { playlist in
                Button { perform { try await music.addSong(song, to: playlist.playlistID!) } } label: {
                    HStack(spacing: 12) {
                        ArtworkView(url: music.playlistArtwork(for: playlist), size: 36, radius: 7)
                        Text(playlist.title).lineLimit(2)
                        Spacer()
                        Image(systemName: "plus").foregroundStyle(MusicStyle.red)
                    }.padding(.vertical, 4).contentShape(Rectangle())
                }.buttonStyle(.plain).disabled(working)
            }.listStyle(.plain).frame(minHeight: 240)
                .overlay {
                    if destinations.isEmpty && !loadingDestinations {
                        Text(search.isEmpty ? "Create a playlist above to get started." : "No matching playlists.")
                            .foregroundStyle(.secondary)
                    }
                }
            if working || loadingDestinations {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text(working ? "Updating playlist…" : "Loading playlists…").foregroundStyle(.secondary)
                }
            }
            if let message = error ?? destinationError {
                Text(message).font(.callout).foregroundStyle(MusicStyle.red)
                if destinationError != nil {
                    Button("Retry loading playlists") { Task { await loadDestinations() } }.disabled(working)
                }
            }
        }
        .padding(24).frame(width: 480, height: 560)
        .background { MusicBackdrop() }
        .interactiveDismissDisabled(working)
        .task(id: music.accountGeneration) { await loadDestinations() }
    }

    private func loadDestinations() async {
        let generation = music.accountGeneration
        loadingDestinations = true
        destinationError = nil
        defer { if music.accountGeneration == generation { loadingDestinations = false } }
        do {
            let items = try await music.writablePlaylists(for: song)
            guard !Task.isCancelled, music.accountGeneration == generation else { return }
            writable = items
        } catch is CancellationError { }
        catch { if music.accountGeneration == generation { destinationError = "Couldn’t load writable playlists. Try again." } }
    }

    private func create() {
        guard !working, !loadingDestinations, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        perform { try await music.createPlaylistAndAdd(song, title: name) }
    }

    private func perform(_ operation: @escaping @MainActor () async throws -> Void) {
        guard !working else { return }
        let generation = music.accountGeneration
        working = true
        error = nil
        Task { @MainActor in
            defer { if music.accountGeneration == generation { working = false } }
            do {
                guard music.accountGeneration == generation else { return }
                try await operation()
                if music.accountGeneration == generation { dismiss() }
            } catch is CancellationError { }
            catch { if music.accountGeneration == generation { self.error = error.localizedDescription } }
        }
    }
}

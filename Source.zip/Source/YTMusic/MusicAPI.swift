import Foundation
import CryptoKit
import WebKit

@MainActor
final class MusicAPI {
    var config: [String: Any] = [:]
    let store: WKWebsiteDataStore
    let userAgent: String
    private var sessionGeneration = UUID()
    private var podcastRoute: MusicRoute?
    private let session: URLSession

    init(store: WKWebsiteDataStore, userAgent: String) {
        self.store = store
        self.userAgent = userAgent
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 30
        session = URLSession(configuration: configuration, delegate: NoRedirects(), delegateQueue: nil)
    }

    func resetSession() {
        sessionGeneration = UUID()
        config = [:]
        podcastRoute = nil
    }

    func request(_ endpoint: String, body: [String: Any], allowNotFound: Bool = false) async throws -> [String: Any] {
        let generation = sessionGeneration
        let snapshot = config
        guard let context = snapshot["context"] as? [String: Any], let client = context["client"] as? [String: Any],
              let version = client["clientVersion"] as? String else {
            throw ProbeError(message: "Sign in to YouTube Music to continue.")
        }
        let cookies = await store.httpCookieStore.allCookies().filter {
            let domain = $0.domain.trimmingCharacters(in: CharacterSet(charactersIn: "."))
            return (domain == "youtube.com" || domain == "music.youtube.com")
                && "/youtubei/v1/\(endpoint)".hasPrefix($0.path)
                && ($0.expiresDate == nil || $0.expiresDate! > Date())
        }
        guard sessionGeneration == generation else { throw CancellationError() }
        guard let signing = cookies.first(where: { $0.name == "SAPISID" })
                ?? cookies.first(where: { $0.name == "__Secure-3PAPISID" }) else {
            throw ProbeError(message: "Your session has expired. Please sign in again.")
        }
        let origin = "https://music.youtube.com"
        var url = URLComponents(string: origin + "/youtubei/v1/" + endpoint)!
        url.queryItems = [URLQueryItem(name: "prettyPrint", value: "false")]
        if let key = snapshot["apiKey"] as? String { url.queryItems?.append(.init(name: "key", value: key)) }
        var request = URLRequest(url: url.url!)
        request.httpMethod = "POST"
        let stamp = String(Int(Date().timeIntervalSince1970))
        let hash = Insecure.SHA1.hash(data: Data("\(stamp) \(signing.value) \(origin)".utf8))
            .map { String(format: "%02x", $0) }.joined()
        var headers = ["Content-Type": "application/json", "Origin": origin, "Referer": origin + "/",
            "User-Agent": userAgent, "X-Origin": origin, "X-YouTube-Client-Name": "67",
            "X-YouTube-Client-Version": version, "X-Goog-AuthUser": String(describing: snapshot["authUser"] ?? 0),
            "Authorization": "SAPISIDHASH \(stamp)_\(hash)",
            "Cookie": cookies.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")]
        if let visitor = client["visitorData"] as? String { headers["X-Goog-Visitor-Id"] = visitor }
        if let delegated = snapshot["delegatedSession"] as? String, !delegated.isEmpty { headers["X-Goog-PageId"] = delegated }
        request.allHTTPHeaderFields = headers
        var payload = body
        payload["context"] = context
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard sessionGeneration == generation else { throw CancellationError() }
        if allowNotFound, (response as? HTTPURLResponse)?.statusCode == 404 { return [:] }
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw ProbeError(message: "YouTube Music returned HTTP \((response as? HTTPURLResponse)?.statusCode ?? 0). Try refreshing or signing in again.")
        }
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any], json["error"] == nil else {
            throw ProbeError(message: "YouTube Music could not load this section for this account.")
        }
        return json
    }

    func writablePlaylists(videoID: String) async throws -> [MusicItem] {
        let generation = sessionGeneration
        var response = try await request("playlist/get_add_to_playlist", body: ["videoIds": [videoID]])
        var result: [MusicItem] = []
        var seenIDs = Set<String>()
        var seenTokens = Set<String>()
        while true {
            guard sessionGeneration == generation else { throw CancellationError() }
            for item in MusicParser.addToPlaylistOptions(response) where seenIDs.insert(item.id).inserted {
                result.append(item)
            }
            guard let token = MusicParser.dictionaries(response, key: "continuationCommand").first?["token"] as? String else { break }
            guard seenTokens.insert(token).inserted else { throw ProbeError(message: "Couldn’t finish loading writable playlists. Try again.") }
            response = try await request("browse", body: ["continuation": token])
        }
        return result
    }

    func playlistContains(_ playlistID: String, videoID: String) async throws -> Bool {
        let generation = sessionGeneration
        let route = MusicRoute(title: "Playlist", browseID: "VL" + playlistID)
        var token: String?
        var seen = Set<String>()
        repeat {
            let result = try await page(route, continuation: token)
            guard sessionGeneration == generation else { throw CancellationError() }
            if result.items.contains(where: { $0.videoID == videoID }) { return true }
            token = result.continuation
            if let token, !seen.insert(token).inserted {
                throw ProbeError(message: "Couldn’t check the entire playlist. Try again before adding the song.")
            }
        } while token != nil
        return false
    }

    func editPlaylist(_ playlistID: String, action: [String: Any]) async throws {
        try await editPlaylist(playlistID, actions: [action])
    }

    func editPlaylist(_ playlistID: String, actions: [[String: Any]]) async throws {
        guard !actions.isEmpty else { return }
        let response = try await request("browse/edit_playlist", body: ["playlistId": playlistID, "actions": actions])
        guard response["status"] as? String == "STATUS_SUCCEEDED" else {
            throw ProbeError(message: "Couldn’t change this playlist. It may be read-only, or the song may already be there.")
        }
    }

    func createPlaylist(title: String, videoID: String) async throws -> String {
        let title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, !title.contains("<"), !title.contains(">") else {
            throw ProbeError(message: "Enter a playlist name without < or >.")
        }
        let response = try await request("playlist/create", body: ["title": title, "description": "", "privacyStatus": "PRIVATE", "videoIds": [videoID]])
        guard let id = response["playlistId"] as? String, !id.isEmpty else {
            throw ProbeError(message: "YouTube Music couldn’t create the playlist. Open Account if it needs your attention.")
        }
        return id
    }

    func songLiked(_ videoID: String) async throws -> Bool? {
        let response = try await request("next", body: ["videoId": videoID, "isAudioOnly": true])
        for track in MusicParser.dictionaries(response, key: "playlistPanelVideoRenderer")
            where track["videoId"] as? String == videoID {
            if let liked = MusicParser.liked(track) { return liked }
        }
        return nil
    }

    func setSongLiked(_ videoID: String, liked: Bool) async throws {
        let response = try await request(liked ? "like/like" : "like/removelike", body: ["target": ["videoId": videoID]])
        guard MusicParser.dictionaries(response, key: "showEngagementPanelEndpoint").isEmpty else {
            throw ProbeError(message: "Open Account to complete YouTube Music’s requested interaction.")
        }
    }

    func page(_ route: MusicRoute, continuation: String? = nil) async throws -> MusicPage {
        if let song = route.song {
            var detail = MusicPage(title: song.title, subtitle: song.subtitle, artwork: song.artwork)
            detail.song = song
            return detail
        }
        // Podcasts is a Home chip with server-provided params, not a stable FE page.
        if route.browseID == "FEmusic_podcasts" {
            if podcastRoute == nil { _ = try await page(.init(title: "Home", browseID: "FEmusic_home")) }
            guard let discovered = podcastRoute else {
                throw ProbeError(message: "YouTube Music does not expose Podcasts for this account right now.")
            }
            var result = try await page(discovered, continuation: continuation)
            result.title = "Podcasts"
            return result
        }
        var body: [String: Any] = [:]
        let endpoint = route.search == nil ? "browse" : "search"
        if let continuation { body["continuation"] = continuation }
        else if let query = route.search { body["query"] = query }
        else { body["browseId"] = route.browseID }
        if let params = route.params { body["params"] = params }
        let json = try await request(endpoint, body: body)
        var page = MusicParser.page(json, fallback: route.title, preservePlaylistEntries: route.browseID.hasPrefix("VL"))
        if route.browseID == "FEmusic_home", route.params == nil {
            podcastRoute = page.filters.first { $0.title.lowercased().contains("podcast") }
        }
        if route.browseID.hasPrefix("VL") {
            page.playlistID = String(route.browseID.dropFirst(2))
            var position = 0
            for shelfIndex in page.shelves.indices where page.shelves[shelfIndex].isList {
                for itemIndex in page.shelves[shelfIndex].items.indices {
                    page.shelves[shelfIndex].items[itemIndex].playlistID = page.playlistID
                    page.shelves[shelfIndex].items[itemIndex].playlistPosition = position
                    position += 1
                }
            }
        }
        return page
    }
}

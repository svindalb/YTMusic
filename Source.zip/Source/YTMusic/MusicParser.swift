import Foundation

// Parse the service-provided shelves and navigation endpoints instead of hardcoding catalog data.
enum MusicParser {
    static func text(_ value: Any?) -> String {
        guard let dict = value as? [String: Any] else { return "" }
        if let simple = dict["simpleText"] as? String { return simple }
        return (dict["runs"] as? [[String: Any]] ?? []).compactMap { $0["text"] as? String }.joined()
    }

    static func dictionaries(_ value: Any, key: String) -> [[String: Any]] {
        var found: [[String: Any]] = []
        func walk(_ object: Any) {
            if let dict = object as? [String: Any] {
                if let result = dict[key] as? [String: Any] { found.append(result) }
                for name in dict.keys.sorted() where name != key { if let child = dict[name] { walk(child) } }
            } else if let array = object as? [Any] { array.forEach(walk) }
        }
        walk(value)
        return found
    }

    static func firstString(_ value: Any, key: String) -> String? {
        if let dict = value as? [String: Any] {
            if let result = dict[key] as? String { return result }
            for name in dict.keys.sorted() { if let child = dict[name], let result = firstString(child, key: key) { return result } }
        } else if let array = value as? [Any] {
            for child in array { if let result = firstString(child, key: key) { return result } }
        }
        return nil
    }

    static func artwork(_ value: Any) -> URL? {
        func candidates(_ value: Any) -> [[String: Any]] {
            if let dict = value as? [String: Any] {
                var images = dict["thumbnails"] as? [[String: Any]] ?? []
                for name in dict.keys.sorted() where name != "thumbnails" {
                    if let child = dict[name] { images.append(contentsOf: candidates(child)) }
                }
                return images
            } else if let array = value as? [Any] { return array.flatMap(candidates) }
            return []
        }
        func resolution(_ image: [String: Any]) -> Int {
            let width = image["width"] as? Int ?? 0
            return min(width, image["height"] as? Int ?? width)
        }
        let images = candidates(value).filter { $0["url"] as? String != nil }
        guard let path = images.max(by: { resolution($0) < resolution($1) })?["url"] as? String else { return nil }
        return URL(string: path.hasPrefix("//") ? "https:" + path : path)
    }

    static func route(_ endpoint: Any?, title: String) -> MusicRoute? {
        guard let endpoint else { return nil }
        if let browse = dictionaries(endpoint, key: "browseEndpoint").first,
           let id = browse["browseId"] as? String {
            return .init(title: title, browseID: id, params: browse["params"] as? String)
        }
        if let search = dictionaries(endpoint, key: "searchEndpoint").first,
           let query = search["query"] as? String {
            return .init(title: title, browseID: "search", params: search["params"] as? String, search: query)
        }
        return nil
    }

    static func liked(_ renderer: [String: Any]) -> Bool? {
        if let status = renderer["likeStatus"] as? String {
            if status == "LIKE" { return true }
            if status == "INDIFFERENT" || status == "DISLIKE" { return false }
        }
        for button in dictionaries(renderer, key: "likeButtonRenderer") {
            if let status = button["likeStatus"] as? String {
                if status == "LIKE" { return true }
                if status == "INDIFFERENT" || status == "DISLIKE" { return false }
            }
        }
        for toggle in dictionaries(renderer["menu"] ?? [:], key: "toggleMenuServiceItemRenderer") {
            if let endpoint = toggle["defaultServiceEndpoint"] as? [String: Any],
               let like = endpoint["likeEndpoint"] as? [String: Any],
               let status = like["status"] as? String {
                // The default action removes an existing like or adds a new one.
                if status == "INDIFFERENT" { return true }
                if status == "LIKE" { return false }
            }
        }
        return nil
    }

    static func item(_ wrapper: [String: Any]) -> MusicItem? {
        let keys = ["musicTwoRowItemRenderer", "musicResponsiveListItemRenderer", "musicMultiRowListItemRenderer", "musicNavigationButtonRenderer", "musicItemRenderer"]
        guard let key = keys.first(where: { wrapper[$0] != nil }), let renderer = wrapper[key] as? [String: Any] else { return nil }
        let columns = (renderer["flexColumns"] as? [[String: Any]] ?? []).compactMap { $0["musicResponsiveListItemFlexColumnRenderer"] as? [String: Any] }
        let title = text(renderer["title"]).isEmpty ? text(columns.first?["text"]) : text(renderer["title"])
        let unavailable = renderer["musicItemRendererDisplayPolicy"] as? String == "MUSIC_ITEM_RENDERER_DISPLAY_POLICY_GREY_OUT"
            || renderer["isPlayable"] as? Bool == false
        let fallbackTitle = title.isEmpty ? text(renderer["buttonText"]) : title
        let actualTitle = fallbackTitle.isEmpty && unavailable ? "Unavailable entry" : fallbackTitle
        guard !actualTitle.isEmpty else { return nil }
        let subtitle = text(renderer["subtitle"]).isEmpty ? columns.dropFirst().map { text($0["text"]) }.filter { !$0.isEmpty }.joined(separator: " • ") : text(renderer["subtitle"])
        var clean = renderer
        // Menus contain unrelated radio, remove, and navigation endpoints.
        clean.removeValue(forKey: "menu")
        clean.removeValue(forKey: "badges")
        let endpoint = renderer["navigationEndpoint"] ?? columns.first?["text"] ?? renderer["title"] ?? clean
        let primaryBrowse = dictionaries(endpoint, key: "browseEndpoint").first
            ?? dictionaries(renderer["title"] ?? [:], key: "browseEndpoint").first
        let watch = dictionaries(endpoint, key: "watchEndpoint").first ?? dictionaries(clean, key: "watchEndpoint").first
        let watchPlaylist = dictionaries(clean, key: "watchPlaylistEndpoint").first
        let explicitVideo = (renderer["playlistItemData"] as? [String: Any])?["videoId"] as? String
        var video = explicitVideo ?? watch?["videoId"] as? String
        // Container cards can contain a random video in a shuffle thumbnail overlay.
        // Their primary browse endpoint, rather than that overlay, defines their identity.
        if explicitVideo == nil, let primaryID = primaryBrowse?["browseId"] as? String,
           primaryID.hasPrefix("VL") || primaryID.hasPrefix("MPRE") || primaryID.hasPrefix("UC") {
            video = nil
        }
        let browse = primaryBrowse ?? (video == nil ? dictionaries(clean, key: "browseEndpoint").first : nil)
        let browseID = browse?["browseId"] as? String
        var playlist = watch?["playlistId"] as? String ?? watchPlaylist?["playlistId"] as? String
        if let browseID, browseID.hasPrefix("VL") { playlist = String(browseID.dropFirst(2)) }
        if key == "musicResponsiveListItemRenderer", video == nil, browseID == nil, playlist != nil, !unavailable { return nil }
        let kind: String
        if video != nil || unavailable { kind = "Song" }
        else if playlist != nil { kind = "Playlist" }
        else if browseID?.hasPrefix("MPRE") == true { kind = "Album" }
        else if browseID?.hasPrefix("UC") == true { kind = "Artist" }
        else { kind = "Browse" }
        let fixed = (renderer["fixedColumns"] as? [[String: Any]] ?? []).first?["musicResponsiveListItemFixedColumnRenderer"] as? [String: Any]
        let duration = text(fixed?["text"])
        var result = MusicItem(id: video ?? browseID ?? playlist ?? actualTitle, title: actualTitle, subtitle: subtitle,
            artwork: artwork(renderer["thumbnailRenderer"] ?? renderer["thumbnail"] ?? [:]),
            videoID: video, playlistID: playlist, browseID: browseID, params: browse?["params"] as? String,
            duration: duration.isEmpty ? nil : duration, kind: kind)
        let metadata: [Any] = [renderer["subtitle"] ?? [:]] + columns.dropFirst().map { $0["text"] ?? [:] }
        func collectLinks(_ value: Any) {
            if let dict = value as? [String: Any] {
                if let name = dict["text"] as? String,
                   let endpoint = dict["navigationEndpoint"] as? [String: Any],
                   let browse = endpoint["browseEndpoint"] as? [String: Any],
                   let id = browse["browseId"] as? String {
                    let link = MusicLink(title: name, browseID: id, params: browse["params"] as? String)
                    if id.hasPrefix("MPRE"), result.album == nil { result.album = link }
                    if id.hasPrefix("UC"), result.artist == nil { result.artist = link }
                }
                for key in dict.keys.sorted() where key != "navigationEndpoint" {
                    if let child = dict[key] { collectLinks(child) }
                }
            } else if let array = value as? [Any] { array.forEach(collectLinks) }
        }
        result.playlistEntryID = (renderer["playlistItemData"] as? [String: Any])?["playlistSetVideoId"] as? String
        for edit in dictionaries(renderer["menu"] ?? [:], key: "playlistEditEndpoint") {
            for action in edit["actions"] as? [[String: Any]] ?? []
                where action["action"] as? String == "ACTION_REMOVE_VIDEO" {
                if let entry = action["setVideoId"] as? String,
                   let playlist = edit["playlistId"] as? String,
                   action["removedVideoId"] as? String == video {
                    result.playlistEntryID = entry
                    result.removalPlaylistID = playlist
                }
            }
        }
        result.unavailable = unavailable
        result.liked = liked(renderer)
        metadata.forEach(collectLinks)
        return result
    }

    static func addToPlaylistOptions(_ response: [String: Any]) -> [MusicItem] {
        var result: [MusicItem] = []
        var seen = Set<String>()
        for key in ["playlistAddToOptionRenderer", "addToPlaylistItemRenderer"] {
            for option in dictionaries(response, key: key) {
                if option["isEditable"] as? Bool == false || option["isDisabled"] as? Bool == true { continue }
                let edit = dictionaries(option, key: "playlistEditEndpoint").first
                guard let id = option["playlistId"] as? String ?? edit?["playlistId"] as? String,
                      id.hasPrefix("PL"), seen.insert(id).inserted else { continue }
                let title = text(option["title"])
                guard !title.isEmpty else { continue }
                result.append(MusicItem(id: "VL" + id, title: title, subtitle: text(option["subtitle"]),
                    artwork: artwork([option["thumbnail"] ?? [:], option["thumbnailRenderer"] ?? [:], ["thumbnails": option["thumbnails"] ?? []]]), playlistID: id, browseID: "VL" + id, kind: "Playlist"))
            }
        }
        return result
    }

    static func page(_ json: [String: Any], fallback: String, preservePlaylistEntries: Bool = false) -> MusicPage {
        var page = MusicPage(title: fallback)
        let headers: Any = json
        for key in ["musicDetailHeaderRenderer", "musicResponsiveHeaderRenderer", "musicImmersiveHeaderRenderer", "musicVisualHeaderRenderer"] {
            if let header = dictionaries(headers, key: key).first {
                let title = text(header["title"])
                if !title.isEmpty { page.title = title }
                page.subtitle = text(header["subtitle"])
                page.artwork = artwork(header)
                page.playlistID = dictionaries(header, key: "watchPlaylistEndpoint").first?["playlistId"] as? String
                    ?? dictionaries(header, key: "watchEndpoint").first?["playlistId"] as? String
            }
        }
        let contents = json["contents"] ?? json["continuationContents"] ?? json["onResponseReceivedActions"] ?? json
        var shelfCount = 0
        var looseItems: [MusicItem] = []
        func visit(_ value: Any) {
            if let dict = value as? [String: Any] {
                if let direct = item(dict) {
                    looseItems.append(direct)
                    return
                }
                if let card = dict["musicCardShelfRenderer"] as? [String: Any] {
                    var primary = card
                    primary["navigationEndpoint"] = card["onTap"] ?? card["title"]
                    primary.removeValue(forKey: "contents")
                    primary.removeValue(forKey: "buttons")
                    if let result = item(["musicTwoRowItemRenderer": primary]) {
                        page.shelves.append(.init(id: "top-result-\(shelfCount)", title: "Top result", items: [result]))
                        shelfCount += 1
                    }
                    if let children = card["contents"] { visit(children) }
                    return
                }
                for name in ["musicCarouselShelfRenderer", "musicShelfRenderer", "musicPlaylistShelfRenderer", "gridRenderer", "musicShelfContinuation", "musicPlaylistShelfContinuation", "gridContinuation", "musicMultiRowListItemShelfRenderer"] {
                    if let shelf = dict[name] as? [String: Any] {
                        let wrapped = shelf["contents"] as? [[String: Any]] ?? shelf["items"] as? [[String: Any]] ?? []
                        let items = wrapped.compactMap { item($0) }
                        if !items.isEmpty {
                            let basic = dictionaries(shelf["header"] ?? [:], key: "musicCarouselShelfBasicHeaderRenderer").first
                            let title = text(shelf["title"]).isEmpty ? text(basic?["title"]) : text(shelf["title"])
                            let more = route(basic?["moreContentButton"] ?? shelf["bottomEndpoint"] ?? [:], title: title)
                            page.shelves.append(.init(id: "shelf-\(shelfCount)", title: title,
                                items: items, more: more, isList: name.contains("PlaylistShelf") || name == "musicShelfRenderer" || name.contains("ShelfContinuation")))
                            shelfCount += 1
                        }
                        return
                    }
                }
                // Preserve the source order of tab/section/continuation arrays.
                for key in dict.keys.sorted() where key != "menu" && key != "header" && key != "background" {
                    if let child = dict[key] { visit(child) }
                }
            } else if let array = value as? [Any] { array.forEach(visit) }
        }
        visit(contents)
        if !looseItems.isEmpty {
            var seen = Set<String>()
            let unique = preservePlaylistEntries ? looseItems : looseItems.filter { seen.insert($0.id).inserted }
            page.shelves.append(.init(id: "results", title: "Results", items: unique, isList: true))
        }
        var filterIDs = Set<String>()
        for key in ["chipCloudChipRenderer", "tabRenderer"] {
            for filter in dictionaries(json, key: key) {
                let title = text(filter["text"]).isEmpty ? filter["title"] as? String ?? "" : text(filter["text"])
                if !title.isEmpty, let route = route(filter["navigationEndpoint"] ?? filter["endpoint"], title: title), filterIDs.insert(route.id).inserted {
                    page.filters.append(route)
                }
            }
        }
        // Only consume pagination for the page, not per-carousel continuation tokens.
        let continuationNames = ["musicPlaylistShelfRenderer", "musicShelfRenderer", "gridRenderer", "musicPlaylistShelfContinuation", "musicShelfContinuation", "gridContinuation"]
        for key in continuationNames {
            for shelf in dictionaries(contents, key: key) {
                if let data = dictionaries(shelf["continuations"] ?? [], key: "nextContinuationData").first,
                   let token = data["continuation"] as? String { page.continuation = token }
            }
        }
        if let command = dictionaries(contents, key: "continuationCommand").first,
           let token = command["token"] as? String { page.continuation = token }
        if page.playlistID == nil { page.playlistID = page.items.first(where: { $0.videoID != nil })?.playlistID }
        return page
    }
}

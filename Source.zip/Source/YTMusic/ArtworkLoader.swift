import Foundation
import ImageIO

// Bounded RAM cache only. Coalescing avoids duplicate sidebar/player downloads.
actor ArtworkLoader {
    static let shared = ArtworkLoader()
    private let cache = NSCache<NSURL, NSData>()
    private let failures = NSCache<NSURL, NSDate>()
    private var pending: [URL: Task<Data?, Never>] = [:]
    private let session: URLSession
    private var generation = UUID()

    init(session suppliedSession: URLSession? = nil) {
        cache.totalCostLimit = 32 * 1024 * 1024
        cache.countLimit = 160
        failures.countLimit = 256
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 15
        session = suppliedSession ?? URLSession(configuration: configuration)
    }

    func clear() {
        generation = UUID()
        for task in pending.values { task.cancel() }
        pending.removeAll()
        cache.removeAllObjects()
        failures.removeAllObjects()
    }

    func data(for candidates: [URL]) async -> Data? {
        let epoch = generation
        for url in candidates {
            guard generation == epoch, !Task.isCancelled else { return nil }
            let data = await load(url)
            guard generation == epoch else { return nil }
            if let data { return data }
        }
        return nil
    }

    private func load(_ url: URL) async -> Data? {
        if let data = cache.object(forKey: url as NSURL) { return data as Data }
        if let failed = failures.object(forKey: url as NSURL), Date().timeIntervalSince(failed as Date) < 300 { return nil }
        let epoch = generation
        if let task = pending[url] {
            let result = await task.value
            return generation == epoch ? result : nil
        }
        let session = session
        let task = Task<Data?, Never> {
            guard let (data, response) = try? await session.data(from: url),
                  (response as? HTTPURLResponse)?.statusCode == 200,
                  let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
                  let width = properties[kCGImagePropertyPixelWidth] as? Int,
                  let height = properties[kCGImagePropertyPixelHeight] as? Int else { return nil }
            guard ArtworkResolution.isUsable(url: url, width: width, height: height) else { return nil }
            return data
        }
        pending[url] = task
        let result = await task.value
        guard generation == epoch else { return nil }
        pending[url] = nil
        if let result { cache.setObject(result as NSData, forKey: url as NSURL, cost: result.count) }
        else { failures.setObject(Date() as NSDate, forKey: url as NSURL) }
        return result
    }
}

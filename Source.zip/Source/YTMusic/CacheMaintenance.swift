import Foundation
import WebKit

@MainActor
enum CacheMaintenance {
    // Deliberate allowlist: never use allWebsiteDataTypes() for cache maintenance.
    // Cookies, local/session storage, IndexedDB and worker registrations preserve login.
    static let removableTypes: Set<String> = [
        WKWebsiteDataTypeDiskCache,
        WKWebsiteDataTypeMemoryCache,
        WKWebsiteDataTypeFetchCache
    ]
    static let interval: TimeInterval = 6 * 60 * 60

    static func isDue(lastCleanup: Date?, now: Date = Date()) -> Bool {
        guard let lastCleanup else { return true }
        return now.timeIntervalSince(lastCleanup) >= interval
    }

    static func clear(_ store: WKWebsiteDataStore) async {
        await store.removeData(ofTypes: removableTypes, modifiedSince: .distantPast)
    }
}

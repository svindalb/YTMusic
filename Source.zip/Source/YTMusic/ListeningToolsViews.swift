import SwiftUI

struct ListeningToolsMenu: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        Menu {
            Button("Hold my place…", systemImage: "bookmark") { present(.place) }
            if let held = music.tools.heldPlace {
                Button("Return to " + held.song.title, systemImage: "arrow.uturn.backward") { music.restoreHeldPlace() }
                    .disabled(!music.ready || music.tools.restoring || music.tools.holding)
            }
            Divider()
            Button("Playlist Doctor…", systemImage: "stethoscope") { present(.doctor) }.disabled(!music.ready)
            Button("Radio breadcrumbs…", systemImage: "point.topleft.down.to.point.bottomright.curvepath") { present(.radio) }
            Button("Artwork atmosphere…", systemImage: "paintpalette") { present(.atmosphere) }
        } label: { Image(systemName: "sparkles") }
            .menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize()
            .help("Listening tools").accessibilityLabel("Listening tools").accessibilityIdentifier("listening-tools")
    }
    private func present(_ sheet: ListeningToolSheet) {
        Task { @MainActor in await Task.yield(); music.tools.sheet = sheet }
    }
}

struct ListeningToolView: View {
    let sheet: ListeningToolSheet
    var body: some View {
        switch sheet {
        case .place: HeldPlaceView()
        case .doctor: PlaylistDoctorView()
        case .radio: RadioBreadcrumbsView()
        case .atmosphere: AtmosphereSettingsView()
        }
    }
}

struct HeldPlaceView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack { Label("Hold my place", systemImage: "bookmark").font(.title2.bold()); Spacer(); Button("Done") { dismiss() }.keyboardShortcut(.cancelAction) }
            Text("Keep your queue and playback position while you explore something else.").foregroundStyle(.secondary)
            if let held = music.tools.heldPlace {
                HStack(spacing: 14) {
                    ArtworkView(url: held.song.artwork, size: 76, radius: 12)
                    VStack(alignment: .leading, spacing: 7) {
                        Text(held.song.title).font(.headline).lineLimit(2)
                        Text(held.song.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        Text("\(held.elapsed.musicTime) · \(held.queue.count) queued · \(held.savedAt.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(16).modifier(MusicSurface())
                HStack {
                    Button { music.restoreHeldPlace() } label: { Label(music.tools.restoring ? "Returning…" : "Return to saved place", systemImage: "arrow.uturn.backward") }
                        .buttonStyle(MusicButtonStyle(prominent: true)).disabled(!music.ready || music.tools.restoring || music.tools.holding)
                    Button("Forget saved place") { music.tools.clearPlace() }.disabled(music.tools.restoring || music.tools.holding)
                }
            } else {
                ContentUnavailableView("No place held yet", systemImage: "bookmark", description: Text("Choose a song, then save your place here."))
            }
            Divider()
            if let song = music.currentSong {
                Text("Playing now: " + song.title).font(.callout).lineLimit(2)
                Button(music.tools.holding ? "Saving queue…" : music.tools.heldPlace == nil ? "Save current place" : "Replace saved place with this song") { music.holdMyPlace() }
                    .buttonStyle(MusicButtonStyle()).disabled(music.tools.restoring || music.tools.holding)
            }
            if let message = music.tools.restoreMessage { Text(message).font(.callout).foregroundStyle(.secondary) }
            Text("Saves up to 1,000 queued tracks. Radio holds its currently available recommendations.").font(.caption).foregroundStyle(.secondary)
            Text(music.tools.hasDiskStorage ? "Saved locally on this Mac for this account." : "Available for this app session.")
                .font(.caption).foregroundStyle(.secondary)
            if let error = music.tools.storageError { Text(error).font(.caption).foregroundStyle(MusicStyle.red) }
        }.padding(24).frame(width: 560).background(MusicBackdrop()).preferredColorScheme(.dark).tint(MusicStyle.red)
    }
}

struct AtmosphereControls: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Toggle("Follow the current artwork", isOn: Binding(get: { music.tools.atmosphereEnabled }, set: { music.tools.configureAtmosphere(enabled: $0) }))
            HStack {
                Text("Subtle").font(.caption).foregroundStyle(.secondary)
                Slider(value: Binding(get: { music.tools.atmosphereIntensity }, set: { music.tools.configureAtmosphere(intensity: $0) }), in: 0...1)
                    .accessibilityLabel("Artwork atmosphere intensity").disabled(!music.tools.atmosphereEnabled)
                Text("Vivid").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                Circle().fill(music.tools.palette?.primary.color ?? MusicStyle.red).frame(width: 24, height: 24)
                Circle().fill(music.tools.palette?.secondary.color ?? .purple).frame(width: 24, height: 24)
                Text("Colours blend slowly between songs.").font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
struct AtmosphereSettingsView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack { Label("Artwork atmosphere", systemImage: "paintpalette").font(.title2.bold()); Spacer(); Button("Done") { dismiss() }.keyboardShortcut(.cancelAction) }
            Text("Let the current cover gently colour your music space.").foregroundStyle(.secondary)
            AtmosphereControls()
        }.padding(26).frame(width: 500)
            .background(MusicBackdrop(palette: music.tools.activePalette, intensity: music.tools.atmosphereIntensity))
            .preferredColorScheme(.dark).tint(MusicStyle.red)
    }
}

struct RadioBreadcrumbsView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    @State private var selectedTrail: UUID?
    @State private var showTray = false
    @State private var confirmClear = false
    private var trail: RadioTrail? { music.tools.trails.first { $0.id == selectedTrail } ?? music.tools.trails.first }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Label("Radio breadcrumbs", systemImage: "point.topleft.down.to.point.bottomright.curvepath").font(.title2.bold()); Spacer(); Button("Done") { dismiss() }.keyboardShortcut(.cancelAction) }
            Picker("View", selection: $showTray) {
                Text("Radio trails").tag(false)
                Text("Discovery tray (\(music.tools.discoveries.count))").tag(true)
            }.pickerStyle(.segmented)
            if showTray {
                Text("Keep promising songs here, then choose a playlist when you’re ready.").font(.callout).foregroundStyle(.secondary)
                ScrollView { LazyVStack(spacing: 8) { ForEach(music.tools.discoveries, id: \.videoID) { song in songRow(song) } } }
                    .overlay { if music.tools.discoveries.isEmpty { ContentUnavailableView("Your discovery tray is empty", systemImage: "tray", description: Text("Use the bookmark beside a song in a radio trail.")) } }
            } else if let trail {
                Picker("Radio session", selection: Binding(get: { trail.id }, set: { selectedTrail = $0 })) {
                    ForEach(music.tools.trails) { trail in Text(trail.seed.title + " · " + trail.startedAt.formatted(date: .abbreviated, time: .shortened)).tag(trail.id) }
                }
                HStack(spacing: 12) {
                    ArtworkView(url: trail.seed.artwork, size: 52, radius: 9)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Started from " + trail.seed.title).font(.headline).lineLimit(2)
                        Text(trail.id == music.tools.activeTrailID ? "Current radio session" : "Saved radio trail").font(.caption).foregroundStyle(.secondary)
                    }
                }
                ScrollView { LazyVStack(spacing: 8) { ForEach(trail.visits) { visit in songRow(visit.song) } } }
                    .overlay { if trail.visits.isEmpty { Text("Songs appear here as they start playing.").foregroundStyle(.secondary) } }
            } else {
                ContentUnavailableView("Follow a radio adventure", systemImage: "dot.radiowaves.left.and.right", description: Text("Start Mix / Radio from a song. This Mac will remember the seed and songs you play along the way."))
                    .frame(maxHeight: .infinity)
            }
            HStack {
                Text("Only listening in this app is recorded. Stored on this Mac.").font(.caption).foregroundStyle(.secondary)
                Spacer()
                if !showTray && !music.tools.trails.isEmpty { Button("Clear trails…") { confirmClear = true } }
            }
            if let error = music.tools.storageError { Text(error).font(.caption).foregroundStyle(MusicStyle.red) }
        }.padding(24).frame(width: 650, height: 630).background(MusicBackdrop()).preferredColorScheme(.dark).tint(MusicStyle.red)
            .confirmationDialog("Clear saved radio trails on this Mac? Your discovery tray stays.", isPresented: $confirmClear) {
                Button("Clear trails", role: .destructive) { music.tools.clearTrails() }
                Button("Cancel", role: .cancel) { }
            }
    }
    private func songRow(_ song: MusicItem) -> some View {
        HStack(spacing: 12) {
            Button { if let route = song.detailRoute { music.tools.sheet = nil; music.navigateFromMenu(route) } } label: {
                HStack(spacing: 10) {
                    ArtworkView(url: song.artwork, size: 42, radius: 7)
                    VStack(alignment: .leading, spacing: 4) { Text(song.title).font(.callout).lineLimit(1); Text(song.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                }.frame(maxWidth: .infinity, alignment: .leading)
            }.buttonStyle(.plain).help("Go to song")
            Button { music.play(song); music.tools.sheet = nil } label: { Image(systemName: "play.fill") }.help("Play song")
            Button { music.tools.toggleDiscovery(song) } label: { Image(systemName: music.tools.isDiscovered(song) ? "bookmark.fill" : "bookmark") }
                .foregroundStyle(music.tools.isDiscovered(song) ? MusicStyle.red : .primary).help(music.tools.isDiscovered(song) ? "Remove from discovery tray" : "Keep in discovery tray")
            Button {
                music.tools.playlistDestinationSong = song
                music.tools.sheet = nil
            } label: { Image(systemName: "text.badge.plus") }.help("Add to playlist")
        }.buttonStyle(TransportButtonStyle(compact: true)).padding(10).modifier(MusicSurface(radius: 12))
    }
}

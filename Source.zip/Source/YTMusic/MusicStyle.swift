import SwiftUI

enum MusicStyle {
    static let red = Color(red: 1, green: 0.19, blue: 0.28)
    static let backdrop = Color(red: 0.055, green: 0.055, blue: 0.075)
    static let gradient = LinearGradient(colors: [red, Color(red: 0.72, green: 0.13, blue: 0.34)], startPoint: .topLeading, endPoint: .bottomTrailing)
}

struct ArtworkAtmosphereGlow: View {
    var palette: ArtworkPalette? = nil
    var intensity: Double = 0.45
    var radius: CGFloat = 650
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        ZStack {
            RadialGradient(colors: [(palette?.primary.color ?? MusicStyle.red).opacity(palette == nil ? 0.15 : intensity * 0.38), .clear], center: .topLeading, startRadius: 0, endRadius: radius)
            RadialGradient(colors: [(palette?.secondary.color ?? .purple).opacity(palette == nil ? 0.10 : intensity * 0.30), .clear], center: .bottomTrailing, startRadius: 0, endRadius: radius * 600 / 650)
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 2.4), value: palette)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct MusicBackdrop: View {
    var palette: ArtworkPalette? = nil
    var intensity: Double = 0.45
    var body: some View {
        ZStack {
            MusicStyle.backdrop
            ArtworkAtmosphereGlow(palette: palette, intensity: intensity)
        }.ignoresSafeArea()
    }
}

struct MusicSurface: ViewModifier {
    var radius: CGFloat = 16
    func body(content: Content) -> some View {
        content.background {
            RoundedRectangle(cornerRadius: radius).fill(.ultraThinMaterial).opacity(0.75)
                .overlay { RoundedRectangle(cornerRadius: radius).strokeBorder(.white.opacity(0.065), lineWidth: 1) }
        }
    }
}

struct MusicButtonStyle: ButtonStyle {
    var prominent = false
    func makeBody(configuration: Configuration) -> some View {
        MusicButtonBody(configuration: configuration, prominent: prominent)
    }
    private struct MusicButtonBody: View {
        let configuration: Configuration
        let prominent: Bool
        @State private var hovering = false
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        var body: some View {
            configuration.label
                .foregroundStyle(prominent ? .white : .primary)
                .padding(.horizontal, 13).padding(.vertical, 9)
                .background {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(prominent ? AnyShapeStyle(MusicStyle.gradient) : AnyShapeStyle(.white.opacity(hovering ? 0.10 : 0.04)))
                }
                .overlay { RoundedRectangle(cornerRadius: 12).strokeBorder(.white.opacity(hovering ? 0.16 : 0.06)) }
                .scaleEffect(configuration.isPressed && !reduceMotion ? 0.96 : 1)
                .brightness(hovering && prominent ? 0.07 : 0)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: hovering)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
                .onHover { hovering = $0 }
        }
    }
}

struct ArtworkView: View {
    let url: URL?
    var size: CGFloat
    var radius: CGFloat = 12
    var highResolution = false
    @State private var loadedImage: NSImage?
    @State private var loadedCandidates: [URL] = []
    @Environment(\.displayScale) private var displayScale
    private var pixels: Int { ArtworkResolution.requestedPixels(pointSize: size, displayScale: displayScale, highResolution: highResolution) }
    private var candidates: [URL] { ArtworkResolution.candidates(for: url, pixels: pixels) }
    var body: some View {
        Group {
            if loadedCandidates == candidates, let loadedImage {
                Image(nsImage: loadedImage).resizable().interpolation(.high).scaledToFill()
            } else {
                ZStack {
                    LinearGradient(colors: [.white.opacity(0.08), MusicStyle.red.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Image(systemName: "music.note").font(.system(size: size * 0.25)).foregroundStyle(.white.opacity(0.22))
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: radius))
        .overlay { RoundedRectangle(cornerRadius: radius).strokeBorder(.white.opacity(0.06)) }
        .task(id: candidates) {
            let requested = candidates
            let data = await ArtworkLoader.shared.data(for: requested)
            guard !Task.isCancelled else { return }
            loadedImage = data.flatMap { NSImage(data: $0) }
            loadedCandidates = requested
        }
    }
}

struct EqualizerView: View {
    let active: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !active || reduceMotion)) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                for index in 0..<5 {
                    let phase = time * (3.0 + Double(index) * 0.32) + Double(index) * 1.9
                    let fraction = active && !reduceMotion ? 0.25 + 0.75 * abs(sin(phase)) : [0.35, 0.65, 0.9, 0.5, 0.3][index]
                    let width = size.width / 8
                    let height = max(3, size.height * fraction)
                    let rect = CGRect(x: CGFloat(index) * size.width / 5, y: size.height - height, width: width, height: height)
                    context.fill(Path(roundedRect: rect, cornerRadius: 2), with: .color(MusicStyle.red))
                }
            }
        }.frame(width: 23, height: 19)
            .accessibilityLabel(active ? "Playing" : "Paused")
    }
}

extension Double {
    var musicTime: String {
        guard isFinite, self > 0 else { return "0:00" }
        let value = Int(self)
        return value >= 3600 ? String(format: "%d:%02d:%02d", value / 3600, (value / 60) % 60, value % 60)
            : String(format: "%d:%02d", value / 60, value % 60)
    }
}

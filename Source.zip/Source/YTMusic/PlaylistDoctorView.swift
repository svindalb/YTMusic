import SwiftUI

struct PlaylistDoctorView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    @State private var primaryID = ""
    @State private var compareID = ""
    @State private var report: PlaylistAudit?
    @State private var selected = Set<String>()
    @State private var section = "duplicates"
    @State private var scanning = false
    @State private var removing = false
    @State private var reviewing = false
    @State private var message: String?
    @State private var error: String?
    @State private var scanTask: Task<Void, Never>?
    private var playlists: [MusicItem] { music.playlists.filter { $0.playlistID?.hasPrefix("PL") == true } }
    private var chosen: [MusicItem] { report?.removableExtras.filter { selected.contains($0.playlistEntryID ?? "") } ?? [] }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Label("Playlist Doctor", systemImage: "stethoscope").font(.title2.bold()); Spacer(); Button("Done") { dismiss() }.disabled(removing).keyboardShortcut(.cancelAction) }
            if reviewing, let report {
                review(report)
            } else {
                Text("Find exact duplicates, unavailable entries, and songs shared by two playlists.").font(.callout).foregroundStyle(.secondary)
                HStack {
                    Picker("Playlist", selection: $primaryID) {
                        Text("Choose a playlist").tag("")
                        ForEach(playlists) { item in Text(item.title).tag(item.playlistID!) }
                    }
                    Button { scan() } label: { Label(scanning ? "Scanning…" : "Scan", systemImage: "magnifyingglass") }
                        .buttonStyle(MusicButtonStyle(prominent: true)).disabled(primaryID.isEmpty || scanning)
                }.disabled(removing)
                Picker("Compare with", selection: $compareID) {
                    Text("None").tag("")
                    ForEach(playlists.filter { $0.playlistID != primaryID }) { item in Text(item.title).tag(item.playlistID!) }
                }.disabled(scanning || removing)
                if scanning { HStack { ProgressView().controlSize(.small); Text("Reading the complete playlist…").foregroundStyle(.secondary) } }
                if let report {
                    Text("\(report.entries.count) entries checked" + (report.comparedPlaylist == nil ? "" : " · compared with \(report.comparedCount) entries"))
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("Findings", selection: $section) {
                        Text("Duplicates (\(report.duplicates.count))").tag("duplicates")
                        Text("Unavailable (\(report.unavailable.count))").tag("unavailable")
                        Text("Shared (\(report.overlap.count))").tag("overlap")
                    }.pickerStyle(.segmented)
                    findings(report)
                    if section == "duplicates", !report.removableExtras.isEmpty {
                        HStack {
                            Button("Select extra copies") { selected = Set(report.removableExtras.prefix(100).compactMap(\.playlistEntryID)) }
                            Button("Clear selection") { selected = [] }.disabled(selected.isEmpty)
                            Spacer()
                            Button("Review removal (\(chosen.count))") { reviewing = true }
                                .buttonStyle(MusicButtonStyle()).disabled(chosen.isEmpty || chosen.count > 100 || scanning)
                        }
                    }
                } else if !scanning {
                    ContentUnavailableView("Give a playlist a check-up", systemImage: "stethoscope", description: Text("A scan is read-only. Extra copies are removed only after you select and review them."))
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            if let message { Text(message).font(.callout).foregroundStyle(.secondary) }
            if let error { Text(error).font(.callout).foregroundStyle(MusicStyle.red).fixedSize(horizontal: false, vertical: true) }
        }.padding(24).frame(width: 740, height: 660).background(MusicBackdrop()).preferredColorScheme(.dark).tint(MusicStyle.red)
            .interactiveDismissDisabled(removing)
            .task {
                if primaryID.isEmpty { primaryID = playlists.first(where: { $0.browseID == music.route.browseID })?.playlistID ?? playlists.first?.playlistID ?? "" }
            }
            .onChange(of: primaryID) { _, _ in if compareID == primaryID { compareID = "" }; clearReport() }
            .onChange(of: compareID) { _, _ in clearReport() }
            .onDisappear { scanTask?.cancel() }
    }

    @ViewBuilder private func findings(_ report: PlaylistAudit) -> some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                if section == "duplicates" {
                    if report.duplicates.isEmpty { empty("No exact duplicates found", "Different uploads and remixes are kept separate.") }
                    ForEach(report.duplicates) { group in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(group.entries[0].title).font(.headline)
                            Label("First copy kept", systemImage: "checkmark.shield").font(.caption).foregroundStyle(.secondary)
                            ForEach(Array(group.entries.dropFirst().enumerated()), id: \.offset) { _, item in
                                let entry = item.playlistEntryID ?? ""
                                let editable = !entry.isEmpty && item.removalPlaylistID == report.playlist.playlistID
                                Toggle(isOn: Binding(get: { selected.contains(entry) }, set: { if $0 { selected.insert(entry) } else { selected.remove(entry) } })) {
                                    HStack {
                                        Text("Extra copy" + (item.playlistPosition.map { " · #\($0 + 1)" } ?? ""))
                                        Spacer()
                                        if !editable { Text("Read-only entry").font(.caption).foregroundStyle(.secondary) }
                                    }
                                }.disabled(!editable).toggleStyle(.checkbox)
                            }
                        }.padding(14).modifier(MusicSurface(radius: 12))
                    }
                } else if section == "unavailable" {
                    Text("Availability can change by account or region. These entries are flagged for review; they won’t be removed automatically.").font(.caption).foregroundStyle(.secondary)
                    if report.unavailable.isEmpty { empty("No unavailable entries flagged", "Based on the playlist information available to this account.") }
                    ForEach(Array(report.unavailable.enumerated()), id: \.offset) { _, item in song(item, symbol: "exclamationmark.triangle") }
                } else {
                    if report.comparedPlaylist == nil { empty("Choose a second playlist", "Select Compare with, then scan again.") }
                    else if report.overlap.isEmpty { empty("No shared songs found", "Matches use the exact song or video, not just its title.") }
                    ForEach(Array(report.overlap.enumerated()), id: \.offset) { _, item in song(item, symbol: "square.on.square") }
                }
            }.padding(.vertical, 6)
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    private func empty(_ title: String, _ description: String) -> some View {
        ContentUnavailableView(title, systemImage: "checkmark.circle", description: Text(description)).frame(maxWidth: .infinity)
    }
    private func song(_ item: MusicItem, symbol: String) -> some View {
        HStack(spacing: 12) { ArtworkView(url: item.artwork, size: 40, radius: 7); VStack(alignment: .leading, spacing: 4) { Text(item.title).lineLimit(1); Text(item.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1) }; Spacer(); Image(systemName: symbol).foregroundStyle(.secondary) }
            .padding(10).modifier(MusicSurface(radius: 12))
    }
    private func review(_ report: PlaylistAudit) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Review \(chosen.count) extra copies").font(.title3.bold())
            Text("Remove these entries from “\(report.playlist.title)”? At least one copy of every selected song will be kept.").foregroundStyle(.secondary)
            ScrollView { LazyVStack(spacing: 8) { ForEach(Array(chosen.enumerated()), id: \.offset) { _, item in song(item, symbol: "minus.circle") } } }
            HStack {
                Button("Back to findings") { reviewing = false }.disabled(removing)
                Spacer()
                if removing { ProgressView().controlSize(.small) }
                Button(removing ? "Removing…" : "Remove \(chosen.count) extra copies", role: .destructive) { remove(report) }.disabled(removing || chosen.isEmpty)
            }
        }.frame(maxHeight: .infinity)
    }
    private func clearReport() { scanTask?.cancel(); report = nil; selected = []; message = nil; error = nil; reviewing = false; scanning = false }
    private func scan() {
        guard let playlist = playlists.first(where: { $0.playlistID == primaryID }) else { return }
        let compared = playlists.first { $0.playlistID == compareID }
        scanTask?.cancel(); scanning = true; report = nil; selected = []; error = nil; message = nil
        let account = music.accountGeneration
        scanTask = Task {
            defer { if music.accountGeneration == account, !Task.isCancelled { scanning = false } }
            do {
                let result = try await music.scanPlaylist(playlist, compare: compared)
                guard !Task.isCancelled, music.accountGeneration == account else { return }
                report = result
            } catch is CancellationError { }
            catch { if !Task.isCancelled, music.accountGeneration == account { self.error = error.localizedDescription } }
        }
    }
    private func remove(_ report: PlaylistAudit) {
        let entries = chosen
        guard !entries.isEmpty else { return }
        removing = true; error = nil
        let account = music.accountGeneration
        Task {
            defer { if music.accountGeneration == account { removing = false } }
            do {
                try await music.removeDoctorDuplicates(entries, from: report.playlist)
                guard music.accountGeneration == account else { return }
                reviewing = false; self.report = nil; selected = []
                message = "Removed \(entries.count) extra copies. Scan again for a fresh check-up."
            } catch {
                if music.accountGeneration == account { reviewing = false; self.report = nil; selected = []; self.error = error.localizedDescription }
            }
        }
    }
}

import SwiftUI

struct MusicPageView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var revealedCurrent = false
    @State private var playlistSearch = ""
    private var isPlaylist: Bool { music.route.browseID.hasPrefix("VL") && music.page?.playlistID != nil }
    private var searchQuery: String { isPlaylist ? playlistSearch.trimmingCharacters(in: .whitespacesAndNewlines) : "" }
    var body: some View {
        ScrollViewReader { proxy in
            List {
                if music.isLoading {
                    HStack(spacing: 12) { ProgressView().controlSize(.small); Text("Finding your music…").foregroundStyle(.secondary) }
                        .frame(maxWidth: .infinity, minHeight: 320)
                        .listRowSeparator(.hidden).listRowBackground(Color.clear)
                } else if let page = music.page {
                    header(page)
                        .listRowInsets(EdgeInsets(top: 18, leading: 30, bottom: 14, trailing: 30))
                        .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    if let song = page.song {
                        songDetails(song)
                            .listRowInsets(EdgeInsets(top: 12, leading: 30, bottom: 28, trailing: 30))
                            .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    }
                    if !page.filters.isEmpty {
                        FilterFlowLayout {
                            ForEach(page.filters) { filter in
                                Button(filter.title) { music.navigate(filter) }.buttonStyle(MusicButtonStyle())
                            }
                        }
                            .listRowInsets(EdgeInsets(top: 8, leading: 30, bottom: 20, trailing: 30))
                            .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    }
                    if page.shelves.isEmpty && page.song == nil {
                        ContentUnavailableView("Nothing here yet", systemImage: "music.note",
                            description: Text("There’s no music to show here yet. Try another section or refresh your library."))
                            .frame(maxWidth: .infinity, minHeight: 240)
                            .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    }
                    if !searchQuery.isEmpty {
                        let count = page.shelves.filter(\.isList).flatMap(\.items).filter { $0.matchesPlaylistSearch(searchQuery) }.count
                        Text(count == 0 ? "No matches in loaded songs." : "\(count) matches in loaded songs")
                            .font(.callout).foregroundStyle(.secondary)
                            .listRowInsets(EdgeInsets(top: 4, leading: 30, bottom: 8, trailing: 30))
                            .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    }
                    ForEach(page.shelves) { shelf in
                        Section {
                            if shelf.isList {
                                ForEach(Array(shelf.items.enumerated()).filter { $0.element.matchesPlaylistSearch(searchQuery) }, id: \.offset) { index, item in
                                    MusicTrackRow(item: item, index: index + 1, sourcePlaylistID: music.route.browseID == "VL" + (page.playlistID ?? "") ? page.playlistID : nil)
                                        .frame(height: 61)
                                        .id("\(shelf.id)-\(index)")
                                        .listRowInsets(EdgeInsets(top: 2, leading: 30, bottom: 2, trailing: 30))
                                        .listRowSeparator(.hidden).listRowBackground(Color.clear)
                                }
                            } else if shelf.items.count == 1, let item = shelf.items.first {
                                HStack(alignment: .top) {
                                    MusicCard(item: item)
                                    Spacer(minLength: 0)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .frame(height: 242, alignment: .top)
                                .listRowInsets(EdgeInsets(top: 6, leading: 30, bottom: 18, trailing: 30))
                                .listRowSeparator(.hidden).listRowBackground(Color.clear)
                            } else {
                                ScrollView(.horizontal) {
                                    LazyHStack(alignment: .top, spacing: 18) {
                                        ForEach(Array(shelf.items.enumerated()), id: \.offset) { _, item in MusicCard(item: item) }
                                    }.padding(.bottom, 7)
                                }
                                .scrollIndicators(.hidden).frame(height: 242, alignment: .top)
                                .listRowInsets(EdgeInsets(top: 6, leading: 30, bottom: 18, trailing: 30))
                                .listRowSeparator(.hidden).listRowBackground(Color.clear)
                            }
                        } header: {
                            if !shelf.title.isEmpty {
                                HStack {
                                    Text(shelf.title).font(.system(size: 22, weight: .bold, design: .rounded)).textCase(nil)
                                    Spacer()
                                    if let more = shelf.more {
                                        Button { music.navigate(more) } label: { Image(systemName: "arrow.right") }
                                            .buttonStyle(MusicButtonStyle()).help("See all " + shelf.title)
                                    }
                                }.padding(.top, 12).padding(.bottom, 8)
                            }
                        }.listSectionSeparator(.hidden)
                    }
                    if page.continuation != nil {
                        HStack {
                            Spacer()
                            Button { Task { await music.loadMore() } } label: {
                                if music.loadingMore { ProgressView().controlSize(.small) } else { Text("Load more") }
                            }.buttonStyle(MusicButtonStyle()).disabled(music.loadingMore)
                            Spacer()
                        }
                        .listRowInsets(EdgeInsets(top: 16, leading: 30, bottom: 24, trailing: 30))
                        .listRowSeparator(.hidden).listRowBackground(Color.clear)
                    }
                }
                if let error = music.error {
                    VStack(spacing: 14) {
                        Image(systemName: "wifi.exclamationmark").font(.largeTitle).foregroundStyle(MusicStyle.red)
                        Text("Couldn’t load this section").font(.title3.bold())
                        Text(error).font(.callout).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        Button("Try again") { music.navigate(music.route, remember: false, refresh: true) }.buttonStyle(MusicButtonStyle())
                    }.frame(maxWidth: .infinity, minHeight: 270)
                        .listRowSeparator(.hidden).listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain).scrollContentBackground(.hidden).scrollIndicators(.hidden)
            .environment(\.defaultMinListRowHeight, 0)
            .onChange(of: music.isLoading) { _, loading in if loading { revealedCurrent = false } }
            .task(id: "\(music.isLoading)-\(music.page?.items.count ?? 0)-\(music.now.videoID)") {
                guard searchQuery.isEmpty, !music.isLoading, !revealedCurrent, !music.now.videoID.isEmpty,
                      let page = music.page else { return }
                for shelf in page.shelves where shelf.isList {
                    if let index = shelf.items.firstIndex(where: { $0.videoID == music.now.videoID }) {
                        await Task.yield()
                        guard !Task.isCancelled else { return }
                        // Native list scrolling uses fixed row geometry. Do not animate
                        // through the outgoing page's lazy-stack layout on Back.
                        proxy.scrollTo("\(shelf.id)-\(index)", anchor: .center)
                        revealedCurrent = true
                        return
                    }
                }
            }
        }
    }

    private func songDetails(_ original: MusicItem) -> some View {
        let song = music.enrichedSong(original)
        return VStack(alignment: .leading, spacing: 16) {
            if let duration = song.duration, !duration.isEmpty {
                Label(duration, systemImage: "clock").font(.callout).foregroundStyle(.secondary)
            }
            HStack(spacing: 12) {
                if let videoID = song.videoID { SongLikeButton(videoID: videoID, known: song.liked) }
                if let album = song.album {
                    Button { music.navigate(album.route) } label: { Label("Album: " + album.title, systemImage: "square.stack") }
                        .buttonStyle(MusicButtonStyle())
                }
                if let artist = song.artist {
                    Button { music.navigate(artist.route) } label: { Label("Artist: " + artist.title, systemImage: "person") }
                        .buttonStyle(MusicButtonStyle())
                }
            }
        }
    }

    private func header(_ page: MusicPage) -> some View {
        HStack(alignment: .center, spacing: 24) {
            if let art = page.artwork { ArtworkView(url: art, size: 158, radius: 20).shadow(color: .black.opacity(0.3), radius: 18, y: 8) }
            VStack(alignment: .leading, spacing: 11) {
                Text(page.song != nil ? "SONG" : music.route.browseID == "FEmusic_home" ? "YOUR DAILY SOUNDTRACK" : "YOUTUBE MUSIC")
                    .font(.system(size: 10, weight: .bold)).tracking(2.2).foregroundStyle(MusicStyle.red)
                Text(music.route.browseID == "FEmusic_home" ? "Made for your\nkind of music." : page.title)
                    .font(.system(size: music.route.browseID == "FEmusic_home" ? 40 : 34, weight: .bold, design: .rounded))
                    .tracking(-1.2).lineLimit(3).fixedSize(horizontal: false, vertical: true)
                if !page.subtitle.isEmpty { Text(page.subtitle).font(.callout).foregroundStyle(.secondary).lineLimit(3) }
                else if music.route.browseID == "FEmusic_home" {
                    Text("Familiar favorites. New obsessions. All yours.").font(.callout).foregroundStyle(.secondary)
                }
                if page.song != nil || page.playlistID != nil || page.items.contains(where: { $0.videoID != nil }) {
                    HStack(spacing: 10) {
                        Button { music.playPage() } label: { Label("Play", systemImage: "play.fill").fontWeight(.semibold) }
                            .buttonStyle(MusicButtonStyle(prominent: true))
                        if let item = page.song ?? page.items.first(where: { $0.videoID != nil }) {
                            Button { music.play(item, radio: true) } label: { Label("Start radio", systemImage: "dot.radiowaves.left.and.right") }
                                .buttonStyle(MusicButtonStyle())
                        }
                        if let song = page.song { SongActionsMenu(song: song) }
                        if isPlaylist {
                            HStack(spacing: 7) {
                                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                                TextField("Search in playlist", text: $playlistSearch)
                                    .textFieldStyle(.plain)
                                    .accessibilityIdentifier("playlist-content-search")
                                if !playlistSearch.isEmpty {
                                    Button { playlistSearch = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                                        .buttonStyle(.plain).help("Clear playlist search")
                                }
                            }
                            .padding(.horizontal, 10).padding(.vertical, 10)
                            .modifier(MusicSurface(radius: 12))
                            .frame(minWidth: 130, idealWidth: 190, maxWidth: 230)
                            .help("Filter loaded songs by title, artist or album")
                        }
                    }.padding(.top, 5)
                }
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 18)
    }
}

struct MusicCard: View {
    let item: MusicItem
    @Environment(MusicSession.self) private var music
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var hovered = false
    var body: some View {
        Button { music.open(item) } label: {
            VStack(alignment: .leading, spacing: 9) {
                ArtworkView(url: item.artwork, size: 164, radius: item.kind == "Artist" ? 82 : 15)
                Text(item.title).font(.system(size: 13, weight: .semibold)).lineLimit(2)
                    .multilineTextAlignment(.leading).frame(maxWidth: .infinity, alignment: .leading)
                Text(item.subtitle.isEmpty ? item.kind : item.subtitle)
                    .font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(2)
                    .multilineTextAlignment(.leading)
            }
            .frame(width: 164, alignment: .topLeading).contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Open " + item.title)
        .accessibilityIdentifier("open-card-" + item.id)
        .overlay(alignment: .topTrailing) {
            if item.isPlayable {
                Button { music.play(item) } label: {
                    Image(systemName: "play.fill").font(.system(size: 16, weight: .bold))
                        .frame(width: 38, height: 38)
                }
                .buttonStyle(.plain).foregroundStyle(.black)
                .background(.white, in: Circle()).shadow(color: .black.opacity(0.3), radius: 8, y: 4)
                .padding(.trailing, 10).padding(.top, 116)
                .opacity(hovered ? 1 : 0).allowsHitTesting(hovered)
                .accessibilityLabel("Play " + item.title)
                .accessibilityIdentifier("play-card-" + item.id)
            }
        }
        .scaleEffect(hovered && !reduceMotion ? 1.015 : 1, anchor: .top)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: hovered)
        .onHover { hovered = $0 }
        .contextMenu { MusicItemMenu(item: item) }
    }
}

struct MusicTrackRow: View {
    let item: MusicItem
    let index: Int
    var sourcePlaylistID: String? = nil
    @Environment(MusicSession.self) private var music
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var hovered = false
    var isCurrent: Bool { item.videoID != nil && item.videoID == music.now.videoID }
    var body: some View {
        HStack(spacing: 13) {
            ZStack {
                if isCurrent { EqualizerView(active: music.now.isPlaying) }
                else { Text("\(index)").monospacedDigit().font(.caption).foregroundStyle(.tertiary) }
            }.frame(width: 25)
            ArtworkView(url: item.artwork, size: 43, radius: 8)
            VStack(alignment: .leading, spacing: 5) {
                Text(item.title).font(.system(size: 13, weight: isCurrent ? .semibold : .medium))
                    .foregroundStyle(isCurrent ? MusicStyle.red : .primary).lineLimit(1)
                Text(item.subtitle.isEmpty ? item.kind : item.subtitle).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 15)
            if item.videoID != nil {
                Button { music.play(item, radio: true) } label: { Image(systemName: "dot.radiowaves.left.and.right") }
                    .buttonStyle(.plain).foregroundStyle(.secondary).help("Start radio")
                    .opacity(hovered || isCurrent ? 1 : 0)
            }
            if let videoID = item.videoID { SongLikeButton(videoID: videoID, known: item.liked, fetchMissing: hovered || isCurrent) }
            Text(item.duration ?? "").font(.system(size: 11)).monospacedDigit().foregroundStyle(.secondary).frame(width: 48, alignment: .trailing)
            Menu { MusicItemMenu(item: item, sourcePlaylistID: sourcePlaylistID) } label: { Image(systemName: "ellipsis") }
                .menuStyle(.borderlessButton).menuIndicator(.hidden).frame(width: 22)
        }
        .padding(.horizontal, 13).padding(.vertical, 9)
        .background {
            ZStack {
                RoundedRectangle(cornerRadius: 12).fill(.ultraThinMaterial)
                    .opacity(isCurrent ? 0.75 : hovered ? 0.08 : 0)
                RoundedRectangle(cornerRadius: 12)
                    .fill(MusicStyle.red.opacity(isCurrent ? 0.10 : hovered ? 0.018 : 0))
            }
            .shadow(color: .black.opacity(hovered ? 0.24 : 0), radius: hovered ? 8 : 0, y: hovered ? 4 : 0)
        }
        .overlay { RoundedRectangle(cornerRadius: 12).strokeBorder(MusicStyle.red.opacity(isCurrent ? 0.22 : hovered ? 0.035 : 0)) }
        .offset(y: hovered && !reduceMotion ? -2 : 0)
        .contentShape(Rectangle())
        .onTapGesture { music.open(item) }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier(isCurrent ? "current-track-row" : "track-row-" + item.id)
        .accessibilityValue(isCurrent ? (music.now.isPlaying ? "Currently playing" : "Current song, paused") : "")
        .accessibilityAction(named: "Play or open " + item.title) { music.open(item) }
        .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: hovered)
        .onHover { hovered = $0 }
        .contextMenu { MusicItemMenu(item: item, sourcePlaylistID: sourcePlaylistID) }
    }
}

struct MusicItemMenu: View {
    let item: MusicItem
    var sourcePlaylistID: String? = nil
    @Environment(MusicSession.self) private var music
    var body: some View {
        if item.isPlayable { Button("Play", systemImage: "play.fill") { music.play(item) } }
        if item.videoID != nil {
            Button("Add to playlist…", systemImage: "text.badge.plus") { music.presentAddToPlaylist(item) }
            if let sourcePlaylistID, item.removalPlaylistID == sourcePlaylistID, item.playlistEntryID != nil {
                Button("Remove from this playlist", systemImage: "text.badge.minus", role: .destructive) {
                    Task { @MainActor in
                        await Task.yield()
                        await music.removeSong(item, from: sourcePlaylistID)
                    }
                }.disabled(music.playlistMutationBusy)
            }
            Button("Start Mix / Radio", systemImage: "dot.radiowaves.left.and.right") { music.play(item, radio: true) }
        }
        if item.videoID != nil, let detail = item.detailRoute {
            Button("Open Song", systemImage: "arrow.up.right") { music.navigateFromMenu(detail) }
        } else if let route = item.containerRoute {
            Button("Open " + item.kind, systemImage: "arrow.up.right") { music.navigateFromMenu(route) }
        }
        if let album = item.album { Button("Go to Album", systemImage: "square.stack") { music.navigateFromMenu(album.route) } }
        if let artist = item.artist { Button("Go to Artist", systemImage: "person") { music.navigateFromMenu(artist.route) } }
    }
}


struct SongLikeButton: View {
    let videoID: String
    var known: Bool? = nil
    var fetchMissing = true
    @Environment(MusicSession.self) private var music
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var clickAnimation = 0
    private struct ClickPose { var scale: CGFloat = 1; var angle: Double = 0 }
    private var liked: Bool? { music.songLikes[videoID] ?? known }
    private var busy: Bool { music.songLikeBusy.contains(videoID) }
    var body: some View {
        Button {
            let previous = liked
            Task {
                await music.toggleSongLike(videoID)
                // Celebrate the confirmed state, after the symbol and color have changed.
                if let previous, music.songLikes[videoID] == !previous,
                   music.songLikeErrors[videoID] == nil, !reduceMotion {
                    await Task.yield()
                    clickAnimation += 1
                }
            }
        } label: {
            Image(systemName: liked == true ? "hand.thumbsup.fill" : "hand.thumbsup")
                .foregroundStyle(liked == true ? MusicStyle.red : .secondary)
                .opacity(busy ? 0.4 : 1)
                .overlay(alignment: .topTrailing) {
                    if liked == nil && !busy { Circle().fill(.secondary).frame(width: 4, height: 4) }
                }
                .keyframeAnimator(initialValue: ClickPose(), trigger: clickAnimation) { icon, pose in
                    icon.scaleEffect(pose.scale)
                        .offset(y: -5 * (pose.scale - 1))
                        .rotationEffect(.degrees(pose.angle), anchor: .bottom)
                } keyframes: { _ in
                    KeyframeTrack(\.scale) {
                        CubicKeyframe(1.6, duration: 0.12)
                        LinearKeyframe(1.6, duration: 0.36)
                        SpringKeyframe(1, duration: 0.22, spring: .snappy)
                    }
                    KeyframeTrack(\.angle) {
                        LinearKeyframe(0, duration: 0.12)
                        CubicKeyframe(-16, duration: 0.09)
                        CubicKeyframe(14, duration: 0.09)
                        CubicKeyframe(-10, duration: 0.09)
                        CubicKeyframe(6, duration: 0.09)
                        CubicKeyframe(0, duration: 0.22)
                    }
                }
        }
        .buttonStyle(.plain).frame(width: 24, height: 26)
        .disabled(busy || !music.ready)
        .help(music.songLikeErrors[videoID] ?? (liked == nil ? "Check like status" : liked == true ? "Unlike song" : "Like song"))
        .accessibilityLabel(liked == nil ? "Check like status" : liked == true ? "Unlike song" : "Like song")
        .accessibilityValue(liked == nil ? "Unknown" : liked == true ? "Liked" : "Not liked")
        .accessibilityIdentifier("song-like-" + videoID)
        .task(id: "\(videoID)-\(fetchMissing)") {
            if known != nil || fetchMissing { await music.loadSongLike(videoID, known: known) }
        }
    }
}

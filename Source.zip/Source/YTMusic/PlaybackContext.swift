import Foundation

// One identity for the entire playback request, independent of browse-page navigation.
struct PlaybackContext {
    private(set) var generation = UUID().uuidString
    private(set) var playlistID: String?
    private(set) var awaitingVideoID: String?

    mutating func begin(videoID: String, playlistID: String?) {
        generation = UUID().uuidString
        self.playlistID = playlistID
        awaitingVideoID = videoID
    }

    mutating func accepts(generation: String, videoID: String) -> Bool {
        guard self.generation == generation, !videoID.isEmpty else { return false }
        if let expected = awaitingVideoID {
            guard videoID == expected else { return false }
            awaitingVideoID = nil
        }
        return true
    }

    func owns(_ generation: String, playlistID: String?) -> Bool {
        self.generation == generation && self.playlistID == playlistID
    }

    static func selectedIndex(item: MusicItem, in tracks: [MusicItem]) -> Int? {
        if let position = item.playlistPosition { return position }
        if let entry = item.playlistEntryID,
           let index = tracks.firstIndex(where: { $0.playlistEntryID == entry }) { return index }
        return tracks.firstIndex(where: { $0.videoID == item.videoID })
    }

    static func reconcileQueue(existing: [MusicItem], incoming: [MusicItem], playlistID: String?) -> [MusicItem] {
        guard !incoming.isEmpty else { return existing }
        // Native playlist browsing supplies the canonical order. A /next response may
        // contain only the selected video, a short window, or alternate audio versions.
        if let playlistID, !playlistID.hasPrefix("RD"), !existing.isEmpty {
            var result = existing
            var known = Set(existing.compactMap(\.videoID))
            for item in incoming where item.videoID != nil {
                if known.insert(item.videoID!).inserted { result.append(item) }
            }
            return result
        }
        if incoming.count == 1, existing.count > 1 { return existing }
        return incoming
    }
}

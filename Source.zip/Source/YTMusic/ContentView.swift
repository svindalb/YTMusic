import SwiftUI

struct ContentView: View {
    @Environment(MusicSession.self) private var music
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var search = ""
    @State private var showQueue = false
    @State private var showExpandedPlayer = false

    var body: some View {
        ZStack {
            MusicBackdrop(palette: music.tools.activePalette, intensity: music.tools.atmosphereIntensity)
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    MusicSidebar()
                    Divider().overlay(.white.opacity(0.03))
                    VStack(spacing: 0) {
                        toolbar
                        if music.ready {
                            MusicPageView()
                                .modifier(MusicPageEntrance(isLoading: music.isLoading))
                                .id(music.route.id)
                        } else {
                            welcome
                        }
                    }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    if showQueue { QueueView().frame(width: 290).transition(.move(edge: .trailing).combined(with: .opacity)) }
                }
                PlaybackBar { if !music.now.videoID.isEmpty { showExpandedPlayer = true } }.padding(.horizontal, 16).padding(.bottom, 14).padding(.top, 10)
            }
            .blur(radius: showExpandedPlayer ? 12 : 0)
            .animation(.easeInOut(duration: reduceMotion ? 0.12 : 0.28), value: showExpandedPlayer)
            .allowsHitTesting(!showExpandedPlayer)
            .accessibilityHidden(showExpandedPlayer)
            GeometryReader { geometry in
                ZStack {
                    if showExpandedPlayer {
                        Color.black.opacity(0.26).contentShape(Rectangle())
                            .onTapGesture { showExpandedPlayer = false }
                            .accessibilityLabel("Close expanded player")
                            .transition(.opacity)
                        ExpandedNowPlayingView(size: min(520, geometry.size.width - 64, geometry.size.height - 64)) {
                            showExpandedPlayer = false
                        }
                        .transition(reduceMotion ? .opacity : .scale(scale: 0.28, anchor: .bottom).combined(with: .offset(y: 110)).combined(with: .opacity))
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .allowsHitTesting(showExpandedPlayer)
            .zIndex(1)
        }
        .animation(reduceMotion ? .easeOut(duration: 0.12) : .spring(response: 0.4, dampingFraction: 0.88), value: showExpandedPlayer)
        .onChange(of: music.now.videoID) { _, id in if id.isEmpty { showExpandedPlayer = false } }
        .preferredColorScheme(.dark)
        .tint(MusicStyle.red)
        .frame(minWidth: 1000, minHeight: 680)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: showQueue)
        .task { music.start() }
        .sheet(item: Binding(get: { music.addToPlaylistSong }, set: { music.addToPlaylistSong = $0 })) { song in
            AddToPlaylistView(song: song).environment(music)
        }
        .sheet(item: Binding(get: { music.songCreditsSong }, set: { music.songCreditsSong = $0 })) { song in
            SongCreditsView(song: song).environment(music)
        }
        .sheet(isPresented: Binding(get: { music.showLyrics }, set: { music.showLyrics = $0 })) {
            LyricsView().environment(music)
        }
        .sheet(item: Binding(get: { music.tools.sheet }, set: { music.tools.sheet = $0 }), onDismiss: {
            if let song = music.tools.playlistDestinationSong {
                music.tools.playlistDestinationSong = nil
                music.presentAddToPlaylist(song)
            }
        }) { sheet in
            ListeningToolView(sheet: sheet).environment(music)
        }
        .alert("Couldn’t update playlist", isPresented: Binding(get: { music.playlistMutationError != nil }, set: { if !$0 { music.playlistMutationError = nil } })) {
            Button("OK", role: .cancel) { music.playlistMutationError = nil }
        } message: { Text(music.playlistMutationError ?? "") }
    }

    private var toolbar: some View {
        HStack(spacing: 12) {
            Button { music.back() } label: { Image(systemName: "chevron.left") }
                .disabled(music.history.isEmpty).help("Back")
            HStack(spacing: 9) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Search songs, artists, albums…", text: $search)
                    .textFieldStyle(.plain).onSubmit {
                        let query = search.trimmingCharacters(in: .whitespacesAndNewlines)
                        if !query.isEmpty { music.navigate(.init(title: "Search: " + query, browseID: "search", search: query)) }
                    }
                if !search.isEmpty { Button { search = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.buttonStyle(.plain) }
            }.padding(.horizontal, 13).padding(.vertical, 10).modifier(MusicSurface(radius: 12))
                .frame(maxWidth: 430).disabled(!music.ready)
            Spacer(minLength: 0)
            Button { if music.ready { music.navigate(music.route, remember: false, refresh: true) } } label: { Image(systemName: "arrow.clockwise") }
                .help("Refresh").disabled(!music.ready)
            Button { showQueue.toggle() } label: { Image(systemName: "list.bullet") }.help("Show queue")
                .foregroundStyle(showQueue ? MusicStyle.red : .primary)
            ListeningToolsMenu()
            Button { music.showBrowser() } label: { Image(systemName: "person.crop.circle") }.help("Account & player window")
        }
        .buttonStyle(MusicButtonStyle())
        .padding(.horizontal, 28).padding(.top, 16).padding(.bottom, 18)
    }

    private var welcome: some View {
        VStack(spacing: 20) {
            Image(systemName: "play.circle.fill").font(.system(size: 76)).foregroundStyle(MusicStyle.gradient)
            Text("Your music.\nA little more Mac.").font(.system(size: 40, weight: .bold, design: .rounded)).multilineTextAlignment(.center)
            Text(music.connectionMessage).foregroundStyle(.secondary)
            if music.connecting { ProgressView().controlSize(.small) }
            Button("Sign in to YouTube Music") { music.showBrowser() }.buttonStyle(MusicButtonStyle(prominent: true))
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct MusicSidebar: View {
    @Environment(MusicSession.self) private var music
    @Namespace private var selection
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 9) {
                Image(systemName: "play.circle.fill").font(.system(size: 27)).foregroundStyle(MusicStyle.red)
                Text("Music").font(.system(size: 24, weight: .bold, design: .rounded))
            }.padding(.horizontal, 23).padding(.top, 22).padding(.bottom, 24)
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    ForEach(["Discover", "Your library"], id: \.self) { group in
                        Text(group.uppercased()).font(.system(size: 10, weight: .semibold)).tracking(1.5)
                            .foregroundStyle(.secondary).padding(.horizontal, 15).padding(.top, group == "Discover" ? 0 : 24).padding(.bottom, 6)
                        ForEach(LibrarySection.all.filter { $0.group == group }) { section in
                            Button { music.navigate(section.route) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: section.icon).frame(width: 19).foregroundStyle(music.route.browseID == section.id ? MusicStyle.red : .secondary)
                                    Text(section.title).font(.system(size: 13, weight: music.route.browseID == section.id ? .semibold : .medium))
                                    Spacer()
                                }.padding(.horizontal, 14).padding(.vertical, 10).contentShape(Rectangle())
                                .background {
                                    if music.route.browseID == section.id {
                                        RoundedRectangle(cornerRadius: 11).fill(.white.opacity(0.075))
                                            .matchedGeometryEffect(id: "selection", in: selection)
                                    }
                                }
                            }.buttonStyle(SidebarHoverStyle()).disabled(!music.ready)
                                .accessibilityIdentifier("section-" + section.id)
                        }
                    }
                    if !music.playlists.isEmpty || music.loadingPlaylists || music.playlistsError != nil {
                        Text("YOUR PLAYLISTS").font(.system(size: 10, weight: .semibold)).tracking(1.5).foregroundStyle(.secondary)
                            .padding(.horizontal, 15).padding(.top, 24).padding(.bottom, 6)
                        ForEach(music.playlists) { item in
                            Button { music.open(item) } label: {
                                HStack(spacing: 10) {
                                    ArtworkView(url: item.artwork, size: 30, radius: 6)
                                    Text(item.title).font(.system(size: 12)).lineLimit(1)
                                    Spacer(minLength: 0)
                                }.padding(.horizontal, 14).padding(.vertical, 5).contentShape(Rectangle())
                            }.buttonStyle(SidebarHoverStyle()).accessibilityIdentifier("playlist-" + item.id)
                        }
                        if music.loadingPlaylists {
                            HStack(spacing: 8) {
                                ProgressView().controlSize(.small)
                                Text("Loading playlists…").font(.system(size: 11)).foregroundStyle(.secondary)
                            }.padding(.horizontal, 14).padding(.vertical, 8)
                        }
                        if let message = music.playlistsError {
                            Button { Task { await music.loadPlaylists() } } label: {
                                Label(message + " Retry", systemImage: "arrow.clockwise")
                                    .font(.system(size: 11)).foregroundStyle(.secondary)
                            }.buttonStyle(.plain).padding(.horizontal, 14).padding(.vertical, 8)
                        }
                    }
                }.padding(.horizontal, 10).padding(.bottom, 16)
            }.scrollIndicators(.hidden)
            HStack(spacing: 7) {
                Circle().fill(music.ready ? .green : .orange).frame(width: 5, height: 5)
                Text(music.ready ? "Connected to YouTube Music" : "Waiting for sign in").font(.system(size: 10)).foregroundStyle(.secondary)
            }.padding(.horizontal, 24).padding(.vertical, 14)
        }
        .frame(width: 224)
        .background { Rectangle().fill(.ultraThinMaterial).opacity(0.75) }
        .animation(reduceMotion ? nil : .snappy(duration: 0.25), value: music.route.id)
    }
}

struct QueueView: View {
    @Environment(MusicSession.self) private var music
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Up next").font(.title2.bold()).padding(.top, 20)
            Text("Continuous play · related tracks follow your queue").font(.caption).foregroundStyle(.secondary)
            if music.queue.isEmpty {
                ContentUnavailableView("Your queue is quiet", systemImage: "music.note.list", description: Text("Play a song or playlist to get started."))
            } else {
                ScrollView {
                    LazyVStack(spacing: 4) {
                        ForEach(Array(music.queue.enumerated()), id: \.offset) { _, item in
                            Button { music.play(item) } label: {
                                HStack(spacing: 10) {
                                    ArtworkView(url: item.artwork, size: 38, radius: 7)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.title).font(.system(size: 12, weight: .medium)).lineLimit(2)
                                        Text(item.subtitle).font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                    if item.videoID == music.now.videoID { EqualizerView(active: music.now.isPlaying) }
                                }.padding(8).contentShape(Rectangle())
                                    .background(.white.opacity(item.videoID == music.now.videoID ? 0.07 : 0), in: RoundedRectangle(cornerRadius: 10))
                            }.buttonStyle(.plain)
                        }
                    }
                }.scrollIndicators(.hidden)
            }
        }.padding(.horizontal, 15).frame(maxHeight: .infinity)
            .background { Rectangle().fill(.ultraThinMaterial).opacity(0.75) }
    }
}


private struct SidebarHoverStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        HoverBody(configuration: configuration)
    }

    private struct HoverBody: View {
        let configuration: Configuration
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        @Environment(\.isEnabled) private var isEnabled
        @State private var hovered = false
        private var active: Bool { hovered && isEnabled }

        var body: some View {
            configuration.label
                .background {
                    RoundedRectangle(cornerRadius: 11)
                        .fill(.ultraThinMaterial).opacity(active ? 0.08 : 0)
                    RoundedRectangle(cornerRadius: 11)
                        .fill(MusicStyle.red.opacity(active ? 0.025 : 0))
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 11)
                        .strokeBorder(MusicStyle.red.opacity(active ? 0.08 : 0))
                }
                .shadow(color: .black.opacity(active ? 0.24 : 0), radius: 8, y: 4)
                .shadow(color: MusicStyle.red.opacity(active ? 0.16 : 0), radius: 9)
                .offset(y: active && !reduceMotion ? -2 : 0)
                .scaleEffect(reduceMotion ? 1 : configuration.isPressed ? 0.98 : active ? 1.015 : 1)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: active)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
                .onHover { hovered = $0 }
        }
    }
}


private struct MusicPageEntrance: ViewModifier {
    let isLoading: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var visible = false

    func body(content: Content) -> some View {
        content
            // Animate only the new page's compositing opacity. Never retain an outgoing
            // interactive List or animate its row placement during navigation.
            .opacity(reduceMotion || isLoading || visible ? 1 : 0)
            .task(id: isLoading) {
                var reset = Transaction()
                reset.disablesAnimations = true
                withTransaction(reset) { visible = false }
                guard !isLoading else { return }
                await Task.yield()
                guard !Task.isCancelled else { return }
                withAnimation(reduceMotion ? nil : .easeOut(duration: 0.22)) {
                    visible = true
                }
            }
    }
}

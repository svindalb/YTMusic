import Foundation
import CryptoKit

enum NativeMusicProbe {
    static func browse(title: String, browseID: String, context: [String: Any], version: String,
                       config: [String: Any], cookies: [HTTPCookie], signingValue: String,
                       userAgent: String, session: URLSession) async throws -> ProbeResult {
        let origin = "https://music.youtube.com"
        var components = URLComponents(string: origin + "/youtubei/v1/browse")!
        var query = [URLQueryItem(name: "prettyPrint", value: "false")]
        if let apiKey = config["apiKey"] as? String { query.append(URLQueryItem(name: "key", value: apiKey)) }
        components.queryItems = query
        var request = URLRequest(url: components.url!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(origin, forHTTPHeaderField: "Origin")
        request.setValue(origin + "/", forHTTPHeaderField: "Referer")
        request.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("67", forHTTPHeaderField: "X-YouTube-Client-Name")
        request.setValue(version, forHTTPHeaderField: "X-YouTube-Client-Version")
        request.setValue(String(describing: config["authUser"] ?? 0), forHTTPHeaderField: "X-Goog-AuthUser")
        request.setValue(origin, forHTTPHeaderField: "X-Origin")
        if let delegated = config["delegatedSession"] as? String, !delegated.isEmpty {
            request.setValue(delegated, forHTTPHeaderField: "X-Goog-PageId")
        }
        if let client = context["client"] as? [String: Any], let visitor = client["visitorData"] as? String {
            request.setValue(visitor, forHTTPHeaderField: "X-Goog-Visitor-Id")
        }
        let timestamp = String(Int(Date().timeIntervalSince1970))
        let digest = Insecure.SHA1.hash(data: Data("\(timestamp) \(signingValue) \(origin)".utf8))
            .map { String(format: "%02x", $0) }.joined()
        request.setValue("SAPISIDHASH \(timestamp)_\(digest)", forHTTPHeaderField: "Authorization")
        request.setValue(cookies.map { "\($0.name)=\($0.value)" }.joined(separator: "; "), forHTTPHeaderField: "Cookie")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["context": context, "browseId": browseID])
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ProbeError(message: "No HTTP response received.")
        }
        guard http.statusCode == 200 else {
            // Avoid exposing full URLs, response bodies, or session credentials in diagnostics.
            throw ProbeError(message: "Native request returned HTTP \(http.statusCode).")
        }
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw ProbeError(message: "Native request did not return the expected JSON response.")
        }
        if json["error"] != nil { throw ProbeError(message: "YouTube returned an API error.") }
        let responseContext = json["responseContext"] as? [String: Any]
        let appContext = responseContext?["mainAppWebResponseContext"] as? [String: Any]
        let loggedOut = appContext?["loggedOut"] as? Bool
        let contents = json["contents"] ?? json["continuationContents"]
        let samples = contents.map { collectTitles($0) } ?? []
        guard loggedOut != true, let contents, !samples.isEmpty else {
            return ProbeResult(title: title, passed: false,
                detail: "The native response was signed out or contained no recognizable items.", samples: samples)
        }
        if browseID == "FEmusic_liked_playlists" {
            let accountPlaylists = playlistIDs(contents)
            guard !accountPlaylists.isEmpty else {
                return ProbeResult(title: title, passed: false,
                    detail: "No account playlists were found; account access remains inconclusive.", samples: samples)
            }
            // A successful HTTP response alone is not proof of authentication. Make the
            // same Library request with no credentials and a minimal anonymous context.
            var anonymous = request
            for header in ["Cookie", "Authorization", "X-Goog-AuthUser", "X-Goog-PageId", "X-Goog-Visitor-Id"] {
                anonymous.setValue(nil, forHTTPHeaderField: header)
            }
            anonymous.httpBody = try JSONSerialization.data(withJSONObject: [
                "context": ["client": ["clientName": "WEB_REMIX", "clientVersion": version]],
                "browseId": browseID
            ])
            let (guestData, guestResponse) = try await session.data(for: anonymous)
            let guestStatus = (guestResponse as? HTTPURLResponse)?.statusCode ?? 0
            var guestDenied = guestStatus == 401 || guestStatus == 403
            if guestStatus == 200,
               let guest = try JSONSerialization.jsonObject(with: guestData) as? [String: Any] {
                let guestContext = guest["responseContext"] as? [String: Any]
                let guestApp = guestContext?["mainAppWebResponseContext"] as? [String: Any]
                if guestApp?["loggedOut"] as? Bool == true {
                    guestDenied = true
                } else if let guestContents = guest["contents"] ?? guest["continuationContents"] {
                    guestDenied = playlistIDs(guestContents).isEmpty
                }
            }
            guard guestDenied else {
                return ProbeResult(title: title, passed: false,
                    detail: "Playlists received, but the signed-out comparison did not establish account-only access.", samples: samples)
            }
            return ProbeResult(title: title, passed: true,
                detail: "HTTP 200 via native networking. \(accountPlaylists.count) account playlists found; a separate request without credentials cannot access the Library (HTTP \(guestStatus)).",
                samples: samples)
        }
        return ProbeResult(title: title, passed: true,
            detail: "HTTP 200 via native networking. \(data.count.formatted()) bytes of Home content received; Library separately verifies account-only access.",
            samples: samples)
    }

    static func playlistIDs(_ root: Any) -> Set<String> {
        var ids = Set<String>()
        func walk(_ value: Any) {
            if let dict = value as? [String: Any] {
                if let id = dict["browseId"] as? String, id.hasPrefix("VL") { ids.insert(id) }
                for child in dict.values { walk(child) }
            } else if let list = value as? [Any] { list.forEach(walk) }
        }
        walk(root)
        return ids
    }

    static func collectTitles(_ root: Any) -> [String] {
        var titles: [String] = []
        var seen = Set<String>()
        func text(_ value: Any?) -> String? {
            guard let dict = value as? [String: Any] else { return nil }
            if let simple = dict["simpleText"] as? String { return simple }
            if let runs = dict["runs"] as? [[String: Any]] {
                return runs.compactMap { $0["text"] as? String }.joined()
            }
            return nil
        }
        func walk(_ value: Any) {
            guard titles.count < 24 else { return }
            if let dict = value as? [String: Any] {
                if let title = text(dict["title"]), !title.isEmpty, seen.insert(title).inserted { titles.append(title) }
                // Responsive song/playlist rows store their primary title in the first flex column.
                if let columns = dict["flexColumns"] as? [[String: Any]],
                   let renderer = columns.first?["musicResponsiveListItemFlexColumnRenderer"] as? [String: Any],
                   let title = text(renderer["text"]), !title.isEmpty, seen.insert(title).inserted { titles.append(title) }
                for key in dict.keys.sorted() where key != "menu" && key != "menuRenderer" {
                    if let child = dict[key] { walk(child) }
                }
            } else if let list = value as? [Any] { list.forEach(walk) }
        }
        walk(root)
        return titles
    }
}

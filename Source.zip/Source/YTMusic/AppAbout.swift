import AppKit
import SwiftUI

@MainActor
enum AppAbout {
    private static var window: NSWindow?

    static func show() {
        if window == nil {
            let panel = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 700, height: 720),
                styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
            panel.title = "About YT Music"
            panel.isReleasedWhenClosed = false
            panel.appearance = NSAppearance(named: .darkAqua)
            panel.backgroundColor = NSColor(calibratedRed: 0.065, green: 0.055, blue: 0.085, alpha: 1)
            let host = NSHostingView(rootView: AboutContent())
            host.sizingOptions = []
            panel.contentView = host
            panel.contentMinSize = NSSize(width: 540, height: 480)
            if let screen = NSScreen.main {
                let area = screen.visibleFrame.insetBy(dx: 24, dy: 24)
                panel.setContentSize(NSSize(width: min(700, area.width), height: min(720, area.height - 28)))
            }
            panel.center()
            window = panel
        }
        window?.makeKeyAndOrderFront(nil)
        NSApp.activate()
    }

    static var credits: AttributedString {
        let fallback = NSAttributedString(string: "Your music, at home on your Mac.\n\nAn unofficial native macOS client for YouTube Music. Not affiliated with or endorsed by Google or YouTube.")
        let source = Bundle.main.url(forResource: "Credits", withExtension: "rtf").flatMap {
            try? NSAttributedString(url: $0, options: [.documentType: NSAttributedString.DocumentType.rtf], documentAttributes: nil)
        } ?? fallback
        let styled = NSMutableAttributedString(attributedString: source)
        source.enumerateAttribute(.font, in: NSRange(location: 0, length: source.length)) { value, range, _ in
            let bold = (value as? NSFont).map { NSFontManager.shared.traits(of: $0).contains(.boldFontMask) } ?? false
            styled.addAttributes([
                .font: NSFont.systemFont(ofSize: bold ? 15 : 13, weight: bold ? .semibold : .regular),
                .foregroundColor: bold ? NSColor(calibratedRed: 1, green: 0.78, blue: 0.81, alpha: 1) : NSColor(calibratedRed: 0.88, green: 0.87, blue: 0.92, alpha: 1)
            ], range: range)
        }
        return AttributedString(styled)
    }
}

private struct AboutContent: View {
    private let credits = AppAbout.credits
    private let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    private let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"

    var body: some View {
        VStack(spacing: 22) {
            HStack(spacing: 20) {
                Image(nsImage: NSApp.applicationIconImage).resizable().frame(width: 84, height: 84)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 6) {
                    Text("YT Music").font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(.white)
                    Text("Version \(version) (build \(build))").font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Color(red: 0.95, green: 0.65, blue: 0.71))
                    Text("An unofficial native client for YouTube Music")
                        .font(.system(size: 12)).foregroundStyle(.white.opacity(0.65))
                }
                Spacer(minLength: 0)
            }
            ScrollView {
                Text(credits).frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled).padding(22)
            }
            .background(Color(red: 0.09, green: 0.08, blue: 0.115), in: RoundedRectangle(cornerRadius: 18))
            .overlay { RoundedRectangle(cornerRadius: 18).strokeBorder(.white.opacity(0.08)) }
            .accessibilityLabel("App description and features")
        }
        .padding(28).frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            LinearGradient(colors: [Color(red: 0.15, green: 0.065, blue: 0.105), Color(red: 0.065, green: 0.055, blue: 0.085)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
        .preferredColorScheme(.dark)
    }
}

import AppKit
import CryptoKit
import Observation
import SwiftUI
import WebKit

struct ProbeResult: Identifiable {
    let id = UUID()
    let title: String
    let passed: Bool
    let detail: String
    var samples: [String] = []
}

struct ProbeError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor @Observable
final class LoginProbe {
    var status = "Open the sign-in window to begin."
    var results: [ProbeResult] = []
    var isBusy = false
    var hasBrowser: Bool { webView != nil }
    private var webView: WKWebView?
    private var loginWindow: NSWindow?
    private var browserDelegate: ProbeBrowserDelegate?
    // A separate persistent WebKit profile, unrelated to Safari or other apps.
    private let store = WKWebsiteDataStore(forIdentifier: UUID(uuidString: "79BFAB9B-7B7E-471C-9F83-24A2B6F138AE")!)
    private let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"

    func openLogin() {
        if let loginWindow {
            loginWindow.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            return
        }
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = store
        let browser = WKWebView(frame: .zero, configuration: configuration)
        browser.customUserAgent = userAgent
        let delegate = ProbeBrowserDelegate()
        browser.navigationDelegate = delegate
        browser.uiDelegate = delegate
        browserDelegate = delegate
        webView = browser
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1050, height: 760),
                              styleMask: [.titled, .closable, .miniaturizable, .resizable],
                              backing: .buffered, defer: false)
        window.title = "YouTube Music — Sign In"
        window.isReleasedWhenClosed = false
        window.contentView = NSHostingView(rootView: LoginBrowserView(browser: browser, probe: self))
        window.center()
        loginWindow = window
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        browser.load(URLRequest(url: URL(string: "https://music.youtube.com/")!))
        status = "Sign in in the browser window, then choose Test Native Access."
    }

    func testAccess() async {
        guard !isBusy, let webView else { return }
        isBusy = true
        results = []
        defer { isBusy = false }
        do {
            guard webView.url?.scheme == "https", webView.url?.host == "music.youtube.com" else {
                throw ProbeError(message: "Finish signing in and return to music.youtube.com before testing.")
            }
            status = "Checking the browser session…"
            // Read only the website’s own runtime configuration, not account credentials via JavaScript.
            let expression = """
            JSON.stringify({
              loggedIn: window.ytcfg?.get('LOGGED_IN') === true,
              context: window.ytcfg?.get('INNERTUBE_CONTEXT'),
              apiKey: window.ytcfg?.get('INNERTUBE_API_KEY'),
              authUser: window.ytcfg?.get('SESSION_INDEX') ?? 0,
              delegatedSession: window.ytcfg?.get('DELEGATED_SESSION_ID')
            })
            """
            guard let raw = try await webView.evaluateJavaScript(expression) as? String,
                  let data = raw.data(using: .utf8),
                  let config = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  config["loggedIn"] as? Bool == true,
                  let context = config["context"] as? [String: Any],
                  let client = context["client"] as? [String: Any],
                  let version = client["clientVersion"] as? String else {
                throw ProbeError(message: "YouTube Music does not report a signed-in session. Complete login and reload the Music page. If Google rejects this browser, this login approach has failed.")
            }
            let cookies = await store.httpCookieStore.allCookies().filter { cookie in
                let domain = cookie.domain.trimmingCharacters(in: CharacterSet(charactersIn: "."))
                return (domain == "youtube.com" || domain == "music.youtube.com")
                    && "https://music.youtube.com/youtubei/v1/browse".contains(cookie.path)
                    && (cookie.expiresDate == nil || cookie.expiresDate! > Date())
            }
            guard let signingCookie = cookies.first(where: { $0.name == "SAPISID" })
                    ?? cookies.first(where: { $0.name == "__Secure-3PAPISID" }) else {
                throw ProbeError(message: "The browser has no usable YouTube authentication cookie yet. Finish signing in first.")
            }
            results.append(ProbeResult(title: "Browser session", passed: true,
                detail: "YouTube Music reports signed in. A session cookie is available to native code."))
            let configuration = URLSessionConfiguration.ephemeral
            configuration.httpShouldSetCookies = false
            configuration.httpCookieStorage = nil
            configuration.timeoutIntervalForRequest = 30
            // Never send session cookies to a redirect target.
            let session = URLSession(configuration: configuration, delegate: NoRedirects(), delegateQueue: nil)
            defer { session.invalidateAndCancel() }
            for (title, browseID) in [("Home", "FEmusic_home"), ("Library playlists", "FEmusic_liked_playlists")] {
                status = "Fetching \(title) through native networking…"
                do {
                    let result = try await NativeMusicProbe.browse(title: title, browseID: browseID,
                        context: context, version: version, config: config, cookies: cookies,
                        signingValue: signingCookie.value, userAgent: userAgent, session: session)
                    results.append(result)
                } catch {
                    results.append(ProbeResult(title: title, passed: false, detail: error.localizedDescription))
                }
            }
            if results.count == 3 && results.allSatisfy(\.passed) {
                status = "Success: native Home and Library access works."
                loginWindow?.close()
            } else {
                status = "Session detected, but native access is not fully verified. See the results below."
            }
        } catch {
            status = error.localizedDescription
        }
    }

    func clearSession() async {
        guard !isBusy else { return }
        isBusy = true
        webView?.stopLoading()
        loginWindow?.close()
        browserDelegate?.closePopups()
        loginWindow = nil
        webView = nil
        browserDelegate = nil
        await store.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast)
        results = []
        status = "Test profile cleared. Open the sign-in window to start again."
        isBusy = false
    }
}

struct LoginBrowserView: View {
    let browser: WKWebView
    let probe: LoginProbe
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Back") { if browser.canGoBack { browser.goBack() } }
                Button("Reload") { browser.reload() }
                Button("Return to Music") {
                    browser.load(URLRequest(url: URL(string: "https://music.youtube.com/")!))
                }
                Spacer()
                Button("Test Native Access") { Task { await probe.testAccess() } }
                    .buttonStyle(.borderedProminent).disabled(probe.isBusy)
            }.padding(10)
            Text(probe.status).font(.caption).frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 12).padding(.bottom, 8).textSelection(.enabled)
            Divider()
            ProbeWebView(browser: browser)
        }
    }
}

struct ProbeWebView: NSViewRepresentable {
    let browser: WKWebView
    func makeNSView(context: Context) -> WKWebView { browser }
    func updateNSView(_ nsView: WKWebView, context: Context) {}
}

@MainActor
final class ProbeBrowserDelegate: NSObject, WKNavigationDelegate, WKUIDelegate {
    private var popupWindows: [NSWindow] = []
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        let popup = WKWebView(frame: .zero, configuration: configuration)
        popup.customUserAgent = webView.customUserAgent
        popup.navigationDelegate = self
        popup.uiDelegate = self
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 700, height: 760),
            styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
        window.title = "Google Sign In"
        window.isReleasedWhenClosed = false
        window.contentView = popup
        popupWindows.append(window)
        window.center()
        window.makeKeyAndOrderFront(nil)
        return popup
    }
    func webViewDidClose(_ webView: WKWebView) { webView.window?.close() }
    func closePopups() { popupWindows.forEach { $0.close() }; popupWindows = [] }
}

final class NoRedirects: NSObject, URLSessionTaskDelegate {
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

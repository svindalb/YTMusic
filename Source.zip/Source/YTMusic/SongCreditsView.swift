import SwiftUI

struct SongCreditSection {
    let role: String
    let contributors: String

    static func parse(_ response: [String: Any]) -> [Self] {
        MusicParser.dictionaries(response, key: "dismissableDialogContentSectionRenderer").compactMap { section in
            let role = MusicParser.text(section["title"]).trimmingCharacters(in: .whitespacesAndNewlines)
            let contributors = MusicParser.text(section["subtitle"]).trimmingCharacters(in: .whitespacesAndNewlines)
            guard !role.isEmpty, !contributors.isEmpty else { return nil }
            return Self(role: role, contributors: contributors)
        }
    }
}

struct SongCreditsView: View {
    let song: MusicItem
    @Environment(MusicSession.self) private var music
    @Environment(\.dismiss) private var dismiss
    @State private var result: Result<[SongCreditSection], Error>?
    @State private var retry = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Song credits").font(.title2.bold())
                    Text(song.title).font(.headline)
                    Text(song.subtitle).foregroundStyle(.secondary)
                }
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction)
            }
            Divider()
            switch result {
            case nil:
                ProgressView("Loading credits…").frame(maxWidth: .infinity, maxHeight: .infinity)
            case .success(let sections) where sections.isEmpty:
                ContentUnavailableView("No song credits available", systemImage: "person.text.rectangle",
                    description: Text("YouTube Music doesn’t provide credits for this track."))
            case .success(let sections):
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        ForEach(sections.indices, id: \.self) { index in
                            let section = sections[index]
                            VStack(alignment: .leading, spacing: 4) {
                                Text(section.role).font(.headline).foregroundStyle(.secondary)
                                Text(section.contributors).textSelection(.enabled)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            case .failure(let error):
                ContentUnavailableView {
                    Label("Couldn’t load credits", systemImage: "person.text.rectangle")
                } description: {
                    Text(error.localizedDescription)
                } actions: {
                    Button("Try again") { retry += 1 }
                }
            }
        }
        .padding(24)
        .frame(width: 500, height: 400)
        .task(id: retry) {
            result = nil
            do {
                let sections = try await music.loadSongCredits(for: song)
                try Task.checkCancellation()
                result = .success(sections)
            } catch is CancellationError {
                return
            } catch {
                if !Task.isCancelled { result = .failure(error) }
            }
        }
    }
}

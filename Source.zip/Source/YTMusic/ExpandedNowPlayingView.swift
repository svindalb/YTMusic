import SwiftUI

struct ExpandedNowPlayingView: View {
    let size: CGFloat
    let close: () -> Void
    @Environment(MusicSession.self) private var music
    @State private var seeking = false
    @State private var position: Double = 0

    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Text("NOW PLAYING").font(.system(size: 10, weight: .semibold)).tracking(2)
                    .foregroundStyle(.secondary)
                Spacer()
                if let song = music.currentSong { SongActionsMenu(song: song, includeSong: true, close: close) }
                LyricsButton()
                EqualizerView(active: music.now.isPlaying)
                Button(action: close) { Image(systemName: "chevron.down").font(.system(size: 13, weight: .semibold)) }
                    .buttonStyle(TransportButtonStyle(compact: true))
                    .help("Collapse Now Playing (Esc)").accessibilityLabel("Collapse Now Playing")
                    .keyboardShortcut(.cancelAction)
            }
            Spacer(minLength: 0)
            ArtworkView(url: music.now.artwork, size: size * 0.40, radius: 18, highResolution: true)
                .shadow(color: MusicStyle.red.opacity(0.18), radius: 24, y: 9)
                .shadow(color: .black.opacity(0.3), radius: 12, y: 8)
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(music.now.title).font(.system(size: 21, weight: .bold, design: .rounded)).lineLimit(2)
                    Text(music.now.artist).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 4)
                SongLikeButton(videoID: music.now.videoID)
            }.frame(maxWidth: .infinity, alignment: .leading)
            VStack(spacing: 3) {
                Slider(value: Binding(get: { seeking ? position : music.now.elapsed }, set: {
                    position = $0
                    if !seeking { music.seek($0) }
                }), in: 0...max(1, music.now.duration), onEditingChanged: { editing in
                    if editing { position = music.now.elapsed; seeking = true }
                    else { music.seek(position); seeking = false }
                })
                .controlSize(.small).disabled(music.now.duration <= 0)
                .accessibilityLabel("Expanded playback position")
                HStack {
                    Text((seeking ? position : music.now.elapsed).musicTime)
                    Spacer()
                    Text(music.now.duration.musicTime)
                }.font(.system(size: 10)).monospacedDigit().foregroundStyle(.secondary)
            }
            HStack(spacing: 22) {
                ShuffleButton()
                Button { music.previous() } label: { Image(systemName: "backward.end.fill").font(.system(size: 19)) }
                    .buttonStyle(TransportButtonStyle()).help("Previous song")
                Button { music.togglePlayback() } label: {
                    Image(systemName: music.now.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 20, weight: .bold)).contentTransition(.identity)
                }
                .buttonStyle(TransportButtonStyle(prominent: true))
                .accessibilityLabel(music.now.isPlaying ? "Pause" : "Play")
                .accessibilityIdentifier("expanded-play-pause")
                Button { music.next() } label: { Image(systemName: "forward.end.fill").font(.system(size: 19)) }
                    .buttonStyle(TransportButtonStyle()).help("Next song")
                RepeatButton()
            }
            HStack(spacing: 10) {
                Image(systemName: music.volume == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Slider(value: Binding(get: { music.volume }, set: { music.setVolume($0) }), in: 0...1)
                    .controlSize(.mini).accessibilityLabel("Expanded app volume")
                Text("\(Int(music.volume * 100))%")
                    .font(.system(size: 10)).monospacedDigit().foregroundStyle(.secondary).frame(width: 30)
            }.frame(maxWidth: 220)
            Spacer(minLength: 0)
        }
        .padding(24).frame(width: size, height: size)
        .background {
            RoundedRectangle(cornerRadius: 28).fill(.ultraThinMaterial).opacity(0.75)
            RoundedRectangle(cornerRadius: 28).fill(Color(red: 0.06, green: 0.045, blue: 0.065).opacity(0.82))
            ArtworkAtmosphereGlow(palette: music.tools.activePalette,
                intensity: music.tools.atmosphereIntensity, radius: size * 0.95)
                .clipShape(RoundedRectangle(cornerRadius: 28))
        }
        .overlay { RoundedRectangle(cornerRadius: 28).strokeBorder(.white.opacity(0.10)) }
        .shadow(color: .black.opacity(0.45), radius: 36, y: 18)
        .contentShape(RoundedRectangle(cornerRadius: 28))
        .onTapGesture { } // Consume empty panel clicks instead of dismissing through the backdrop.
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("expanded-now-playing")
        .onChange(of: music.now.videoID) { _, _ in seeking = false }
    }
}

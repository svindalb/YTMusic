import Foundation
import Observation

struct MusicRoute: Hashable, Identifiable {
    var title: String
    var browseID: String
    var params: String? = nil
    var search: String? = nil
    var song: MusicItem? = nil
    var id: String { [browseID, params ?? "", search ?? ""].joined(separator: "|") }
}

struct MusicLink: Hashable, Codable {
    var title: String
    var browseID: String
    var params: String? = nil
    var route: MusicRoute { MusicRoute(title: title, browseID: browseID, params: params) }
}

struct MusicItem: Identifiable, Hashable, Codable {
    let id: String
    var title: String
    var subtitle: String
    var artwork: URL?
    var videoID: String?
    var playlistID: String?
    var browseID: String?
    var params: String?
    var duration: String?
    var kind: String
    var playlistPosition: Int? = nil
    var playlistEntryID: String? = nil
    var removalPlaylistID: String? = nil
    var liked: Bool? = nil
    var album: MusicLink? = nil
    var artist: MusicLink? = nil
    var unavailable = false
    func matchesPlaylistSearch(_ query: String) -> Bool {
        let query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return query.isEmpty || title.localizedStandardContains(query) || subtitle.localizedStandardContains(query)
    }
    var isPlayable: Bool { videoID != nil || playlistID != nil }
    var containerRoute: MusicRoute? {
        if let browseID, browseID.hasPrefix("VL") {
            return MusicRoute(title: title, browseID: browseID, params: params)
        }
        if kind == "Playlist", let playlistID {
            return MusicRoute(title: title, browseID: "VL" + playlistID)
        }
        if videoID == nil { return route }
        return nil
    }
    var detailRoute: MusicRoute? {
        if let videoID { return MusicRoute(title: title, browseID: "song:" + videoID, song: self) }
        return containerRoute
    }
    var route: MusicRoute? {
        // A song's subtitle links belong to its album/artist, never to the song itself.
        guard videoID == nil, let browseID else { return nil }
        return MusicRoute(title: title, browseID: browseID, params: params)
    }
}

struct MusicShelf: Identifiable {
    let id: String
    var title: String
    var items: [MusicItem]
    var more: MusicRoute?
    var isList: Bool = false
}

struct MusicPage {
    var title: String
    var subtitle = ""
    var artwork: URL?
    var shelves: [MusicShelf] = []
    var filters: [MusicRoute] = []
    var playlistID: String?
    var continuation: String?
    var song: MusicItem? = nil
    var items: [MusicItem] { shelves.flatMap(\.items) }
}

struct LibrarySection: Identifiable {
    let title: String
    let icon: String
    let browseID: String
    let group: String
    var id: String { browseID }
    var route: MusicRoute { MusicRoute(title: title, browseID: browseID) }
    static let all: [LibrarySection] = [
        .init(title: "Home", icon: "house.fill", browseID: "FEmusic_home", group: "Discover"),
        .init(title: "Explore", icon: "safari", browseID: "FEmusic_explore", group: "Discover"),
        .init(title: "New releases", icon: "sparkles", browseID: "FEmusic_new_releases", group: "Discover"),
        .init(title: "Charts", icon: "chart.line.uptrend.xyaxis", browseID: "FEmusic_charts", group: "Discover"),
        .init(title: "Moods & genres", icon: "square.grid.2x2", browseID: "FEmusic_moods_and_genres", group: "Discover"),
        .init(title: "Podcasts", icon: "mic", browseID: "FEmusic_podcasts", group: "Discover"),
        .init(title: "Playlists", icon: "music.note.list", browseID: "FEmusic_liked_playlists", group: "Your library"),
        .init(title: "Songs", icon: "music.note", browseID: "FEmusic_liked_videos", group: "Your library"),
        .init(title: "Liked music", icon: "heart", browseID: "VLLM", group: "Your library"),
        .init(title: "Saved podcasts", icon: "bookmark", browseID: "FEmusic_library_non_music_audio_list", group: "Your library"),
        .init(title: "Channels", icon: "person.crop.square", browseID: "FEmusic_library_non_music_audio_channels_list", group: "Your library"),
        .init(title: "Albums", icon: "square.stack", browseID: "FEmusic_liked_albums", group: "Your library"),
        .init(title: "Artists", icon: "person.2", browseID: "FEmusic_library_corpus_track_artists", group: "Your library"),
        .init(title: "Subscriptions", icon: "person.crop.circle.badge.checkmark", browseID: "FEmusic_library_corpus_artists", group: "Your library"),
        .init(title: "History", icon: "clock.arrow.circlepath", browseID: "FEmusic_history", group: "Your library"),
        .init(title: "Uploads", icon: "icloud.and.arrow.up", browseID: "FEmusic_library_privately_owned_tracks", group: "Your library")
    ]
}

@MainActor @Observable
final class NowPlaying {
    var videoID = ""
    var title = "Nothing playing yet"
    var artist = "Choose something you love"
    var artwork: URL?
    var isPlaying = false
    var elapsed: Double = 0
    var duration: Double = 0
}

struct MusicPageCache {
    private var pages: [String: MusicPage] = [:]
    private var order: [String] = []
    let limit: Int
    init(limit: Int = 20) { self.limit = max(1, limit) }
    func page(for route: MusicRoute) -> MusicPage? { pages[route.id] }
    mutating func store(_ page: MusicPage, for route: MusicRoute) {
        order.removeAll { $0 == route.id }
        order.append(route.id)
        pages[route.id] = page
        while order.count > limit { pages.removeValue(forKey: order.removeFirst()) }
    }
}


struct MusicAccountIdentity: Equatable {
    let slot: String
    let delegated: String
    let dataSyncID: String
    init(config: [String: Any]) {
        slot = String(describing: config["authUser"] ?? 0)
        delegated = config["delegatedSession"] as? String ?? ""
        dataSyncID = config["dataSyncID"] as? String ?? ""
    }
}


// Only rewrite recognized image CDN sizing syntax; retain the original as fallback.
enum ArtworkResolution {
    // YouTube can return a successful 120x90 placeholder for an unavailable
    // high-resolution variant. A valid decode/HTTP 200 alone is insufficient.
    nonisolated static func isUsable(url: URL, width: Int, height: Int) -> Bool {
        guard width > 0, height > 0 else { return false }
        guard url.host?.lowercased() == "i.ytimg.com" else { return true }
        switch url.deletingPathExtension().lastPathComponent {
        case "maxresdefault", "hq720", "sddefault": return width > 120 || height > 90
        default: return true
        }
    }

    static func requestedPixels(pointSize: CGFloat, displayScale: CGFloat, highResolution: Bool = false) -> Int {
        let needed = max(64, Int(ceil(pointSize * max(1, displayScale) * 1.08)))
        let minimum = highResolution || pointSize >= 128 ? max(1024, needed) : needed
        return [64, 128, 256, 512, 1024, 2048].first(where: { $0 >= minimum }) ?? 2048
    }

    static func candidates(for url: URL?, highResolution: Bool) -> [URL] {
        guard highResolution else { return url.map { [$0] } ?? [] }
        return candidates(for: url, pixels: 1024)
    }

    static func candidates(for url: URL?, pixels: Int) -> [URL] {
        guard let url else { return [] }
        let host = url.host?.lowercased() ?? ""
        var candidates: [URL] = []
        if host.hasSuffix(".googleusercontent.com") || host.hasSuffix(".ggpht.com"),
           var components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            var path = components.percentEncodedPath
            func resize(_ pattern: String, transform: ([Int]) -> String) {
                guard let regex = try? NSRegularExpression(pattern: pattern) else { return }
                for match in regex.matches(in: path, range: NSRange(path.startIndex..., in: path)).reversed() {
                    guard let range = Range(match.range, in: path) else { continue }
                    let numbers = (1..<match.numberOfRanges).compactMap { index -> Int? in
                        guard let r = Range(match.range(at: index), in: path) else { return nil }
                        return Int(path[r])
                    }
                    path.replaceSubrange(range, with: transform(numbers))
                }
            }
            resize(#"=w([0-9]+)-h([0-9]+)"#) { values in
                guard values.count == 2, values.allSatisfy({ $0 > 0 }) else { return "" }
                // Preserve the source aspect ratio, and never reduce an already-large image.
                let scale = max(1, Double(pixels) / Double(min(values[0], values[1])))
                return "=w\(Int(ceil(Double(values[0]) * scale)))-h\(Int(ceil(Double(values[1]) * scale)))"
            }
            resize(#"(?<=[/=])s([0-9]+)(?=[-/.]|$)"#) { "s\(max(pixels, $0.first ?? pixels))" }
            components.percentEncodedPath = path
            if let upgraded = components.url, upgraded != url { candidates.append(upgraded) }
        } else if host == "i.ytimg.com", url.path.contains("/vi/") || url.path.contains("/vi_webp/") {
            let variants = pixels > 256 ? ["maxresdefault", "hq720", "sddefault", "hqdefault"] : ["hqdefault"]
            // Public video thumbnail resize queries can crop/limit every variant.
            // Try uncropped CDN originals first; retain the supplied URL at the end.
            for name in variants {
                var components = URLComponents(url: url, resolvingAgainstBaseURL: false)!
                components.query = nil
                components.path = url.deletingLastPathComponent().path + "/" + name + "." + url.pathExtension
                if let candidate = components.url { candidates.append(candidate) }
                if url.path.contains("/vi_webp/") {
                    components.path = components.path.replacingOccurrences(of: "/vi_webp/", with: "/vi/")
                    components.path = (components.path as NSString).deletingPathExtension + ".jpg"
                    if let candidate = components.url { candidates.append(candidate) }
                }
            }
        }
        candidates.append(url)
        var seen = Set<URL>()
        return candidates.filter { seen.insert($0).inserted }
    }
}

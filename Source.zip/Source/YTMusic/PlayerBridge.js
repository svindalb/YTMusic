(() => {
  if (location.hostname !== 'music.youtube.com' || window.__nativeMusic) return;
  const config = __NATIVE_CONFIG__;
  const media = HTMLMediaElement.prototype;
  const volumeDescriptor = Object.getOwnPropertyDescriptor(media, 'volume');
  const originalPlay = media.play;
  const originalCreate = Document.prototype.createElement;
  let expected = config.expectedVideoID || null;
  let desired = Math.max(0, Math.min(1, config.volume));
  const observed = new WeakSet();
  let lastState;
  let transportCommand = 0;
  let report = () => {};
  let shuffle = !!config.shuffle;
  let repeatMode = config.repeatMode || 'off';
  let lastModeAttempt = 0;
  const applyModes = () => {
    const video = document.querySelector('video');
    if (video) video.loop = repeatMode === 'one';
    const bar = document.querySelector('ytmusic-player-bar');
    if (!bar || (expected && playerID() !== expected)) return;
    // YouTube Music owns the queue outside the iframe player. Drive its actual
    // controls, whose state is language-independent, rather than setShuffle().
    if (Date.now() - lastModeAttempt < 400) return;
    if (typeof bar.shuffleOn === 'boolean' && bar.shuffleOn !== shuffle) {
      const button = bar.querySelector('#expand-shuffle');
      if (button) { lastModeAttempt = Date.now(); button.click(); }
    }
    const target = {off: 'NONE', all: 'ALL', one: 'ONE'}[repeatMode];
    if (['NONE', 'ALL', 'ONE'].includes(bar.repeatMode) && bar.repeatMode !== target) {
      const button = bar.querySelector('#expand-repeat');
      if (button) { lastModeAttempt = Date.now(); button.click(); }
    }
  };
  // Diagnostics contain only volume numbers/counters, never account/session data.
  const volumeStats = {blockedRaises: 0, playingSamples: 0, peakObserved: 0, maxOvershoot: 0};
  const playerID = () => document.querySelector('#movie_player')?.getVideoData?.()?.video_id || '';
  const releaseExpected = () => {
    if (expected && playerID() === expected) expected = null;
  };
  const apply = element => {
    releaseExpected();
    // A restored old track must stay silent until the requested track is loaded.
    const level = expected || (config.nativeQueue && config.expectedVideoID && playerID() !== config.expectedVideoID) ? 0 : desired;
    const actual = volumeDescriptor.get.call(element);
    if (!element.paused && !element.ended) {
      volumeStats.playingSamples++;
      volumeStats.peakObserved = Math.max(volumeStats.peakObserved, actual);
      volumeStats.maxOvershoot = Math.max(volumeStats.maxOvershoot, actual - level);
    }
    if (Math.abs(actual - level) > 0.0001) volumeDescriptor.set.call(element, level);
  };
  const watch = element => {
    if (!(element instanceof HTMLMediaElement)) return;
    apply(element);
    if (observed.has(element)) return;
    observed.add(element);
    for (const event of ['loadstart', 'loadedmetadata', 'canplay', 'play', 'playing', 'volumechange']) {
      element.addEventListener(event, () => apply(element), true);
    }
    for (const event of ['play', 'playing', 'pause', 'ended', 'seeked', 'durationchange', 'loadedmetadata']) {
      element.addEventListener(event, () => report(), true);
    }
  };
  // Enforce the app's setting at the setter and play call, rather than correcting
  // the website's volume after an audible 750ms polling interval.
  Object.defineProperty(media, 'volume', {
    configurable: true,
    enumerable: volumeDescriptor.enumerable,
    get() { return volumeDescriptor.get.call(this); },
    set(value) {
      if (Number(value) > (expected ? 0 : desired) + 0.0001) volumeStats.blockedRaises++;
      apply(this);
    }
  });
  media.play = function (...args) {
    watch(this);
    apply(this);
    if (config.pauseOnLoad && !window.__nativeRestoreReleased) { this.pause(); return Promise.resolve(); }
    return originalPlay.apply(this, args);
  };
  Document.prototype.createElement = function (...args) {
    const element = originalCreate.apply(this, args);
    watch(element);
    return element;
  };
  window.__nativeMusic = {
    generation: config.generation,
    setModes(enabled, mode) {
      shuffle = !!enabled;
      repeatMode = ['off', 'all', 'one'].includes(mode) ? mode : 'off';
      applyModes();
    },
    restorePlace(position, playing, command) {
      const video = document.querySelector('video');
      if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return false;
      video.currentTime = Math.max(0, Math.min(Number(position) || 0, Math.max(0, video.duration - 0.25)));
      const accepted = window.__nativeMusic.setPlaying(playing, command);
      // Metadata/canplay callbacks may retry website autoplay after our pause.
      // A paused held place stays guarded until an explicit native Play command.
      if (!playing) window.__nativeRestoreReleased = false;
      return accepted;
    },
    setPlaying(playing, command) {
      const video = document.querySelector('video');
      if (!video) return false;
      window.__nativeRestoreReleased = true;
      transportCommand = command;
      window.__nativeAutoplayAttempted = true;
      if (playing) {
        watch(video);
        video.play().then(() => report()).catch(() => report());
      } else {
        video.pause();
      }
      report();
      return true;
    },
    setVolume(value) {
      const next = Number(value);
      if (!Number.isFinite(next)) return;
      desired = Math.max(0, Math.min(1, next));
      document.querySelectorAll('video,audio').forEach(watch);
      volumeStats.peakObserved = 0;
      volumeStats.maxOvershoot = 0;
      volumeStats.playingSamples = 0;
    },
    playRequested() {
      releaseExpected();
      if (expected) return;
      const video = document.querySelector('video');
      if (video) { watch(video); video.play().catch(() => {}); }
    }
  };
  // A held queue belongs to the native app. Stop the site's ended handler from
  // replacing it with newly generated recommendations before advancing natively.
  document.addEventListener('ended', event => {
    if (config.nativeQueue) { event.stopImmediatePropagation(); report(); }
  }, true);
  new MutationObserver(records => {
    for (const record of records) for (const node of record.addedNodes) {
      watch(node);
      node.querySelectorAll?.('video,audio').forEach(watch);
    }
  }).observe(document, {subtree: true, childList: true});
  document.querySelectorAll('video,audio').forEach(watch);
  report = () => {
    applyModes();
    releaseExpected();
    document.querySelectorAll('video,audio').forEach(watch);
    const player = document.querySelector('#movie_player');
    const video = document.querySelector('video');
    const data = player?.getVideoData?.() || {};
    const bar = document.querySelector('ytmusic-player-bar');
    // Never use the requested URL as evidence that the actual player loaded it.
    const id = data.video_id || '';
    // The player-bar image is a tiny thumbnail. Prefer the largest metadata image.
    const thumbnails = player?.getPlayerResponse?.()?.videoDetails?.thumbnail?.thumbnails || data.thumbnail?.thumbnails || [];
    const largest = [...thumbnails].sort((a, b) => (b.width || 0) - (a.width || 0))[0];
    const image = largest?.url || bar?.querySelector('img')?.src || (id ? 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' : '');
    let playlistIndex = null;
    let playlistID = null;
    try {
      const watchURL = new URL(location.href);
      if (watchURL.searchParams.get('v') === id) {
        const index = watchURL.searchParams.get('index');
        if (index && /^\d+$/.test(index)) playlistIndex = Math.max(0, Number(index) - 1);
        playlistID = watchURL.searchParams.get('list');
      }
    } catch (_) {}
    const state = {
      generation: config.generation, transportCommand, id, playlistIndex, playlistID,
      title: data.title || bar?.querySelector('.title')?.textContent?.trim() || '',
      artist: data.author || bar?.querySelector('.byline')?.textContent?.trim() || '',
      artwork: image,
      playing: !!video && !video.paused && !video.ended,
      elapsed: video?.currentTime || 0,
      duration: Number.isFinite(video?.duration) ? video.duration : 0,
      ended: !!video?.ended,
      actualVolume: video ? volumeDescriptor.get.call(video) : desired,
      volumeDiagnostics: {desired, ...volumeStats},
      playbackModes: {shuffle, repeatMode, barShuffle: bar?.shuffleOn, barRepeat: bar?.repeatMode, videoLoop: !!video?.loop}
    };
    const serialized = JSON.stringify(state);
    if (serialized !== lastState) {
      lastState = serialized;
      window.webkit.messageHandlers.musicState.postMessage(state);
    }
    if (video && !video.paused && !video.ended) window.__nativeAutoplayAttempted = true;
    if (config.autoplay && !expected && video?.paused && !video.ended && !window.__nativeAutoplayAttempted) {
      window.__nativeAutoplayAttempted = true;
      window.__nativeMusic.playRequested();
    }
  };
  document.addEventListener('DOMContentLoaded', report, {once: true});
  setInterval(report, 500);
})();

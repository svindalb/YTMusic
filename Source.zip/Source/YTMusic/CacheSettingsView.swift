import SwiftUI

struct CacheSettingsView: View {
    @Environment(MusicSession.self) private var music

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Label("Cache & storage", systemImage: "internaldrive").font(.title2.bold())
            Text("Temporary playback and artwork caches are cleared at launch, then every six hours when playback is paused.")
                .foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            Label("Your login stays saved", systemImage: "lock.shield")
                .foregroundStyle(MusicStyle.red)
            Text("Cookies and account storage are preserved. Clearing cache doesn’t remove playlists, likes, or your music preferences.")
                .font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if let date = music.lastCacheCleanup {
                Text("Last cleared: \(date.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 12) {
                Button { music.requestCacheCleanup() } label: {
                    Label(music.clearingCache ? "Clearing…" : "Clear cache", systemImage: "arrow.triangle.2.circlepath")
                }
                .buttonStyle(MusicButtonStyle()).disabled(music.clearingCache || music.cacheCleanupPending)
                if music.clearingCache { ProgressView().controlSize(.small) }
            }
            if let message = music.cacheCleanupMessage {
                Text(message).font(.callout).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Divider()
            Label("Artwork atmosphere", systemImage: "paintpalette").font(.headline)
            AtmosphereControls()
        }
        .padding(26).frame(width: 430)
        .background { MusicBackdrop(palette: music.tools.activePalette, intensity: music.tools.atmosphereIntensity) }
        .preferredColorScheme(.dark)
    }
}

import Foundation

// Only inspect metadata belonging to this exact panel, never sibling queue entries.
enum PlaybackMetadata {
    static func item(from panel: [String: Any], playlistID: String?) -> MusicItem? {
        guard let id = panel["videoId"] as? String else { return nil }
        var item = MusicItem(id: id, title: MusicParser.text(panel["title"]),
            subtitle: MusicParser.text(panel["longBylineText"]), artwork: MusicParser.artwork(panel["thumbnail"] ?? [:]),
            videoID: id, playlistID: playlistID, duration: MusicParser.text(panel["lengthText"]), kind: "Song")
        func collect(_ value: Any) {
            if let dict = value as? [String: Any] {
                if let name = dict["text"] as? String,
                   let endpoint = dict["navigationEndpoint"] as? [String: Any],
                   let browse = endpoint["browseEndpoint"] as? [String: Any],
                   let browseID = browse["browseId"] as? String {
                    let link = MusicLink(title: name, browseID: browseID, params: browse["params"] as? String)
                    if browseID.hasPrefix("UC"), item.artist == nil { item.artist = link }
                    if browseID.hasPrefix("MPRE"), item.album == nil { item.album = link }
                }
                for key in dict.keys.sorted() where key != "navigationEndpoint" { if let child = dict[key] { collect(child) } }
            } else if let list = value as? [Any] { list.forEach(collect) }
        }
        collect(panel["longBylineText"] ?? [:])
        collect(panel["shortBylineText"] ?? [:])
        for menu in MusicParser.dictionaries(panel["menu"] ?? [:], key: "menuNavigationItemRenderer") {
            guard let browse = (menu["navigationEndpoint"] as? [String: Any])?["browseEndpoint"] as? [String: Any],
                  let id = browse["browseId"] as? String else { continue }
            if id.hasPrefix("MPRE"), item.album == nil { item.album = MusicLink(title: "Album", browseID: id, params: browse["params"] as? String) }
            if id.hasPrefix("UC"), item.artist == nil { item.artist = MusicLink(title: "Artist", browseID: id, params: browse["params"] as? String) }
        }
        return item
    }

    static func merge(_ base: MusicItem, with extra: MusicItem) -> MusicItem {
        guard base.videoID != nil, base.videoID == extra.videoID else { return base }
        var result = base
        result.artist = result.artist ?? extra.artist
        result.album = result.album ?? extra.album
        result.artwork = result.artwork ?? extra.artwork
        result.duration = result.duration ?? extra.duration
        result.liked = result.liked ?? extra.liked
        return result
    }
}

import Foundation

struct HeldPlace: Codable, Identifiable {
    var id = UUID()
    var savedAt = Date()
    var song: MusicItem
    var queue: [MusicItem]
    var playlistID: String?
    var selectedIndex: Int?
    var elapsed: Double
    var wasPlaying: Bool
    var shuffle: Bool
    var repeatMode: String
    var radioTrailID: UUID?
}

struct RadioVisit: Codable, Identifiable {
    var id = UUID()
    var playedAt = Date()
    var song: MusicItem
}

struct RadioTrail: Codable, Identifiable {
    var id = UUID()
    var startedAt = Date()
    var seed: MusicItem
    var playlistID: String
    var visits: [RadioVisit] = []
}

struct LocalListeningData: Codable {
    var version = 1
    var heldPlace: HeldPlace?
    var trails: [RadioTrail] = []
    var discoveries: [MusicItem] = []

    // Ratings and write permission hints are live account state, not local facts.
    // Old snapshots must never override a fresh server rating after relaunch.
    func withoutAccountHints() -> Self {
        func clean(_ item: MusicItem) -> MusicItem {
            var copy = item
            copy.liked = nil
            copy.removalPlaylistID = nil
            return copy
        }
        var result = self
        if var held = result.heldPlace {
            held.song = clean(held.song); held.queue = held.queue.map(clean)
            result.heldPlace = held
        }
        result.trails = result.trails.map { trail in
            var copy = trail
            copy.seed = clean(copy.seed)
            copy.visits = copy.visits.map { visit in var item = visit; item.song = clean(item.song); return item }
            return copy
        }
        result.discoveries = result.discoveries.map(clean)
        return result
    }
}

enum ListeningToolSheet: String, Identifiable {
    case place, doctor, radio, atmosphere
    var id: String { rawValue }
}

struct DuplicateGroup: Identifiable {
    var videoID: String
    var entries: [MusicItem]
    var id: String { videoID }
}

struct PlaylistAudit {
    var playlist: MusicItem
    var entries: [MusicItem]
    var comparedPlaylist: MusicItem?
    var comparedCount: Int
    var duplicates: [DuplicateGroup]
    var unavailable: [MusicItem]
    var overlap: [MusicItem]
    var removableExtras: [MusicItem] {
        duplicates.flatMap { $0.entries.dropFirst() }.filter {
            $0.playlistEntryID != nil && $0.removalPlaylistID == playlist.playlistID
        }
    }

    static func make(playlist: MusicItem, entries: [MusicItem], compared: MusicItem? = nil, other: [MusicItem] = []) -> Self {
        let groups = Dictionary(grouping: entries.filter { $0.videoID != nil }, by: { $0.videoID! })
        var seen = Set<String>()
        let duplicates = entries.compactMap { item -> DuplicateGroup? in
            guard let id = item.videoID, seen.insert(id).inserted, let copies = groups[id], copies.count > 1 else { return nil }
            return DuplicateGroup(videoID: id, entries: copies)
        }
        let otherIDs = Set(other.compactMap(\.videoID))
        var sharedIDs = Set<String>()
        return Self(playlist: playlist, entries: entries, comparedPlaylist: compared, comparedCount: other.count,
            duplicates: duplicates,
            unavailable: entries.filter { $0.unavailable || $0.videoID == nil },
            overlap: entries.filter { item in
                guard let id = item.videoID, otherIDs.contains(id) else { return false }
                return sharedIDs.insert(id).inserted
            })
    }

    // Re-evaluate against a fresh server snapshot. Never remove a last remaining
    // copy, an unrelated occurrence, or an entry without its exact removal ID.
    static func removalActions(selected: [MusicItem], fresh: [MusicItem], playlistID: String) throws -> [[String: Any]] {
        guard !selected.isEmpty else { return [] }
        let selectedIDs = selected.compactMap(\.playlistEntryID)
        guard selectedIDs.count == selected.count, Set(selectedIDs).count == selected.count else {
            throw ProbeError(message: "Some selected entries cannot be identified safely. Scan again.")
        }
        for item in selected {
            guard let videoID = item.videoID, let entryID = item.playlistEntryID,
                  item.removalPlaylistID == playlistID,
                  fresh.contains(where: { $0.videoID == videoID && $0.playlistEntryID == entryID && $0.removalPlaylistID == playlistID }) else {
                throw ProbeError(message: "This playlist changed since the scan. Scan again before removing duplicates.")
            }
        }
        let removing = Dictionary(grouping: selected, by: { $0.videoID! })
        for (id, entries) in removing where fresh.filter({ $0.videoID == id }).count <= entries.count {
            throw ProbeError(message: "A selected song no longer has another copy. Scan again; no changes were made.")
        }
        return selected.map { ["action": "ACTION_REMOVE_VIDEO", "setVideoId": $0.playlistEntryID!, "removedVideoId": $0.videoID!] }
    }
}

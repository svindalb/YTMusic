import Foundation
import ImageIO
import AppKit

nonisolated final class MockArtworkProtocol: URLProtocol, @unchecked Sendable {
    nonisolated(unsafe) static var requests = 0
    nonisolated(unsafe) static var succeed = true
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.requests += 1
        let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: 8, pixelsHigh: 8, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
        let data = bitmap.representation(using: .png, properties: [:])!
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: Self.succeed ? 200 : 404, httpVersion: nil, headerFields: nil)!, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
@main struct ReviewChecks {
    @MainActor static func main() async throws {
        var count = 0
        func expect(_ condition: Bool, _ message: String) { precondition(condition, message); count += 1 }
        func row(_ entry: String) -> [String: Any] {
            ["musicResponsiveListItemRenderer": ["title": ["simpleText": "Track"], "playlistItemData": ["videoId": "same", "playlistSetVideoId": entry]]]
        }
        let json: [String: Any] = ["onResponseReceivedActions": [["appendContinuationItemsAction": ["continuationItems": [row("first"), row("second")]]]]]
        let playlist = MusicParser.page(json, fallback: "Playlist", preservePlaylistEntries: true)
        expect(playlist.shelves.flatMap(\.items).count == 2, "Continuation retains duplicate occurrences")
        expect(MusicParser.page(json, fallback: "Search").shelves.flatMap(\.items).count == 1, "Search still deduplicates identical results")
        var song = MusicItem(id: "same", title: "Track", subtitle: "Artist", videoID: "same", kind: "Song")
        song.liked = true; song.removalPlaylistID = "PLsource"; song.playlistEntryID = "entry"
        let held = HeldPlace(song: song, queue: [song], elapsed: 12, wasPlaying: false, shuffle: false, repeatMode: "none")
        let original = LocalListeningData(heldPlace: held, trails: [RadioTrail(seed: song, playlistID: "RDsame", visits: [RadioVisit(song: song)])], discoveries: [song])
        let clean = original.withoutAccountHints()
        let items = [clean.heldPlace!.song] + clean.heldPlace!.queue + [clean.trails[0].seed, clean.trails[0].visits[0].song] + clean.discoveries
        expect(items.allSatisfy { $0.liked == nil && $0.removalPlaylistID == nil }, "All local snapshots discard stale account hints")
        expect(items.allSatisfy { $0.videoID == "same" && $0.playlistEntryID == "entry" }, "Cleaning preserves song and occurrence identities")
        expect(original.heldPlace?.song.liked == true, "Snapshot cleaning does not mutate live state")
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let account = MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "review-test"])
        let tools = ListeningTools(); tools.connect(account, directory: folder); tools.hold(held)
        let file = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil).first!
        let persisted = try JSONDecoder().decode(LocalListeningData.self, from: Data(contentsOf: file))
        expect(persisted.heldPlace?.song.liked == nil, "New persisted snapshots omit stale ratings")
        try JSONEncoder().encode(original).write(to: file)
        let restored = ListeningTools(); restored.connect(account, directory: folder)
        expect(restored.heldPlace?.song.liked == nil && restored.heldPlace?.song.removalPlaylistID == nil, "Legacy snapshots sanitized on read")
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [MockArtworkProtocol.self]
        let loader = ArtworkLoader(session: URLSession(configuration: config))
        let urls = [URL(string: "https://example.test/image.png")!]
        let first = await loader.data(for: urls); let second = await loader.data(for: urls)
        expect(first != nil && second != nil && MockArtworkProtocol.requests == 1, "Artwork memory cache reuses downloads")
        await loader.clear(); let third = await loader.data(for: urls)
        expect(third != nil && MockArtworkProtocol.requests == 2, "Clear cache drops stored artwork")
        await loader.clear(); MockArtworkProtocol.succeed = false
        let failed = await loader.data(for: urls); MockArtworkProtocol.succeed = true
        let stillFailed = await loader.data(for: urls)
        expect(failed == nil && stillFailed == nil && MockArtworkProtocol.requests == 3, "Failed artwork is briefly cached")
        await loader.clear(); let recovered = await loader.data(for: urls)
        expect(recovered != nil && MockArtworkProtocol.requests == 4, "Clear cache retries previously failed artwork")
        print("PASS \(count) review regression checks")
    }
}

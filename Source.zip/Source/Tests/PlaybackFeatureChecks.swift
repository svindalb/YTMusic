import Foundation

@main struct FeatureChecks {
    @MainActor static func main() {
        var count = 0
        func expect(_ value: Bool, _ message: String) { precondition(value, message); count += 1 }
        expect(MusicRepeatMode.off.next == .all && MusicRepeatMode.all.next == .one && MusicRepeatMode.one.next == .off, "Repeat cycles off / queue / song")
        expect(LyricsParser.browseID(in: ["tabs": [["tabRenderer": ["endpoint": ["browseEndpoint": ["browseId": "MPLY_test"]]]]]]) == "MPLY_test", "Lyrics endpoint is read from the lyrics tab")
        expect(LyricsParser.browseID(in: ["tabs": [["tabRenderer": ["unselectable": true, "endpoint": ["browseEndpoint": ["browseId": "MPLY_test"]]]]]]) == nil, "Unavailable tab must not fetch")
        expect(LyricsParser.browseID(in: ["tabs": [["tabRenderer": ["endpoint": ["browseEndpoint": ["browseId": "MPRE_album"]]]]]]) == nil, "Album browse must never be treated as lyrics")
        let parsed = LyricsParser.parse(["contents": ["musicDescriptionShelfRenderer": ["description": ["runs": [["text": "First line\n"], ["text": "Second line"]]], "footer": ["runs": [["text": "Source: test"]]]]]])
        expect(parsed?.text == "First line\nSecond line" && parsed?.source == "Source: test", "Lyric lines and attribution are preserved")
        expect(LyricsParser.parse([:]) == nil, "Missing lyrics is a normal unavailable result")
        let session = MusicSession()
        session.setShuffle(true); session.setRepeat(.one); session.showLyrics = true
        session.resetAccountState()
        expect(!session.shuffle && session.repeatMode == .off && !session.showLyrics && session.lyrics == nil && !session.loadingLyrics, "Account reset clears feature state")
        print("PASS: \(count) playback mode / lyrics / account reset checks")
    }
}

import Foundation
import ImageIO

@main struct NavigationArtworkChecks {
    @MainActor static func main() async {
        var checks = 0
        func expect(_ value: Bool, _ message: String) { precondition(value, message); checks += 1 }
        func link(_ text: String, _ id: String) -> [String: Any] {
            ["text": text, "navigationEndpoint": ["browseEndpoint": ["browseId": id]]]
        }
        let panel: [String: Any] = ["videoId": "current", "title": ["simpleText": "Current song"],
            "longBylineText": ["runs": [link("Correct artist", "UCcorrect"), link("Correct album", "MPREcorrect")]]]
        let parsed = PlaybackMetadata.item(from: panel, playlistID: "PLtest")!
        expect(parsed.artist?.browseID == "UCcorrect" && parsed.album?.browseID == "MPREcorrect", "Current-panel links must identify the actual artist and album")
        expect(parsed.videoID == "current" && parsed.playlistID == "PLtest", "Metadata extraction preserves exact video/playlist identity")
        let video = PlaybackMetadata.item(from: ["videoId": "upload", "longBylineText": ["runs": [link("Uploader", "UCupload")]]], playlistID: nil)!
        expect(video.album == nil && video.artist?.browseID == "UCupload", "Videos without album metadata must not invent an album")
        var wrong = parsed; wrong.videoID = "unrelated"
        let plain = MusicItem(id: "current", title: "Current", subtitle: "", videoID: "current", kind: "Song")
        expect(PlaybackMetadata.merge(plain, with: wrong).artist == nil, "A sibling queue track must never supply navigation links")
        expect(PlaybackMetadata.merge(plain, with: parsed).album?.browseID == "MPREcorrect", "Sparse Now Playing metadata gains the exact album link")
        var known = plain; known.album = MusicLink(title: "Already known", browseID: "MPREknown")
        expect(PlaybackMetadata.merge(known, with: parsed).album?.browseID == "MPREknown", "Existing explicit album metadata wins over fallback metadata")
        let session = MusicSession()
        session.now.videoID = "current"; session.now.title = "Current title"
        session.queue = [wrong, parsed]
        expect(session.currentSong?.artist?.browseID == "UCcorrect", "Now Playing navigation skips unrelated queue entries")
        let previous = MusicItem(id: "previous", title: "Previous", subtitle: "", videoID: "previous", kind: "Song")
        expect(session.enrichedSong(previous).album == nil, "Old Song views must not acquire the newly playing song's album")
        session.resetAccountState()
        expect(session.currentSong == nil, "Account reset removes current-song navigation")
        let base = URL(string: "https://i.ytimg.com/vi/AJkp9mICONI/hqdefault.jpg")!
        let maxres = URL(string: "https://i.ytimg.com/vi/AJkp9mICONI/maxresdefault.jpg")!
        expect(!ArtworkResolution.isUsable(url: maxres, width: 120, height: 90), "Reject successful tiny placeholders for large variants")
        expect(ArtworkResolution.isUsable(url: maxres, width: 1280, height: 720), "Accept real high-resolution video thumbnails")
        expect(ArtworkResolution.isUsable(url: base, width: 480, height: 360), "Accept the original standard thumbnail")
        expect(ArtworkResolution.isUsable(url: base, width: 480, height: 270), "Cropped standard thumbnails must remain valid")
        expect(!ArtworkResolution.isUsable(url: base, width: 0, height: 0), "Reject invalid image dimensions")
        expect(ArtworkResolution.candidates(for: base, pixels: 1024).last == base, "Fallback always retains the original thumbnail")
        let cropped = URL(string: "https://i.ytimg.com/vi/AJkp9mICONI/hqdefault.jpg?sqp=resize&rs=signature")!
        let options = ArtworkResolution.candidates(for: cropped, pixels: 1024)
        expect(options.first?.query == nil && options.last == cropped, "Try uncropped video originals while retaining the exact supplied URL fallback")
        let webp = URL(string: "https://i.ytimg.com/vi_webp/AJkp9mICONI/hqdefault.webp")!
        expect(ArtworkResolution.candidates(for: webp, pixels: 1024).contains(base), "Unavailable WebP variants retain a standard JPEG fallback")
        if CommandLine.arguments.contains("--live") {
            let data = await ArtworkLoader.shared.data(for: ArtworkResolution.candidates(for: base, pixels: 1024))
            let source = data.flatMap { CGImageSourceCreateWithData($0 as CFData, nil) }
            let properties = source.flatMap { CGImageSourceCopyPropertiesAtIndex($0, 0, nil) as? [CFString: Any] }
            expect(properties?[kCGImagePropertyPixelWidth] as? Int == 480 && properties?[kCGImagePropertyPixelHeight] as? Int == 360,
                "Exact reported video falls through missing large variants to its working standard thumbnail")
        }
        print("PASS: \(checks) song navigation / metadata isolation / artwork fallback checks")
    }
}

# Parser and playback regression checks

Run from the project root. These checks do not sign in or contact YouTube.

```sh
mkdir -p /tmp/ytmusic-parser-checks
xcrun swiftc -module-cache-path /tmp/ytmusic-parser-checks/cache -parse-as-library \
  YTMusic/MusicModels.swift YTMusic/PlaybackContext.swift YTMusic/MusicParser.swift \
  Tests/MusicParserChecks.swift -o /tmp/ytmusic-parser-checks/run
/tmp/ytmusic-parser-checks/run
node Tests/PlayerBridgeChecks.cjs YTMusic/PlayerBridge.js
```

68 Swift checks cover track identity, playlist context, metadata, nested headers/artwork,
pagination, search/filter layouts, playlist shuffle overlays, stale player messages,
queue ownership, queue retention, playlist-card navigation priority, separate song/album/artist
destinations, bounded navigation-cache retention, liked/unliked/unknown rating parsing, exact playlist-removal endpoint identity, and loaded-song search matching.

11 JavaScript checks run the actual injected player bridge against mock media elements.
They verify volume before `play()`, website volume restoration, replacement media,
muting, and respecting a user pause. A further 10,000 writes simulate website volume changes during an already-playing song, with three checks on ongoing-volume diagnostics. They do not substitute for an acoustic measurement
or live testing against a changing YouTube player.


The bridge checks also include nine transport assertions: play/pause reports without a polling
step, command acknowledgements, rapid alternating requests, and missing-media failure.


The parser checks additionally cover account identity, selected duplicate occurrences, and
writable-only playlist options. MusicSessionChecks.swift supplies six integration checks using
the actual session object for reset isolation and invalidated-page cache prevention. Compile it
with all YTMusic/*.swift sources except MyApp.swift, -parse-as-library and
-default-isolation MainActor, then run on macOS. These checks do not send playlist mutations.

CacheMaintenanceChecks.swift exercises the exact cache-removal allowlist and six-hour policy,
then runs cache cleanup against an isolated WebKit profile and checks cookies, local storage,
and session storage remain intact. Run on macOS:

```sh
xcrun swiftc -module-cache-path /tmp/ytmusic-parser-checks/cache -parse-as-library \
  -default-isolation MainActor YTMusic/CacheMaintenance.swift \
  Tests/CacheMaintenanceChecks.swift -o /tmp/ytmusic-parser-checks/cache-checks
/tmp/ytmusic-parser-checks/cache-checks
```

Artwork checks cover high-resolution CDN URLs, original fallbacks, video variants, small-image requests, unknown hosts and missing artwork.

Shared artwork guards additionally cover Retina sizing, prominent vs small images, avatar sizing formats, aspect ratio/query preservation, large originals and nested thumbnail resolution selection.


NavigationArtworkChecks.swift adds 18 checks for exact-track artist/album destinations,
missing album metadata, cross-track metadata isolation, current-song/account reset,
thumbnail placeholder validation, cropped originals and WebP/JPEG fallback. Compile with
all YTMusic/*.swift sources except MyApp.swift, -parse-as-library and
-default-isolation MainActor. Run without arguments for offline checks; --live additionally
fetches public thumbnails for the reported video AJkp9mICONI and verifies that unavailable
large variants fall through to the usable 480x360 original. No login or mutations are used.


ListeningToolsChecks.swift supplies 31 checks for exact duplicate grouping, removal
preflight safety (changed entries, last-copy protection, foreign playlists, repeated
selection IDs), unavailable metadata, persistence/relaunch, account isolation,
radio/tray bounds, invalid artwork and dominant colour extraction. Compile with all
YTMusic/*.swift files except MyApp.swift using -parse-as-library and
-default-isolation MainActor. It uses temporary local files and sends no mutations.
The bridge suite additionally has 13 saved-place checks for real seeking, paused
restore, late website autoplay suppression, app volume and held-queue ownership.


ReviewChecks.swift adds 11 offline regression checks for duplicate continuation entries,
local snapshot sanitization (including legacy files), and artwork success/failure cache
clearing. Compile with all YTMusic/*.swift except MyApp.swift, -parse-as-library and
-default-isolation MainActor. Artwork responses are mocked; storage uses a disposable
temporary folder. No account changes or external requests are sent.

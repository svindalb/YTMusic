import AppKit
import Foundation

@main
struct MusicSessionChecks {
    @MainActor static func main() {
        var checks = 0
        func expect(_ value: @autoclosure () -> Bool, _ message: String) {
            precondition(value(), message)
            checks += 1
        }
        let session = MusicSession()
        session.ready = true
        session.page = MusicPage(title: "Old private page")
        session.route = MusicRoute(title: "Old", browseID: "old-account-page")
        session.playlists = [MusicItem(id: "old", title: "Old playlist", subtitle: "", kind: "Playlist")]
        session.queue = session.playlists
        session.history = [session.route]
        session.songLikes = ["old-video": true]
        session.songLikeBusy = ["old-video"]
        session.now.videoID = "old-video"
        session.addToPlaylistSong = session.playlists.first
        let oldGeneration = session.accountGeneration
        session.resetAccountState()
        expect(session.accountGeneration != oldGeneration, "Account reset must reject old async generations")
        expect(!session.ready && session.page == nil, "Signed-out UI must have no private page")
        expect(session.queue.isEmpty && session.playlists.isEmpty && session.history.isEmpty, "Reset must clear account-owned collections")
        expect(session.songLikes.isEmpty && session.songLikeBusy.isEmpty, "Reset must clear ratings and busy flags")
        expect(session.now.videoID.isEmpty && session.addToPlaylistSong == nil, "Reset must clear playback and account-owned sheet")
        session.ready = true
        let liked = MusicRoute(title: "Liked", browseID: "VLLM")
        session.route = liked
        session.page = MusicPage(title: "Stale liked page")
        session.invalidatePages()
        session.navigate(MusicRoute(title: "Home", browseID: "FEmusic_home"))
        session.navigate(liked)
        expect(session.page == nil && session.isLoading, "Navigating away must not recache invalidated visible page")
        session.resetAccountState()
        print("PASS: \(checks) actual MusicSession lifecycle/cache checks")
    }
}

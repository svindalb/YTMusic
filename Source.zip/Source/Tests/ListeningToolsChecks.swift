import Foundation
import ImageIO
import UniformTypeIdentifiers

@main struct ListeningToolsChecks {
    @MainActor static func main() async throws {
        var checks = 0
        func expect(_ value: Bool, _ message: String) { precondition(value, message); checks += 1 }
        func entry(_ id: String, _ occurrence: String, playlist: String = "PLsource") -> MusicItem {
            MusicItem(id: occurrence, title: "Same title", subtitle: "Artist", videoID: id, playlistID: playlist, kind: "Song", playlistEntryID: occurrence, removalPlaylistID: playlist)
        }
        let first = entry("a", "first"), extra = entry("a", "extra"), other = entry("b", "other")
        let playlist = MusicItem(id: "VLPLsource", title: "Source", subtitle: "", playlistID: "PLsource", kind: "Playlist")
        var unavailable = entry("c", "unavailable"); unavailable.unavailable = true
        let audit = PlaylistAudit.make(playlist: playlist, entries: [first, extra, other, unavailable], compared: playlist, other: [first, extra])
        expect(audit.duplicates.count == 1 && audit.duplicates[0].entries.count == 2, "Only identical video IDs are duplicates; equal titles are not")
        expect(audit.removableExtras.map(\.playlistEntryID) == ["extra"], "Keep the first occurrence and offer only extra exact entries")
        expect(audit.unavailable.map(\.videoID) == ["c"], "Only flagged or unidentified entries are unavailable findings")
        expect(audit.overlap.count == 1 && audit.overlap[0].videoID == "a", "Shared songs are unique exact-ID matches")
        let actions = try PlaylistAudit.removalActions(selected: [extra], fresh: [first, extra], playlistID: "PLsource")
        expect(actions.count == 1 && actions[0]["setVideoId"] as? String == "extra", "Removal addresses the selected exact duplicate occurrence")
        func rejects(_ selected: [MusicItem], _ fresh: [MusicItem], _ id: String = "PLsource") -> Bool {
            do { _ = try PlaylistAudit.removalActions(selected: selected, fresh: fresh, playlistID: id); return false } catch { return true }
        }
        expect(rejects([extra], [extra]), "Never delete the last copy after the playlist changes")
        expect(rejects([extra], [first]), "Already removed or replaced occurrences force a rescan")
        expect(rejects([first, extra], [first, extra]), "Cannot remove every copy in a group")
        expect(rejects([extra, extra], [first, extra]), "Reject duplicated selection IDs")
        expect(rejects([extra], [first, extra], "PLanother"), "Never remove an entry from a different playlist")
        var readOnly = extra; readOnly.playlistEntryID = nil
        expect(rejects([readOnly], [first, readOnly]), "Missing removal IDs cannot become a guessed removal")
        let readOnlyReport = PlaylistAudit.make(playlist: playlist, entries: [first, readOnly])
        expect(readOnlyReport.duplicates.count == 1 && readOnlyReport.removableExtras.isEmpty, "Read-only duplicates remain findings without destructive controls")
        let renderer: [String: Any] = ["musicResponsiveListItemRenderer": ["title": ["simpleText": "Restricted track"], "playlistItemData": ["videoId": "restricted"], "musicItemRendererDisplayPolicy": "MUSIC_ITEM_RENDERER_DISPLAY_POLICY_GREY_OUT"]]
        expect(MusicParser.item(renderer)?.unavailable == true, "Service availability flags survive playlist parsing")
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let accountA = MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "test-account-A"])
        let accountB = MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "test-account-B"])
        let tools = ListeningTools(); tools.connect(accountA, directory: folder)
        let held = HeldPlace(song: first, queue: [first, extra, other], playlistID: "PLsource", selectedIndex: 1, elapsed: 57, wasPlaying: false, shuffle: true, repeatMode: "one")
        tools.hold(held)
        tools.beginRadio(seed: first, playlistID: "RDAMVMa")
        tools.record(first); tools.record(first); tools.record(other)
        expect(tools.trails[0].visits.count == 2, "Polling the same playing song does not duplicate a radio visit")
        tools.toggleDiscovery(other)
        let reloaded = ListeningTools(); reloaded.connect(accountA, directory: folder)
        expect(reloaded.heldPlace?.selectedIndex == 1 && reloaded.heldPlace?.elapsed == 57 && reloaded.heldPlace?.wasPlaying == false, "Held position, duplicate index and paused state survive relaunch")
        expect(reloaded.heldPlace?.shuffle == true && reloaded.heldPlace?.repeatMode == "one" && reloaded.heldPlace?.queue.count == 3, "Queue and playback modes survive relaunch")
        expect(reloaded.trails.count == 1 && reloaded.discoveries.count == 1, "Local radio and tray persist for the correct account")
        reloaded.connect(accountB, directory: folder)
        expect(reloaded.heldPlace == nil && reloaded.trails.isEmpty && reloaded.discoveries.isEmpty, "A different account cannot see the first account's private listening tools")
        reloaded.connect(accountA, directory: folder)
        expect(reloaded.heldPlace?.song.videoID == "a", "Returning to the account restores its saved place")
        reloaded.reset()
        expect(reloaded.heldPlace == nil && reloaded.trails.isEmpty && reloaded.palette == nil, "Account reset clears all in-memory private feature state")
        reloaded.connect(MusicAccountIdentity(config: ["authUser": 0]), directory: folder)
        expect(!reloaded.hasDiskStorage, "An ambiguous account slot alone cannot share a persisted file")
        tools.toggleDiscovery(other)
        expect(tools.discoveries.isEmpty, "Discovery tray toggle removes a kept item")
        for number in 0..<110 { tools.record(entry("song-\(number)", "entry-\(number)")) }
        expect(tools.trails[0].visits.count == 100, "Radio history is bounded per trail")
        for number in 0..<85 { tools.toggleDiscovery(entry("keep-\(number)", "kept-\(number)")) }
        expect(tools.discoveries.count == 80, "Discovery tray is bounded")
        for number in 0..<14 { tools.beginRadio(seed: first, playlistID: "RDAMVM\(number)") }
        expect(tools.trails.count == 12, "Saved session count is bounded")
        tools.endRadio(); let before = tools.trails[0].visits.count; tools.record(first)
        expect(tools.trails[0].visits.count == before, "Ordinary playlist playback does not contaminate a radio session")
        tools.configureAtmosphere(intensity: 2)
        expect(tools.atmosphereIntensity == 1, "Atmosphere intensity stays within the supported range")
        tools.configureAtmosphere(intensity: .nan)
        expect(tools.atmosphereIntensity == 1, "Invalid colour intensity is ignored")
        expect(ArtworkPaletteExtractor.extract(Data([0,1,2])) == nil, "Invalid artwork falls back without creating bogus colours")
        let space = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: nil, width: 16, height: 16, bitsPerComponent: 8, bytesPerRow: 64, space: space, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        context.setFillColor(CGColor(red: 0.9, green: 0.05, blue: 0.1, alpha: 1)); context.fill(CGRect(x: 0, y: 0, width: 16, height: 8))
        context.setFillColor(CGColor(red: 0.05, green: 0.1, blue: 0.9, alpha: 1)); context.fill(CGRect(x: 0, y: 8, width: 16, height: 8))
        let data = NSMutableData(); let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(destination, context.makeImage()!, nil); CGImageDestinationFinalize(destination)
        let palette = ArtworkPaletteExtractor.extract(data as Data)
        expect(palette != nil && palette!.primary != palette!.secondary, "Artwork sampling finds distinct dominant colours")
        let session = MusicSession(); session.tools.hold(held); session.resetAccountState()
        expect(session.tools.heldPlace == nil && session.tools.activeTrailID == nil, "Actual MusicSession account reset clears saved-tool UI state")
        print("PASS: \(checks) listening-tool safety, persistence, isolation, bounds and palette checks")
    }
}

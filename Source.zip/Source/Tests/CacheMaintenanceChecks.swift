import AppKit
import WebKit

@MainActor
final class TestNavigation: NSObject, WKNavigationDelegate {
    var finished: CheckedContinuation<Void, Error>?
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        finished?.resume(); finished = nil
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        finished?.resume(throwing: error); finished = nil
    }
}

@main
struct CacheMaintenanceChecks {
    @MainActor static func main() async throws {
        _ = NSApplication.shared
        var checks = 0
        func expect(_ value: @autoclosure () -> Bool, _ message: String) {
            precondition(value(), message); checks += 1
        }
        let protected: Set<String> = [WKWebsiteDataTypeCookies, WKWebsiteDataTypeLocalStorage,
            WKWebsiteDataTypeSessionStorage, WKWebsiteDataTypeIndexedDBDatabases,
            WKWebsiteDataTypeServiceWorkerRegistrations]
        expect(CacheMaintenance.removableTypes.isDisjoint(with: protected), "Cleanup must exclude authentication and account storage")
        expect(CacheMaintenance.removableTypes == [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache, WKWebsiteDataTypeFetchCache], "Cleanup must use cache-only allowlist")
        let now = Date()
        expect(CacheMaintenance.isDue(lastCleanup: nil, now: now), "First cleanup must run")
        expect(!CacheMaintenance.isDue(lastCleanup: now, now: now), "Recent cleanup must not repeat")
        expect(CacheMaintenance.isDue(lastCleanup: now.addingTimeInterval(-6 * 3600), now: now), "Six-hour maintenance must become due")

        let store = WKWebsiteDataStore.nonPersistent()
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = store
        let webView = WKWebView(frame: .zero, configuration: configuration)
        let delegate = TestNavigation()
        webView.navigationDelegate = delegate
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            delegate.finished = continuation
            webView.loadHTMLString("<html><body>Cache preservation test</body></html>", baseURL: URL(string: "https://cache-test.invalid/"))
        }
        _ = try await webView.evaluateJavaScript("localStorage.setItem('login-preservation-test','keep-me');sessionStorage.setItem('session-preservation-test','keep-session');true")
        let cookie = HTTPCookie(properties: [.domain: "cache-test.invalid", .path: "/", .name: "cache-test-session", .value: "test-only-sentinel", .secure: "TRUE"])!
        await store.httpCookieStore.setCookie(cookie)
        await CacheMaintenance.clear(store)
        let cookies = await store.httpCookieStore.allCookies()
        expect(cookies.contains { $0.name == cookie.name && $0.value == cookie.value }, "Cache cleanup must preserve existing cookie")
        let local = try await webView.evaluateJavaScript("localStorage.getItem('login-preservation-test')") as? String
        let session = try await webView.evaluateJavaScript("sessionStorage.getItem('session-preservation-test')") as? String
        expect(local == "keep-me", "Cache cleanup must preserve local storage")
        expect(session == "keep-session", "Cache cleanup must preserve session storage")
        print("PASS: \(checks) cache policy/WebKit login-storage preservation checks")
    }
}

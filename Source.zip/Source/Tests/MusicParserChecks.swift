import Foundation

@main
struct MusicParserChecks {
    static func main() {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() { fatalError(message) }
        }
        let track: [String: Any] = ["musicResponsiveListItemRenderer": [
            "playlistItemData": ["videoId": "track-1"],
            "flexColumns": [["musicResponsiveListItemFlexColumnRenderer": ["text": ["runs": [["text": "A song", "navigationEndpoint": ["watchEndpoint": ["videoId": "track-1", "playlistId": "PL-1"]]]]]]],
                            ["musicResponsiveListItemFlexColumnRenderer": ["text": ["runs": [["text": "Artist"]]]]]],
            "fixedColumns": [["musicResponsiveListItemFixedColumnRenderer": ["text": ["simpleText": "3:42"]]]],
            "menu": ["navigationEndpoint": ["watchEndpoint": ["videoId": "wrong-menu-track", "playlistId": "radio-menu"]]]
        ]]
        let parsed = MusicParser.item(track)
        expect(parsed?.videoID == "track-1", "Menu endpoint must not replace track identity")
        expect(parsed?.playlistID == "PL-1", "Track must retain playlist context")
        expect(parsed?.duration == "3:42", "Fixed duration column must parse")
        expect(parsed?.subtitle == "Artist", "Artist column must parse")
        let response: [String: Any] = ["contents": ["twoColumnBrowseResultsRenderer": [
            "secondaryContents": ["sectionListRenderer": ["contents": [["musicResponsiveHeaderRenderer": [
                "title": ["runs": [["text": "An album"]]],
                "thumbnail": ["musicThumbnailRenderer": ["thumbnail": ["thumbnails": [["url": "https://example.com/art.jpg", "width": 500]]]]]
            ]]]]],
            "tabs": [["tabRenderer": ["content": ["sectionListRenderer": ["contents": [["musicPlaylistShelfRenderer": [
                "contents": [track], "continuations": [["nextContinuationData": ["continuation": "next-page"]]]
            ]]]]]]]]
        ]]]
        let page = MusicParser.page(response, fallback: "Fallback")
        expect(page.title == "An album", "Nested responsive header must supply title")
        expect(page.artwork?.absoluteString == "https://example.com/art.jpg", "Nested header artwork must parse")
        expect(page.items.count == 1, "Nested playlist shelf should parse exactly once")
        expect(page.continuation == "next-page", "Playlist pagination token must survive")
        let chip: [String: Any] = ["contents": ["chipCloudRenderer": ["chips": [["chipCloudChipRenderer": [
            "text": ["simpleText": "Podcasts"], "navigationEndpoint": ["browseEndpoint": ["browseId": "FEmusic_home", "params": "server-params"]]
        ]]]]]]
        let filters = MusicParser.page(chip, fallback: "Home").filters
        expect(filters.first?.params == "server-params", "Server-provided filter params must survive")
        expect(filters.first?.browseID == "FEmusic_home", "Podcasts uses the discovered Home endpoint")
        let flatSearch: [String: Any] = ["contents": ["tabbedSearchResultsRenderer": ["tabs": [["tabRenderer": [
            "content": ["sectionListRenderer": ["contents": [track]]]
        ]]]]]]
        let searchPage = MusicParser.page(flatSearch, fallback: "Search")
        expect(searchPage.items.first?.videoID == "track-1", "Flat search results must become a native list")
        let filter = MusicParser.route(["searchEndpoint": ["query": "test", "params": "songs-filter"]], title: "Songs")
        expect(filter?.search == "test" && filter?.params == "songs-filter", "Search filters must retain query and params")
        let card: [String: Any] = ["musicTwoRowItemRenderer": [
            "title": ["simpleText": "Playlist"],
            "navigationEndpoint": ["browseEndpoint": ["browseId": "VLplaylist"]],
            "thumbnailOverlay": ["watchEndpoint": ["videoId": "random-overlay-video", "playlistId": "playlist"]]
        ]]
        let playlist = MusicParser.item(card)!
        expect(playlist.videoID == nil, "Playlist cards must not play a shuffled overlay video")
        expect(playlist.playlistID == "playlist" && playlist.kind == "Playlist", "Card must retain playlist identity")
        var artistTrack = track["musicResponsiveListItemRenderer"] as! [String: Any]
        artistTrack["navigationEndpoint"] = ["watchEndpoint": ["videoId": "track-1"]]
        artistTrack["artist"] = ["browseEndpoint": ["browseId": "UCartist"]]
        expect(MusicParser.item(["musicResponsiveListItemRenderer": artistTrack])?.videoID == "track-1", "An artist sublink must not turn a song into a container")
        var context = PlaybackContext()
        context.begin(videoID: "first", playlistID: "playlist")
        let oldGeneration = context.generation
        expect(!context.accepts(generation: oldGeneration, videoID: "restored-random"), "Ignore restored track while requested first song loads")
        expect(context.accepts(generation: oldGeneration, videoID: "first"), "Accept the requested first track")
        expect(context.accepts(generation: oldGeneration, videoID: "second"), "Allow automatic next track after initial acceptance")
        context.begin(videoID: "other-first", playlistID: "other-playlist")
        expect(!context.accepts(generation: oldGeneration, videoID: "second"), "Reject late state messages from the old document")
        expect(!context.owns(oldGeneration, playlistID: "playlist"), "Reject old queue request after switching playlists")
        let seed = [parsed!, MusicItem(id: "track-2", title: "Second", subtitle: "", videoID: "track-2", kind: "Song")]
        let retained = PlaybackContext.reconcileQueue(existing: seed, incoming: [parsed!], playlistID: "playlist")
        expect(retained.map(\.id) == seed.map(\.id), "Single-song response must not collapse playlist queue")
        expect(PlaybackContext.reconcileQueue(existing: seed, incoming: [], playlistID: "playlist").count == 2, "Empty refresh must not clear queue")
        var ambiguousCard = playlist
        ambiguousCard.videoID = "suggested-overlay-track"
        expect(ambiguousCard.containerRoute?.browseID == "VLplaylist", "Opening a playlist must prefer its contents over a suggested track")
        expect(ambiguousCard.containerRoute?.title == "Playlist", "Card navigation must preserve the playlist title")
        expect(parsed!.containerRoute == nil, "A regular song must keep its play action")
        var linkedTrack = track["musicResponsiveListItemRenderer"] as! [String: Any]
        linkedTrack["subtitle"] = ["runs": [
            ["text": "Artist", "navigationEndpoint": ["browseEndpoint": ["browseId": "UCartist"]]],
            ["text": "Album", "navigationEndpoint": ["browseEndpoint": ["browseId": "MPREalbum"]]]
        ]]
        let linked = MusicParser.item(["musicResponsiveListItemRenderer": linkedTrack])!
        expect(linked.route == nil, "Song must never borrow an album browse destination")
        expect(linked.detailRoute?.song?.videoID == "track-1", "Open Song must retain exact video identity")
        expect(linked.album?.browseID == "MPREalbum", "Album link must remain separate")
        expect(linked.artist?.browseID == "UCartist", "Artist link must remain separate")
        var cache = MusicPageCache(limit: 2)
        let a = MusicRoute(title: "A", browseID: "A")
        let b = MusicRoute(title: "B", browseID: "B")
        let c = MusicRoute(title: "C", browseID: "C")
        cache.store(page, for: a)
        expect(cache.page(for: a)?.items.count == 1, "Back cache must retain loaded content")
        cache.store(page, for: b)
        cache.store(page, for: c)
        expect(cache.page(for: a) == nil && cache.page(for: b) != nil, "Navigation cache must stay bounded")
        expect(MusicParser.liked(["likeStatus": "LIKE"]) == true, "Read an existing like")
        expect(MusicParser.liked(["likeStatus": "DISLIKE"]) == false, "Disliked is not liked")
        expect(MusicParser.liked([:]) == nil, "Missing rating must remain unknown")
        expect(MusicParser.liked(["menu": ["toggleMenuServiceItemRenderer": ["defaultServiceEndpoint": ["likeEndpoint": ["status": "INDIFFERENT"]]]]]) == true, "Remove-like menu means already liked")
        expect(MusicParser.liked(["menu": ["toggleMenuServiceItemRenderer": ["defaultServiceEndpoint": ["likeEndpoint": ["status": "LIKE"]]]]]) == false, "Add-like menu means not liked")
        expect(MusicParser.liked(["likeButtonRenderer": ["likeStatus": "INDIFFERENT"]]) == false, "Read unselected like button")
        var removable = track["musicResponsiveListItemRenderer"] as! [String: Any]
        removable["menu"] = ["playlistEditEndpoint": ["playlistId": "PL-owned", "actions": [["action": "ACTION_REMOVE_VIDEO", "setVideoId": "entry-1", "removedVideoId": "track-1"]]]]
        let removableItem = MusicParser.item(["musicResponsiveListItemRenderer": removable])!
        expect(removableItem.playlistEntryID == "entry-1", "Removal must preserve exact playlist occurrence")
        expect(removableItem.removalPlaylistID == "PL-owned", "Removal must preserve source playlist")
        expect(parsed!.playlistEntryID == nil, "Search song without a remove endpoint must not offer removal")
        removable["menu"] = ["playlistEditEndpoint": ["playlistId": "PL-owned", "actions": [["action": "ACTION_REMOVE_VIDEO", "setVideoId": "wrong-entry", "removedVideoId": "other-video"]]]]
        expect(MusicParser.item(["musicResponsiveListItemRenderer": removable])?.playlistEntryID == nil, "Unrelated menu endpoints must never remove another song")
        expect(parsed!.matchesPlaylistSearch("  A SONG  "), "Playlist search must trim and ignore case")
        expect(parsed!.matchesPlaylistSearch("artist"), "Playlist search must match metadata")
        expect(parsed!.matchesPlaylistSearch("   "), "Clearing search must restore songs")
        expect(!parsed!.matchesPlaylistSearch("no-such-song"), "Unmatched songs must be filtered")
        let accountA = MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "account-A"])
        let accountB = MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "account-B"])
        expect(accountA != accountB, "Different accounts in the same slot must reset session")
        expect(accountA != MusicAccountIdentity(config: ["authUser": 0, "dataSyncID": "account-A", "delegatedSession": "brand"]), "Brand identity must trigger reset")
        var firstOccurrence = parsed!
        firstOccurrence.playlistEntryID = "entry-first"
        firstOccurrence.playlistPosition = 0
        var secondOccurrence = firstOccurrence
        secondOccurrence.playlistEntryID = "entry-second"
        secondOccurrence.playlistPosition = 2
        let duplicates = [firstOccurrence, seed[1], secondOccurrence]
        expect(PlaybackContext.selectedIndex(item: secondOccurrence, in: duplicates) == 2, "Later duplicate must preserve canonical position")
        secondOccurrence.playlistPosition = nil
        expect(PlaybackContext.selectedIndex(item: secondOccurrence, in: duplicates) == 2, "Occurrence ID must distinguish duplicate videos")
        secondOccurrence.playlistPosition = 104
        expect(PlaybackContext.selectedIndex(item: secondOccurrence, in: []) == 104, "Canonical index must survive standalone details and pagination")
        let writableResponse: [String: Any] = ["addToPlaylistRenderer": ["contents": [
            ["playlistAddToOptionRenderer": ["playlistId": "PL-owned", "title": ["simpleText": "Owned"]]],
            ["playlistAddToOptionRenderer": ["playlistId": "PL-read-only", "title": ["simpleText": "Read only"], "isEditable": false]],
            ["playlistAddToOptionRenderer": ["playlistId": "PL-disabled", "title": ["simpleText": "Disabled"], "isDisabled": true]],
            ["musicTwoRowItemRenderer": ["navigationEndpoint": ["browseEndpoint": ["browseId": "VLPL-saved"]], "title": ["simpleText": "Saved read-only card"]]],
            ["playlistAddToOptionRenderer": ["playlistId": "PL-owned", "title": ["simpleText": "Duplicate"]]]
        ]]]
        let writableOptions = MusicParser.addToPlaylistOptions(writableResponse)
        expect(writableOptions.map(\.playlistID) == ["PL-owned"], "Picker must use authoritative writable options, dedupe, and exclude disabled/read-only entries")
        expect(writableOptions.first?.title == "Owned", "Writable destination title must survive")
        expect(MusicParser.addToPlaylistOptions(["playlistId": "PL-parent"]).isEmpty, "Arbitrary containers must not become editable destinations")
        expect(MusicParser.addToPlaylistOptions(["playlistAddToOptionRenderer": ["playlistId": "LM", "title": ["simpleText": "Liked music"]]]).isEmpty, "Special liked playlist must use rating controls rather than ordinary playlist writes")
        let tinyCover = URL(string: "https://lh3.googleusercontent.com/cover=w60-h60-l90-rj")!
        let coverOptions = ArtworkResolution.candidates(for: tinyCover, highResolution: true)
        expect(coverOptions.first?.absoluteString == "https://lh3.googleusercontent.com/cover=w1024-h1024-l90-rj", "Large popup must request real higher-resolution cover pixels")
        expect(coverOptions.last == tinyCover, "Original cover must remain a fallback")
        expect(ArtworkResolution.candidates(for: tinyCover, highResolution: false) == [tinyCover], "Small artwork must not overfetch")
        let videoOptions = ArtworkResolution.candidates(for: URL(string: "https://i.ytimg.com/vi/track/hqdefault.jpg")!, highResolution: true)
        expect(videoOptions.first?.lastPathComponent == "maxresdefault.jpg" && videoOptions.last?.lastPathComponent == "hqdefault.jpg", "Video artwork must try high resolution with original fallback")
        let customCover = URL(string: "https://example.com/cover=w60-h60")!
        expect(ArtworkResolution.candidates(for: customCover, highResolution: true) == [customCover], "Unknown image hosts must not be rewritten")
        expect(ArtworkResolution.candidates(for: nil, highResolution: true).isEmpty, "Missing artwork must remain safe")
        expect(ArtworkResolution.requestedPixels(pointSize: 164, displayScale: 2) >= 1024, "Prominent artist/card artwork must request high resolution automatically")
        expect(ArtworkResolution.requestedPixels(pointSize: 57, displayScale: 2) >= 114, "Bottom artwork must account for Retina pixels")
        expect(ArtworkResolution.requestedPixels(pointSize: 30, displayScale: 2) < 1024, "Sidebar thumbnails must avoid oversized requests")
        let sizedAvatar = URL(string: "https://yt3.ggpht.com/avatar=s88-c-k-c0x00ffffff-no-rj")!
        expect(ArtworkResolution.candidates(for: sizedAvatar, pixels: 1024).first?.absoluteString.contains("=s1024-c-k") == true, "Artist avatar sizing and crop flags must be preserved")
        let pathAvatar = URL(string: "https://yt3.ggpht.com/s88-c/avatar.jpg")!
        expect(ArtworkResolution.candidates(for: pathAvatar, pixels: 512).first?.path == "/s512-c/avatar.jpg", "Path-style avatar sizes must be upgraded")
        let banner = URL(string: "https://yt3.ggpht.com/banner=w120-h60-l90-rj?token=keep")!
        let bannerHD = ArtworkResolution.candidates(for: banner, pixels: 1024).first!
        expect(bannerHD.path.contains("=w2048-h1024") && bannerHD.query == "token=keep", "Upsizing must preserve aspect ratio and URL query")
        let existingHD = URL(string: "https://lh3.googleusercontent.com/cover=w2048-h2048-l90-rj")!
        expect(ArtworkResolution.candidates(for: existingHD, pixels: 1024).first == existingHD, "Already large artwork must never be downsampled in the URL")
        let nestedImages: [String: Any] = ["a": ["thumbnails": [["url": "https://example.com/tiny.jpg", "width": 60, "height": 60]]], "b": ["thumbnails": [["url": "https://example.com/large.jpg", "width": 1000, "height": 1000]]]]
        expect(MusicParser.artwork(nestedImages)?.lastPathComponent == "large.jpg", "Parser must inspect every thumbnail group rather than stop at the first tiny one")
        print("PASS: 68 parser/playback checks (identity, playlist context, metadata, nested headers, pagination, dynamic filters)")
    }
}

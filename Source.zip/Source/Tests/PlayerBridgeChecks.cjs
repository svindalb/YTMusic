const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
let lastMessage;
let currentID = 'restored-old-song';
const playLevels = [];
class Media {
  constructor() { this.level = 1; this.paused = true; this.ended = false; this.duration = 180; this.currentTime = 0; }
  get volume() { return this.level; }
  set volume(value) { this.level = value; }
  addEventListener(name, callback) { (this.listeners ??= {})[name] ??= []; this.listeners[name].push(callback); }
  emit(name) { for (const callback of this.listeners?.[name] ?? []) callback(); }
  play() { playLevels.push(this.level); this.paused = false; this.emit('play'); this.emit('playing'); return Promise.resolve(); }
  pause() { this.paused = true; this.emit('pause'); }
}
let clock = 1000;
let shuffleClicks = 0;
let repeatClicks = 0;
const bar = {shuffleOn: false, repeatMode: 'NONE', querySelector(selector) {
  if (selector === '#expand-shuffle') return {click() { shuffleClicks++; bar.shuffleOn = !bar.shuffleOn; }};
  if (selector === '#expand-repeat') return {click() { repeatClicks++; bar.repeatMode = {NONE: 'ALL', ALL: 'ONE', ONE: 'NONE'}[bar.repeatMode]; }};
  return null;
}};
let video;
let tick;
class Doc {
  createElement(name) { return name === 'video' ? new Media() : {}; }
  querySelector(selector) {
    if (selector === '#movie_player') return {getVideoData: () => ({video_id: currentID, title: currentID})};
    if (selector === 'video') return video;
    if (selector === 'ytmusic-player-bar') return bar;
    return null;
  }
  querySelectorAll() { return video ? [video] : []; }
  addEventListener() {}
}
const document = new Doc();
const context = {
  HTMLMediaElement: Media, Document: Doc, document, Date: {now: () => clock},
  location: {hostname: 'music.youtube.com'},
  MutationObserver: class { observe() {} },
  setInterval(callback) { tick = () => { clock += 500; callback(); }; },
  window: {webkit: {messageHandlers: {musicState: {postMessage(message) { lastMessage = message; }}}}}
};
const source = fs.readFileSync(process.argv[2], 'utf8').replace('__NATIVE_CONFIG__', JSON.stringify({
  generation: 'test-generation', expectedVideoID: 'requested-first', volume: 0.12, autoplay: true
}));
vm.runInNewContext(source, context);
video = document.createElement('video');
assert.equal(video.level, 0, 'A restored wrong track must start silent');
video.volume = 1;
assert.equal(video.level, 0, 'Website cannot make an old track audible while loading');
video.play();
assert.equal(playLevels.at(-1), 0, 'Volume guard must run before play');
currentID = 'requested-first';
video.play();
assert.equal(playLevels.at(-1), 0.12, 'Requested song must start at app volume');
video.volume = 1;
assert.equal(video.level, 0.12, 'Website volume restore must not spike above app volume');
tick();
video.paused = true;
const callsBeforePause = playLevels.length;
tick();
assert.equal(playLevels.length, callsBeforePause, 'State polling must not undo a user pause');
currentID = 'next-song';
video = document.createElement('video');
assert.equal(video.level, 0.12, 'Replacement media must inherit app volume before playback');
video.volume = 0.9;
video.play();
assert.equal(playLevels.at(-1), 0.12, 'Next track cannot start at website volume');
context.window.__nativeMusic.setVolume(0.37);
assert.equal(video.level, 0.37, 'App volume changes apply immediately');
video.volume = 1;
assert.equal(video.level, 0.37, 'App remains authoritative after a volume change');
context.window.__nativeMusic.setVolume(0);
video.play();
assert.equal(playLevels.at(-1), 0, 'Mute applies before playback');
context.window.__nativeMusic.setVolume(0.12);
for (let index = 0; index < 10000; index++) {
  // Repeated website writes during an already-playing song, with no user action.
  video.volume = ((index * 7919) % 101) / 100;
  assert.equal(video.level, 0.12, 'Ongoing playback writes cannot raise or lower app volume');
  if (index % 50 === 0) { video.currentTime += 0.5; tick(); }
}
tick();
assert.equal(lastMessage.volumeDiagnostics.maxOvershoot, 0, 'No overshoot during repeated ongoing-playback changes');
assert.ok(lastMessage.volumeDiagnostics.blockedRaises > 0, 'Record website raises prevented before applying them');
assert.ok(lastMessage.volumeDiagnostics.playingSamples > 0, 'Collect actual ongoing-playback samples');
assert.equal(context.window.__nativeMusic.setPlaying(false, 101), true, 'Pause command is accepted');
assert.equal(lastMessage.playing, false, 'Pause event reports immediately without a polling tick');
assert.equal(lastMessage.transportCommand, 101, 'Pause report acknowledges the command');
assert.equal(context.window.__nativeMusic.setPlaying(true, 102), true, 'Play command is accepted');
assert.equal(lastMessage.playing, true, 'Play event reports immediately without a polling tick');
assert.equal(lastMessage.transportCommand, 102, 'Play report acknowledges the latest command');
context.window.__nativeMusic.setPlaying(false, 103);
context.window.__nativeMusic.setPlaying(true, 104);
context.window.__nativeMusic.setPlaying(false, 105);
assert.equal(lastMessage.playing, false, 'Rapid clicks settle at the latest requested state');
assert.equal(lastMessage.transportCommand, 105, 'Rapid clicks acknowledge the latest command');
video = undefined;
assert.equal(context.window.__nativeMusic.setPlaying(true, 106), false, 'Missing media reports a command failure');
console.log('PASS: 9 immediate transport checks + 11 bridge checks + 10,000 ongoing-playback writes + 3 diagnostic checks (pre-play volume, website restore, media replacement, mute, pause)');

video = document.createElement('video');
tick();
context.window.__nativeMusic.setModes(true, 'all');
tick();
assert.equal(bar.shuffleOn, true, 'Shuffle drives the actual YouTube Music queue control');
assert.equal(bar.repeatMode, 'ALL', 'Repeat queue reaches the real player bar');
const previousShuffleClicks = shuffleClicks;
for (let i = 0; i < 10; i++) tick();
assert.equal(shuffleClicks, previousShuffleClicks, 'Polling does not toggle an already-correct shuffle state');
context.window.__nativeMusic.setModes(false, 'one');
tick(); tick();
assert.equal(bar.shuffleOn, false, 'Disabling shuffle updates the actual queue');
assert.equal(bar.repeatMode, 'ONE', 'Repeat one reaches the real queue mode');
assert.equal(video.loop, true, 'Repeat one loops current media without an ended event');
context.window.__nativeMusic.setModes(false, 'off');
tick(); tick();
assert.equal(bar.repeatMode, 'NONE', 'Repeat off reaches the real queue mode');
assert.equal(video.loop, false, 'Turning repeat off releases the media loop');
assert.equal(video.level, 0.12, 'Queue mode changes preserve app volume');
console.log('PASS: 9 real queue shuffle/repeat checks');

// A fresh realm exercises startup suppression and the real restore bridge.
function restoreRealm() {
  let state, tick, endedHandler, id = 'saved';
  const starts = [];
  class RestoreMedia {
    constructor() { this.level = 1; this.paused = true; this.ended = false; this.duration = 180; this.currentTime = 0; }
    get volume() { return this.level; }
    set volume(v) { this.level = v; }
    addEventListener(name, callback) { (this.listeners ??= {})[name] ??= []; this.listeners[name].push(callback); }
    emit(name) { for (const cb of this.listeners?.[name] ?? []) cb(); }
    play() { starts.push(this.level); this.paused = false; this.emit('play'); return Promise.resolve(); }
    pause() { this.paused = true; this.emit('pause'); }
  }
  let media;
  class RestoreDoc {
    createElement() { return new RestoreMedia(); }
    querySelector(selector) { if (selector === 'video') return media; if (selector === '#movie_player') return {getVideoData: () => ({video_id: id, title: id})}; return null; }
    querySelectorAll() { return media ? [media] : []; }
    addEventListener(event, handler) { if (event === 'ended') endedHandler = handler; }
  }
  const doc = new RestoreDoc();
  const realm = {HTMLMediaElement: RestoreMedia, Document: RestoreDoc, document: doc,
    location: {hostname: 'music.youtube.com'}, MutationObserver: class {observe() {}},
    setInterval(callback) { tick = callback; }, window: {webkit: {messageHandlers: {musicState: {postMessage(value) { state = value; }}}}}};
  const script = fs.readFileSync(process.argv[2], 'utf8').replace('__NATIVE_CONFIG__', JSON.stringify({generation: 'restore', expectedVideoID: 'saved', volume: 0.2, autoplay: false, pauseOnLoad: true, nativeQueue: true}));
  vm.runInNewContext(script, realm);
  media = doc.createElement('video');
  return {realm, starts, media, tick: () => tick(), state: () => state, setID: value => {id = value;}, end: event => endedHandler(event)};
}
const restore = restoreRealm();
restore.media.play();
assert.equal(restore.starts.length, 0, 'Saved-place loading cannot emit audio before seeking');
assert.equal(restore.media.paused, true, 'Website autoplay stays paused during saved-place loading');
assert.equal(restore.realm.window.__nativeMusic.restorePlace(44, false, 301), true, 'Restore accepts a loaded saved track');
assert.equal(restore.media.currentTime, 44, 'Restore actually seeks the media, rather than only updating native text');
assert.equal(restore.media.paused, true, 'A paused saved place stays paused');
restore.media.play();
assert.equal(restore.starts.length, 0, 'Late website autoplay cannot unpause a paused saved place');
restore.realm.window.__nativeMusic.setPlaying(true, 302);
assert.equal(restore.starts.at(-1), 0.2, 'Starting the restored song retains app volume');
assert.equal(restore.realm.window.__nativeMusic.restorePlace(999, true, 303), true, 'Overlong saved positions can be restored safely');
assert.equal(restore.media.currentTime, 179.75, 'Saved positions clamp before the end of the track');
restore.media.duration = 0;
assert.equal(restore.realm.window.__nativeMusic.restorePlace(20, true, 304), false, 'Seek waits for a real duration');
restore.media.duration = 180;
restore.setID('unexpected-radio-song');
restore.media.play();
assert.equal(restore.starts.at(-1), 0, 'A regenerated website radio cannot play an unexpected song over a held queue');
let intercepted = false;
restore.media.ended = true;
restore.end({stopImmediatePropagation() { intercepted = true; }});
assert.equal(intercepted, true, 'Held queues intercept website automatic queue progression');
assert.equal(restore.state().ended, true, 'The native app still receives the ending and advances its saved queue');
console.log('PASS: 13 held-place seek, startup-silence and queue-ownership checks');

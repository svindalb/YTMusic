#!/bin/bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${YT_MUSIC_BUILD_ROOT:-/private/tmp/ytmusic-distribution-build}"
output_dir="$project_root/Distribution"
stage_dir="$(mktemp -d /private/tmp/ytmusic-package.XXXXXX)"
trap 'rm -rf "$stage_dir"' EXIT
xcodebuild -project "$project_root/YTMusic.xcodeproj" -scheme YTMusic \
  -configuration Release -destination 'generic/platform=macOS' \
  -derivedDataPath "$build_root" ARCHS=arm64 ONLY_ACTIVE_ARCH=NO \
  CODE_SIGN_IDENTITY=- CODE_SIGN_STYLE=Manual ENABLE_HARDENED_RUNTIME=YES CODE_SIGN_INJECT_BASE_ENTITLEMENTS=NO CODE_SIGN_ENTITLEMENTS="$output_dir/Release.entitlements" build
mkdir -p "$output_dir"
ditto "$build_root/Build/Products/Release/YTMusic.app" "$stage_dir/YT Music.app"
cp "$output_dir/README.txt" "$stage_dir/README.txt"
ln -s /Applications "$stage_dir/Applications"
codesign --verify --deep --strict --verbose=2 "$stage_dir/YT Music.app"
architectures="$(xcrun lipo -archs "$stage_dir/YT Music.app/Contents/MacOS/YTMusic")"
[[ "$architectures" == "arm64" ]]
zip_path="$output_dir/YT-Music-1.0-apple-silicon-unnotarized.zip"
dmg_path="$output_dir/YT-Music-1.0-apple-silicon-unnotarized.dmg"
# Keep the app and installation notes together in the zip.
mkdir "$stage_dir/zip"
ditto "$stage_dir/YT Music.app" "$stage_dir/zip/YT Music.app"
cp "$stage_dir/README.txt" "$stage_dir/zip/README.txt"
ditto -c -k --sequesterRsrc "$stage_dir/zip" "$zip_path"
# Remove only our temporary ZIP staging folder before making the install image.
rm -rf "$stage_dir/zip"
hdiutil create -volname 'YT Music' -srcfolder "$stage_dir" -ov -format UDZO "$dmg_path"
hdiutil verify "$dmg_path"
(cd "$output_dir" && shasum -a 256 "$(basename "$zip_path")" "$(basename "$dmg_path")" > SHA256SUMS.txt)
